"""Turn one 3D depiction of a molecule into another, as line art.

A `.cdxml` ChemDraw built from a crystal structure keeps a real coordinate
per atom whose first two components ARE the drawing position: the picture
is an orthographic projection with depth in the third.  Two depictions of
the same molecule therefore differ by a rigid rotation, which can be
recovered exactly from the coordinates and then turned through.

Nothing here interprets chemistry.  The drawing is treated as a rigid body
of line segments and text, and every frame is repainted with the same
occlusion rules as a morph - the difference being that depth now comes
from the rotated coordinates rather than from the file's paint order.
"""
import copy

import numpy as np

from . import animate as mo
from . import scene as cs

# Which end of the depth axis faces the reader.  Established against the
# crossings ChemDraw itself declared in a 3D export: at each declared
# crossing that actually intersects in projection, the segment ChemDraw
# painted in front was the one with the SMALLER coordinate, by a margin of
# ~38 pt in both cases.  Flip the sign if a drawing comes out inside-out.
FRONT = -1.0

# Atoms a fragment needs before it is a structure rather than decoration:
# an equivalency sign drawn as a triple bond between two bare carbons is a
# fragment like any other, and has no 3D at all.
MIN_ATOMS = 3


def count_3d(sc):
    return sum(1 for n in sc.nodes.values() if n.get("xyz") is not None)


def structures(scenes, min_atoms=MIN_ATOMS):
    """The depictions worth turning: those carrying 3D, decoration dropped."""
    return [s for s in scenes if count_3d(s) >= min_atoms]


def coords(sc):
    keys = [k for k, n in sc.nodes.items() if n.get("xyz") is not None]
    return keys, np.array([sc.nodes[k]["xyz"] for k in keys], float)


def correspondence(A, B):
    """Atom-for-atom pairing between two depictions of one molecule.

    Document order, checked against the element sequence.  One structure
    duplicated and re-oriented writes the same atoms in the same order; if
    that does not hold here the pairing is refused rather than guessed,
    because a wrong pairing yields a plausible-looking wrong rotation.
    """
    ka, P = coords(A)
    kb, Q = coords(B)
    if len(ka) != len(kb):
        raise ValueError(
            f"one depiction has {len(ka)} atoms with 3D coordinates and the "
            f"other {len(kb)}; these are not the same structure")
    ea = [A.nodes[k]["element"] for k in ka]
    eb = [B.nodes[k]["element"] for k in kb]
    if ea != eb:
        bad = next(i for i, (x, y) in enumerate(zip(ea, eb)) if x != y)
        raise ValueError(
            f"the two depictions list different elements in document order "
            f"(atom {bad + 1}: {ea[bad]} vs {eb[bad]}), so they cannot be "
            "paired by order")
    return ka, kb, P, Q


def fit(A, B):
    """The rotation carrying depiction A onto depiction B.

    Returns the rotation, how exactly it fits, and the centres, so a caller
    can report the quality rather than assume it.
    """
    ka, kb, P, Q = correspondence(A, B)
    pc, qc = P.mean(0), Q.mean(0)
    H = (P - pc).T @ (Q - qc)
    U, _, Vt = np.linalg.svd(H)
    d = float(np.sign(np.linalg.det(Vt.T @ U.T))) or 1.0
    R = Vt.T @ np.diag([1.0, 1.0, d]) @ U.T
    rmsd = float(np.sqrt((((P - pc) @ R.T - (Q - qc)) ** 2).sum(1).mean()))
    radius = float(np.linalg.norm(P - pc, axis=1).mean())
    ax, ang = axis_angle(R)
    return dict(R=R, axis=ax, angle=ang, rmsd=rmsd, radius=radius,
                reflected=d < 0, keys_a=ka, keys_b=kb, P=P, Q=Q,
                centre=pc, target_centre=qc)


def axis_angle(R):
    """Axis and angle (radians) of a proper rotation."""
    ang = float(np.arccos(np.clip((np.trace(R) - 1.0) / 2.0, -1.0, 1.0)))
    v = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    n = float(np.linalg.norm(v))
    if n > 1e-9:
        return v / n, ang
    if ang < 1e-9:                       # identity: any axis will do
        return np.array([0.0, 0.0, 1.0]), 0.0
    # a half turn: the axis is the eigenvector of R for eigenvalue +1
    w, V = np.linalg.eigh(R + R.T)
    ax = np.real(V[:, int(np.argmax(w))])
    return ax / float(np.linalg.norm(ax)), ang


def rotation(axis, ang):
    """Rodrigues' rotation matrix."""
    x, y, z = axis
    K = np.array([[0.0, -z, y], [z, 0.0, -x], [-y, x, 0.0]])
    return np.eye(3) + np.sin(ang) * K + (1.0 - np.cos(ang)) * (K @ K)


def oriented(A, ft, t, centre=None, labels=None, colors=None,
             glyphs=None):
    """A copy of depiction A turned `t` of the way onto its partner.

    The turn is about the fixed axis of the rotation, so the molecule
    spins once through the shortest path rather than drifting through
    intermediate shapes: a rigid body stays rigid at every frame.
    """
    R = rotation(ft["axis"], ft["angle"] * float(t))
    pc = ft["centre"]
    at = np.asarray(ft["centre"] if centre is None else centre, float)
    if at.shape == (2,):
        at = np.array([at[0], at[1], pc[2]])

    sc = copy.copy(A)
    sc.nodes = {}
    sc.bonds = {}
    depth = {}
    for k, n in A.nodes.items():
        m = dict(n)
        if n.get("xyz") is not None:
            q = (np.asarray(n["xyz"], float) - pc) @ R.T + at
            d = np.array(q[:2]) - np.asarray(n["p"], float)
            m["p"] = (float(q[0]), float(q[1]))
            m["z"] = FRONT * float(q[2])
            depth[k] = m["z"]
            if n["label"]:                # the label rides its atom
                lab = dict(n["label"])
                x0, y0, x1, y1 = lab["bbox"]
                lab["bbox"] = [x0 + d[0], y0 + d[1], x1 + d[0], y1 + d[1]]
                lab["anchor"] = (n["label"]["anchor"][0] + d[0],
                                 n["label"]["anchor"][1] + d[1])
                m["label"] = lab
        sc.nodes[k] = m

    for k, b in A.bonds.items():
        m = dict(b)
        ends = [depth[x] for x in (b["b"], b["e"]) if x in depth]
        if ends:
            # the engine compares one depth per stroke, so a bond takes the
            # mean of its ends; see `crossing_risk` for where that is thin
            m["z"] = float(np.mean(ends))
        sc.bonds[k] = m
    if colors:
        blend_colors(sc, colors, t)
    if glyphs:
        blend_labels(sc, glyphs, t)
    if labels:
        slide_hydrogen(sc, labels, t)
    return sc


def crossing_risk(A, ft, ts):
    """Crossings where a bond's mean depth disagrees with its depth at the
    point the two bonds actually cross.

    The occlusion engine holds one depth per stroke, so a bond is ordered
    by the mean of its ends.  Two bonds crossing near one end of a steeply
    tilted bond can be ordered the wrong way round by that average; this
    counts how often it happens rather than assuming it does not.
    """
    bad = total = 0
    for t in ts:
        sc = oriented(A, ft, t)
        segs = []
        for k, b in sc.bonds.items():
            if b["b"] not in sc.nodes or b["e"] not in sc.nodes:
                continue
            p0 = np.asarray(sc.nodes[b["b"]]["p"], float)
            p1 = np.asarray(sc.nodes[b["e"]]["p"], float)
            z0 = sc.nodes[b["b"]]["z"]
            z1 = sc.nodes[b["e"]]["z"]
            segs.append((k, p0, p1, z0, z1, b["z"], (b["b"], b["e"])))
        for i in range(len(segs)):
            for j in range(i + 1, len(segs)):
                ki, p0, p1, z0, z1, mi, ei = segs[i]
                kj, q0, q1, w0, w1, mj, ej = segs[j]
                if set(ei) & set(ej):
                    continue
                hit = _cross(p0, p1, q0, q1)
                if hit is None:
                    continue
                u, v = hit
                di = z0 + u * (z1 - z0)
                dj = w0 + v * (w1 - w0)
                if abs(di - dj) < 1e-9 or abs(mi - mj) < 1e-9:
                    continue
                total += 1
                bad += (di > dj) != (mi > mj)
    return bad, total


def _cross(p0, p1, q0, q1):
    r, s = p1 - p0, q1 - q0
    d = r[0] * s[1] - r[1] * s[0]
    if abs(d) < 1e-12:
        return None
    w = q0 - p0
    u = (w[0] * s[1] - w[1] * s[0]) / d
    v = (w[0] * r[1] - w[1] * r[0]) / d
    return (u, v) if 0.0 < u < 1.0 and 0.0 < v < 1.0 else None


def complete(A, B, nm, passes=8):
    """Extend a partial pairing using connectivity alone.

    An atom whose already-paired neighbours point unambiguously at a single
    candidate of the same element and degree is paired with it.  Two
    drawings of one molecule share a graph even when the geometry has been
    redrawn by hand, so this recovers the atoms a geometric match leaves
    out - and refuses to guess where more than one candidate fits.
    """
    nm = dict(nm)
    nbA, nbB = mo.adj(A), mo.adj(B)
    for _ in range(passes):
        used = set(nm.values())
        added = 0
        for a in A.nodes:
            if a in nm:
                continue
            imgs = [nm[x] for x in nbA[a] if x in nm]
            if not imgs:
                continue
            cand = set(nbB[imgs[0]])
            for y in imgs[1:]:
                cand &= set(nbB[y])
            cand = {c for c in cand
                    if c not in used
                    and B.nodes[c].get("element") == A.nodes[a].get("element")
                    and len(nbB[c]) == len(nbA[a])}
            if len(cand) == 1:
                c = cand.pop()
                nm[a] = c
                used.add(c)
                added += 1
        if not added:
            break
    return nm


def median_bond(sc):
    L = [float(np.hypot(*(np.asarray(sc.nodes[b["e"]]["p"], float)
                          - np.asarray(sc.nodes[b["b"]]["p"], float))))
         for b in sc.bonds.values()
         if b["b"] in sc.nodes and b["e"] in sc.nodes]
    return float(np.median(L)) if L else 1.0


def borrow_depth(drawn, solid, pairs):
    """Depth for a hand-drawn depiction, taken from the 3D one it copies.

    The drawing keeps its own x and y - that is the whole point of having
    redrawn it - and gains only the third coordinate, rescaled to the
    drawing's own bond length so the foreshortening matches its size.
    """
    k = median_bond(drawn) / max(median_bond(solid), 1e-6)
    out = {}
    for a, s in pairs.items():
        xyz = solid.nodes[s].get("xyz")
        if xyz is not None:
            out[a] = k * float(xyz[2])
    return out


def guided(A, B, pairs, depth, axis, angle, t, centre_a=None,
           centre_b=None, travel=False, labels=None, colors=None,
           stereo=None, fades=None, glyphs=None):
    """Depiction A at time t, turning as its 3D counterpart turns.

    Two things are combined.  The drawing is treated as a rigid body and
    turned through the rotation measured on the 3D pair, which is what
    makes the motion read as one object rotating.  A hand-drawn depiction
    is not geometrically faithful, though, so that turn does not land on
    the second drawing; the remaining per-atom difference is closed over
    the same interval.  Both ends are therefore exactly the drawings as
    drawn, and everything in between is the rotation plus a correction.
    """
    keys = [k for k in A.nodes if k in depth]
    X = np.array([[A.nodes[k]["p"][0], A.nodes[k]["p"][1], depth[k]]
                  for k in keys], float)
    cA = X.mean(0)
    # Centroids of the ATOMS, not of the bounding boxes: the turn is about
    # the atom centroid, so anchoring it anywhere else shifts the drawing
    # off its own starting position at t=0.
    ca2 = np.asarray(centre_a if centre_a is not None else cA[:2], float)
    if centre_b is not None:
        cb2 = np.asarray(centre_b, float)
    else:
        img = [B.nodes[pairs[k]]["p"] for k in keys
               if pairs.get(k) in B.nodes]
        cb2 = (np.asarray(img, float).mean(0) if img else ca2)

    Rt = rotation(axis, angle * float(t))
    R1 = rotation(axis, angle)
    here = (X - cA) @ Rt.T
    land = (X - cA) @ R1.T

    # What the rigid turn misses.  The second drawing is taken RELATIVE to
    # its own centre, so the molecule turns where it stands instead of
    # sliding across the page to where that drawing happens to sit.
    resid = {}
    for i, k in enumerate(keys):
        b = pairs.get(k)
        if b is not None and b in B.nodes:
            resid[k] = (np.asarray(B.nodes[b]["p"], float) - cb2) - land[i, :2]

    at = ca2 if not travel else ca2 * (1.0 - t) + cb2 * t
    pos, dep = {}, {}
    for i, k in enumerate(keys):
        p = here[i, :2] + at + float(t) * resid.get(k, np.zeros(2))
        pos[k] = (float(p[0]), float(p[1]))
        dep[k] = FRONT * float(here[i, 2])
    out = _placed(A, pos, dep)
    if colors:
        blend_colors(out, colors, t)
    if glyphs:
        blend_labels(out, glyphs, t)
    if fades:
        fade_out(out, fades, t)
    if stereo:
        dissolve_stereo(out, stereo, t)
    if labels:
        slide_hydrogen(out, labels, t)
    land_labels(out, B, pairs, t)
    return out



def land_labels(out, B, pairs, t, ends=1e-3):
    """At the very end of a turn, write the labels the target drawing has.

    A label's TEXT cannot be interpolated - "NH" and "HN" are one group
    written for a bond arriving from either side - so a turn carries the
    starting drawing's wording throughout and lets the sliding hydrogen
    convey the change.  That leaves the last frame one glyph-order away
    from the drawing it lands on, which shows as a flicker where a turn
    hands over to a reaction on the same page.  The final frame adopts
    the target's labels instead, in place.
    """
    if float(t) < 1.0 - ends:
        return
    for a, b in pairs.items():
        lb = B.nodes[b]["label"] if b in B.nodes else None
        la = out.nodes[a]["label"] if a in out.nodes else None
        # The reader stores a label as WRITTEN and flips the glyph order
        # at drawing time from its alignment, so two drawings of the same
        # group hold identical text and differ only in that flag.
        if not lb or not la:
            continue
        if (lb["text"], lb["align"]) == (la["text"], la["align"]):
            continue
        off = (np.asarray(out.nodes[a]["p"], float)
               - np.asarray(B.nodes[b]["p"], float))
        box, anc = lb["bbox"], lb["anchor"]
        out.nodes[a] = dict(out.nodes[a], label=dict(
            lb,
            bbox=[box[0] + off[0], box[1] + off[1],
                  box[2] + off[0], box[3] + off[1]],
            anchor=(anc[0] + off[0], anc[1] + off[1])))


def _placed(A, pos, dep):
    """A copy of depiction A with its atoms moved to `pos` at depth `dep`."""
    sc = copy.copy(A)
    sc.nodes, sc.bonds = {}, {}
    for k, n in A.nodes.items():
        m = dict(n)
        if k in pos:
            d = np.asarray(pos[k], float) - np.asarray(n["p"], float)
            m["p"] = pos[k]
            m["z"] = dep[k]
            if n["label"]:
                lab = dict(n["label"])
                x0, y0, x1, y1 = lab["bbox"]
                lab["bbox"] = [x0 + d[0], y0 + d[1], x1 + d[0], y1 + d[1]]
                lab["anchor"] = (n["label"]["anchor"][0] + d[0],
                                 n["label"]["anchor"][1] + d[1])
                m["label"] = lab
        sc.nodes[k] = m
    for k, b in A.bonds.items():
        m = dict(b)
        ends = [dep[x] for x in (b["b"], b["e"]) if x in dep]
        if ends:
            m["z"] = float(np.mean(ends))
        sc.bonds[k] = m
    return sc


def box(A, ft, ts, pad=8.0, centre=None):
    """A canvas that holds the molecule at every angle it passes through,
    so the drawing neither drifts nor is clipped mid-turn."""
    xs, ys = [], []
    for t in ts:
        x0, y0, x1, y1 = oriented(A, ft, t, centre=centre).extent()
        xs += [x0, x1]
        ys += [y0, y1]
    return (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)


def guide_plan(scenes):
    """The first turn in a file, with the whole chain alongside it."""
    stages = guide_stages(scenes)
    first = stages[0]
    return dict(first, stages=stages)


def numbering(scene, frag):
    """ChemDraw's own atom numbers, where a structure built from a crystal
    file carries them: an exact pairing that survives redrawing."""
    by = {n.get("id"): n.get("AtomNumber") for n in frag.iter("n")}
    return {k: by[k] for k in scene.nodes if by.get(k)}


def pair_solid(SA, SB):
    """Pair two 3D poses, by the most trustworthy means available.

    ChemDraw's own atom numbering comes first: it is exact and survives
    both redrawing and a change of pose.  Document order is next, checked
    against the element sequence.  Position is never used - two poses
    turned far apart cannot be paired geometrically, which is the whole
    difficulty.
    """
    na = {k: v["number"] for k, v in SA.nodes.items() if v.get("number")}
    nb = {k: v["number"] for k, v in SB.nodes.items() if v.get("number")}
    if na and nb:
        inv = {v: k for k, v in nb.items()}
        nm = {k: inv[v] for k, v in na.items() if v in inv}
        if len(nm) >= 0.8 * min(len(SA.nodes), len(SB.nodes)):
            return nm, "ChemDraw atom numbering"
    try:
        ka, kb, _, _ = correspondence(SA, SB)
        return dict(zip(ka, kb)), "document order"
    except ValueError:
        nm = complete(SA, SB, _seed_by_element(SA, SB))
        if len(nm) < 0.8 * min(len(SA.nodes), len(SB.nodes)):
            raise ValueError(
                "cannot pair the two 3D poses: they carry no atom "
                "numbering, differ in atom count or element order, and "
                "poses this far apart cannot be matched geometrically. "
                "Supply a mapping for them.")
        return nm, "connectivity"


def pair_drawn(DA, DB, SA, SB, solid_pairs):
    """Pair the two hand-drawn depictions, through the 3D pair.

    Matching the drawn pair to each other directly is the same hard
    problem as matching the two poses: they are far apart.  But each drawn
    depiction sits in roughly the pose it copies, so it matches THAT
    geometrically, and the 3D pair is already paired exactly.  Composing
    the three is far stronger than the direct match.
    """
    m_a = complete(DA, SA, mo.match_nodes(DA, SA))
    m_b = complete(DB, SB, mo.match_nodes(DB, SB))
    inv_b = {v: k for k, v in m_b.items()}
    nm = {a: inv_b[solid_pairs[s]] for a, s in m_a.items()
          if s in solid_pairs and solid_pairs[s] in inv_b}
    nm = complete(DA, DB, nm)
    direct = complete(DA, DB, mo.match_nodes(DA, DB))
    if len(mo.match_bonds(DA, DB, direct)) > len(mo.match_bonds(DA, DB, nm)):
        return direct, m_a, "direct geometric match"
    return nm, m_a, "composed through the 3D pair"


def _seed_by_element(A, B):
    """A starting pair for connectivity matching: the rarest element that
    appears exactly once in each drawing, with matching degree."""
    nbA, nbB = mo.adj(A), mo.adj(B)
    from collections import Counter
    ca = Counter((A.nodes[k].get("element"), len(nbA[k])) for k in A.nodes)
    cb = Counter((B.nodes[k].get("element"), len(nbB[k])) for k in B.nodes)
    for key, n in sorted(ca.items(), key=lambda kv: kv[1]):
        if n == 1 and cb.get(key) == 1:
            a = next(k for k in A.nodes
                     if (A.nodes[k].get("element"), len(nbA[k])) == key)
            b = next(k for k in B.nodes
                     if (B.nodes[k].get("element"), len(nbB[k])) == key)
            return {a: b}
    return {}


def fit_from(SA, SB, pairs):
    """The rotation carrying pose SA onto pose SB, over a given pairing."""
    ks = [k for k in pairs if SA.nodes[k].get("xyz") is not None
          and SB.nodes[pairs[k]].get("xyz") is not None]
    P = np.array([SA.nodes[k]["xyz"] for k in ks], float)
    Q = np.array([SB.nodes[pairs[k]]["xyz"] for k in ks], float)
    pc, qc = P.mean(0), Q.mean(0)
    H = (P - pc).T @ (Q - qc)
    U, _, Vt = np.linalg.svd(H)
    d = float(np.sign(np.linalg.det(Vt.T @ U.T))) or 1.0
    R = Vt.T @ np.diag([1.0, 1.0, d]) @ U.T
    rmsd = float(np.sqrt((((P - pc) @ R.T - (Q - qc)) ** 2).sum(1).mean()))
    radius = float(np.linalg.norm(P - pc, axis=1).mean())
    ax, ang = axis_angle(R)
    return dict(R=R, axis=ax, angle=ang, rmsd=rmsd, radius=radius,
                reflected=d < 0, n=len(ks), keys_a=ks,
                centre=pc, target_centre=qc)


# ---- which side the hydrogen of an OH or NH sits on ---------------------
# These affect nothing but the labels.  The motion - the rotation, the
# borrowed depth, the correction - is untouched by everything below.

def flippable(lab):
    """True for a label whose hydrogen has a side to be on.

    "NH" and "OH" are drawn with the H on whichever side faces away from
    the structure, so the side has to be chosen afresh as the molecule
    turns.  A lone "H" is a substituent in its own right, and a
    single-token label like "Me" has nothing to reorder.
    """
    if not lab:
        return False
    toks = cs._TOKEN.findall(lab["text"])
    return len(toks) > 1 and any(tk == "H" for tk in toks)


def label_side(sc, nb, k):
    """Mean direction of the bonds at this atom, in the current view."""
    p = np.asarray(sc.nodes[k]["p"], float)
    d = [np.asarray(sc.nodes[m]["p"], float) - p
         for m in nb[k] if m in sc.nodes]
    return float(np.mean(d, axis=0)[0]) if d else 0.0



glyph_centres = cs.glyph_centres

def hydrogen_slide(A, B, pairs, front=()):
    """How each flippable hydrogen travels from one side to the other.

    ChemDraw centres the label on its HETEROATOM glyph - the anchor sits
    half that glyph's width to one side of the atom, whichever way round
    the label is written.  So the N or O is already pinned to the point
    the bonds meet, and only the H has anywhere to go: it slides across,
    passing behind the heteroatom, and arrives on the far side.  Moving
    the label as one box instead is what makes the N appear to jump.
    """
    slide = {}
    for k in A.nodes:
        la = A.nodes[k]["label"]
        if not flippable(la):
            continue
        b = pairs.get(k)
        lb = B.nodes[b]["label"] if b in B.nodes else None
        if not flippable(lb):
            continue
        toks = cs._TOKEN.findall(la["text"])
        hy = [i for i, tk in enumerate(toks) if tk == "H"]
        if len(hy) != 1:
            continue
        hetero = "".join(tk for i, tk in enumerate(toks) if i != hy[0])
        pa = np.asarray(A.nodes[k]["p"], float)
        pb = np.asarray(B.nodes[b]["p"], float)
        # each end measured on its OWN drawing: the two may differ by a
        # hundredth of a point, and one turn's last frame has to match the
        # next turn's first exactly
        width = float(la["bbox"][2] - la["bbox"][0])
        width_b = float(lb["bbox"][2] - lb["bbox"][0])
        base = float(la["anchor"][1] - pa[1])
        base_b = float(lb["anchor"][1] - pb[1])
        # H sits half the whole label's width from the atom, on the side
        # away from the structure; the drawn alignment says which side.
        # A label that does not swap sides is still drawn as two glyphs,
        # with nowhere to travel: were it left as one string, the glyphs
        # would step by a fraction of a point at the seam between one
        # turn and the next, where the two representations meet.
        # measured from the drawn layout, so the split glyphs sit exactly
        # where the one-string rendering puts them at either end
        ga, gb = glyph_centres(la, pa), glyph_centres(lb, pb)
        start = ga.get("H", 0.5 * width)
        end = gb.get("H", 0.5 * width_b)
        slide[k] = dict(
            hetero=hetero, base=base, base_b=base_b, start=start,
            end=end, hetero_a=ga.get(hetero, 0.0), hetero_b=gb.get(hetero, 0.0),
            front=la["text"] in front,
            margin=float(A.doc["MarginWidth"]),
            box_a=[la["bbox"][0] - pa[0], la["bbox"][1] - pa[1],
                   la["bbox"][2] - pa[0], la["bbox"][3] - pa[1]],
            box_b=[lb["bbox"][0] - pb[0], lb["bbox"][1] - pb[1],
                   lb["bbox"][2] - pb[0], lb["bbox"][3] - pb[1]])
    return slide


def slide_hydrogen(sc, slide, t, ends=1e-3):
    """Place the glyphs of each flippable label for this frame.

    At either end of a turn the hydrogen has arrived and the label is
    simply the string the drawing holds, so it is left alone there: split
    into two glyphs it renders a hair differently from the same label
    drawn normally, which would show as a flicker where a turn hands over
    to a reaction on the same page.
    """
    t = float(t)
    if t <= ends or t >= 1.0 - ends:
        return
    for k, g in slide.items():
        if k not in sc.nodes or not sc.nodes[k]["label"]:
            continue
        p = np.asarray(sc.nodes[k]["p"], float)
        off = g["start"] * (1.0 - t) + g["end"] * t
        base = g["base"] * (1.0 - t) + g.get("base_b", g["base"]) * t
        lab = dict(sc.nodes[k]["label"])
        # The heteroatom is painted first and the H a hair above it, so the
        # H travels IN FRONT: its own thin white clearance separates the two
        # where they overlap, the way a bond crossing in front reads.
        # How much the two glyphs overlap, 0 apart and 1 superimposed.
        over = 1.0 - min(1.0, abs(off) / max(0.5 * abs(g["start"]), 1e-6))
        h = dict(text="H", anchor=(p[0] + off, p[1] + base),
                 just="Center")
        if g["front"]:
            # In front, the H needs a white pocket the width of a bond
            # crossing rather than the thin clearance a label keeps from
            # its neighbours: at 0.45 pt it merely slices the heteroatom
            # into arcs and the two read as one broken glyph.  The pocket
            # opens as they overlap and closes again.
            h["dz"] = +1e-4
            h["clearance"] = cs.LABEL_CLEARANCE + over * max(
                0.0, g["margin"] - cs.LABEL_CLEARANCE)
        else:
            # Behind, depth alone is not enough - the heteroatom's own
            # clearance is narrower than the H, so its edges stick out
            # either side - so the H fades out as it goes under.
            h["dz"] = -1e-4
            h["alpha"] = float(max(0.0, 1.0 - over))
        het = (g.get("hetero_a", 0.0) * (1.0 - t)
               + g.get("hetero_b", g.get("hetero_a", 0.0)) * t)
        lab["parts"] = [
            dict(text=g["hetero"], anchor=(p[0] + het, p[1] + base),
                 just="Center", dz=0.0),
            h,
        ]
        bx = [g["box_a"][i] * (1.0 - t) + g["box_b"][i] * t for i in range(4)]
        lab["bbox"] = [p[0] + bx[0], p[1] + bx[1], p[0] + bx[2], p[1] + bx[3]]
        sc.nodes[k] = dict(sc.nodes[k], label=lab)


def color_plan(A, B, pairs):
    """Start and end colour for every paired bond and label.

    The two drawings need not use the same greys - a highlight in one may
    be black in the other - so a colour is carried across rather than held
    at the first drawing's value for the whole turn.
    """
    plan = {"bonds": {}, "labels": {}}
    for ka, kb in mo.match_bonds(A, B, pairs).items():
        ca, cb = A.rgb(A.bonds[ka]["color"]), B.rgb(B.bonds[kb]["color"])
        if ca != cb:
            plan["bonds"][ka] = (ca, cb)
    for ka, kb in pairs.items():
        la = A.nodes[ka]["label"]
        lb = B.nodes[kb]["label"] if kb in B.nodes else None
        if la and lb:
            ca, cb = A.rgb(la["color"]), B.rgb(lb["color"])
            if ca != cb:
                plan["labels"][ka] = (ca, cb)
    return plan


def blend_colors(sc, plan, t):
    """Set this frame's colour on every element whose colour changes."""
    t = float(t)
    mix = lambda ca, cb: tuple(ca[i] * (1.0 - t) + cb[i] * t for i in range(3))
    for k, (ca, cb) in plan["bonds"].items():
        if k in sc.bonds:
            sc.bonds[k] = dict(sc.bonds[k], color=mix(ca, cb))
    for k, (ca, cb) in plan["labels"].items():
        if k in sc.nodes and sc.nodes[k]["label"]:
            sc.nodes[k] = dict(sc.nodes[k],
                               label=dict(sc.nodes[k]["label"],
                                          color=mix(ca, cb)))


def flatten_hydrogens(sc, depth):
    """Put every lone hydrogen in the plane of the drawing.

    A depth borrowed from the crystal can make a bond much LONGER in 3D
    than it looks on the page, and turning the molecule swings that hidden
    length into view - one C-H here grew from 14.4 to 31.9 pt.  Giving a
    terminal hydrogen its carbon's own depth means the bond is exactly as
    long as it is drawn, so it can only foreshorten, and its direction
    barely changes.  Nothing but lone hydrogens is affected.
    """
    nb = mo.adj(sc)
    out = dict(depth)
    for k, nd in sc.nodes.items():
        lab = nd["label"]
        if not lab or lab["text"] != "H" or len(nb.get(k, ())) != 1:
            continue
        other = next(iter(nb[k]))
        if other in depth:
            out[k] = depth[other]
    return out


def stereo_plan(A, B, pairs):
    """Bonds the two depictions draw differently.

    Going from a flat structure to a three-dimensional one, a wedge or a
    hash becomes an ordinary line.  There is no halfway shape - a triangle
    cannot be half a line - so the two renderings are cross-dissolved
    instead of interpolated.
    """
    plan = {}
    for ka, kb in mo.match_bonds(A, B, pairs).items():
        da = A.bonds[ka].get("display", "Solid")
        db = B.bonds[kb].get("display", "Solid")
        if da == db:
            continue
        same = pairs.get(A.bonds[ka]["b"]) == B.bonds[kb]["b"]
        plan[ka] = (da, db, bool(same))
    return plan


def dissolve_stereo(sc, plan, t):
    """Paint both renderings of such a bond, with complementary opacity."""
    f = mo.ramp(float(t), 0.0, 1.0)
    for k, (da, db, same) in list(plan.items()):
        if k not in sc.bonds:
            continue
        b = sc.bonds[k]
        sc.bonds[k] = dict(b, display=da, alpha=(1.0 - f) * b.get("alpha", 1.0))
        gh = dict(b, display=db, alpha=f * b.get("alpha", 1.0))
        if not same:
            # a wedge points from its narrow end, so a bond the second
            # drawing runs the other way has its ends swapped
            gh["b"], gh["e"] = b["e"], b["b"]
        sc.bonds[k + ":to"] = gh


def fade_plan(A, pairs):
    """Atoms of the first drawing that the second one does not have."""
    gone = {k for k in A.nodes if k not in pairs}
    return {"nodes": gone,
            "bonds": {k for k, b in A.bonds.items()
                      if b["b"] in gone or b["e"] in gone}}


def fade_out(sc, plan, t):
    """Dissolve an atom that the second drawing does not have.

    It still turns with the rest - it is part of the same object - and
    fades as it goes, on the same eased schedule a morph uses for a bond
    that breaks.
    """
    a = 1.0 - mo.ramp(float(t), 0.0, 1.0)
    for k in plan["bonds"]:
        if k in sc.bonds:
            sc.bonds[k] = dict(sc.bonds[k],
                               alpha=a * sc.bonds[k].get("alpha", 1.0))
    for k in plan["nodes"]:
        if k in sc.nodes and sc.nodes[k]["label"]:
            sc.nodes[k] = dict(sc.nodes[k],
                               label=dict(sc.nodes[k]["label"], alpha=a))


def guide_stages(scenes):
    """One file's columns, left to right, as a chain of turns.

    A column is a 3D pose and, where the file has one, a hand-drawn
    depiction of the same orientation beneath it.  N columns give N - 1
    turns, each measured on its own pair of poses, so a file can hold a
    whole sequence of reorientations rather than a single one.
    """
    mid = lambda s: 0.5 * (s.extent()[0] + s.extent()[2])
    solid = sorted((s for s in scenes if count_3d(s) >= MIN_ATOMS), key=mid)
    drawn = sorted((s for s in scenes if count_3d(s) == 0
                    and len(s.nodes) >= MIN_ATOMS), key=mid)
    if len(solid) < 2:
        raise ValueError(
            f"found {len(solid)} depiction(s) carrying 3D coordinates; a "
            "rotation needs two poses of one molecule to measure it from")
    # a drawing belongs to the pose it sits under, judged on column centre
    gaps = [mid(solid[i + 1]) - mid(solid[i]) for i in range(len(solid) - 1)]
    tol = 0.5 * min(gaps) if gaps else float("inf")
    below, taken = {}, set()
    for s in solid:
        best = None
        for j, d in enumerate(drawn):
            if j in taken:
                continue
            gap = abs(mid(d) - mid(s))
            if best is None or gap < best[0]:
                best = (gap, j, d)
        if best is not None and best[0] <= tol:
            below[id(s)] = best[2]
            taken.add(best[1])
    stages = []
    for i in range(len(solid) - 1):
        SA, SB = solid[i], solid[i + 1]
        DA, DB = below.get(id(SA)), below.get(id(SB))
        if DA is not None and DB is not None:
            stages.append(dict(mode="guided", A=DA, B=DB, solid=(SA, SB)))
        else:
            stages.append(dict(mode="3d", A=SA, B=SB, solid=(SA, SB)))
    return stages


def label_plan(A, B, pairs):
    """Each paired label's geometry in both drawings, relative to its atom.

    A label is carried rigidly with its atom, which leaves it wearing the
    FIRST drawing's metrics for the whole turn.  Where the two drawings
    write a label slightly differently - a baseline a hundredth of a point
    apart, a different size - the last frame of one turn then fails to
    match the first frame of the next.  So the offset is interpolated,
    exactly as a morph does it.
    """
    plan = {}
    for ka, kb in pairs.items():
        la = A.nodes[ka]["label"]
        lb = B.nodes[kb]["label"] if kb in B.nodes else None
        if not la or not lb:
            continue
        pa = np.asarray(A.nodes[ka]["p"], float)
        pb = np.asarray(B.nodes[kb]["p"], float)
        rel = lambda lab, p: dict(
            bbox=[lab["bbox"][0] - p[0], lab["bbox"][1] - p[1],
                  lab["bbox"][2] - p[0], lab["bbox"][3] - p[1]],
            anchor=[lab["anchor"][0] - p[0], lab["anchor"][1] - p[1]],
            size=float(lab["size"]), just=lab["just"])
        # every paired label, not only the ones that differ: all of them
        # are then drawn by the same convention in every turn, so none
        # changes its rendering at the seam between one turn and the next
        plan[ka] = (rel(la, pa), rel(lb, pb))
    return plan


def blend_labels(sc, plan, t):
    """Place each paired label at its interpolated offset from its atom."""
    t = float(t)
    mix = lambda u, v: [u[i] * (1.0 - t) + v[i] * t for i in range(len(u))]
    for k, (ga, gb) in plan.items():
        if k not in sc.nodes or not sc.nodes[k]["label"]:
            continue
        p = np.asarray(sc.nodes[k]["p"], float)
        bx = mix(ga["bbox"], gb["bbox"])
        an = mix(ga["anchor"], gb["anchor"])
        # Each drawing's OWN justification and anchor, so either end of
        # the turn is exactly the structure as drawn.  Justification is
        # discrete and cannot be averaged here - where the two disagree
        # the canvas is handed both and blends them itself, since only it
        # knows how wide it lays the text out.
        lab = dict(sc.nodes[k]["label"],
                   bbox=[p[0] + bx[0], p[1] + bx[1], p[0] + bx[2], p[1] + bx[3]],
                   anchor=(p[0] + ga["anchor"][0] * (1.0 - t)
                           + gb["anchor"][0] * t, p[1] + an[1]),
                   just=ga["just"],
                   size=ga["size"] * (1.0 - t) + gb["size"] * t)
        if gb["just"] != ga["just"]:
            lab["anchor"] = (p[0] + ga["anchor"][0], p[1] + an[1])
            lab["blend"] = (gb["just"], p[0] + gb["anchor"][0], t)
        else:
            lab.pop("blend", None)
        sc.nodes[k] = dict(sc.nodes[k], label=lab)


def build_turns(scenes, style, flip_h=True, flat_h=True, blend_labels=True,
                guide=False, stages=None, centre=None):
    """Every turn a file holds, as a pose function and a note apiece.

    This is where a turn is actually assembled - the pairing, the borrowed
    depth, the colours, the stereo dissolve, the sliding hydrogens.  The
    command line and the browser both come through here, so a turn renders
    the same either way.
    """
    stages = stages or guide_stages(scenes)
    if guide:
        stages = [dict(s, mode="3d", A=s["solid"][0], B=s["solid"][1])
                  for s in stages]
    # Every turn happens in the same place on the canvas.  A scheme draws
    # its columns side by side, and a turn left at its own column would
    # make the molecule jump across the page between turns.
    if centre is None:
        first = stages[0]["A"]
        centre = np.asarray([first.nodes[k]["p"] for k in first.nodes],
                            float).mean(0)
    common = centre
    h_front = style.get("h_front", ("OH",))

    poses, notes = [], []
    for plan in stages:
        A, B = plan["A"], plan["B"]
        SA, SB = plan["solid"]
        solid_pairs, how_solid = pair_solid(SA, SB)
        ft = fit_from(SA, SB, solid_pairs)
        note = dict(mode=plan["mode"],
                    measured_from=f"{len(solid_pairs)} atoms paired by "
                                  f"{how_solid}",
                    rotation_deg=round(float(np.degrees(ft["angle"])), 2),
                    axis=[round(float(v), 4) for v in ft["axis"]],
                    fit_rmsd_pt=round(ft["rmsd"], 4),
                    reflected=bool(ft["reflected"]))
        if plan["mode"] == "guided":
            # the drawn pair moves; the 3D pair only says how
            pairs, to_pose, how_drawn = pair_drawn(A, B, SA, SB, solid_pairs)
            # A reorientation can be paired by hand too.  Where the drawing
            # changes as it turns - a group drawn out in one orientation and
            # collapsed in the other - the automatic pairing has little to
            # go on, so an explicit one replaces it.  The 3D pair still
            # supplies the axis and the depth; only which atom becomes
            # which is taken from the given mapping.
            given = plan.get("pairs")
            if given:
                pairs = dict(given)
                how_drawn = "given by hand"
            depth = borrow_depth(A, SA, to_pose)
            note["not_turning"] = len(A.nodes) - len(depth)
            if flat_h:
                depth = flatten_hydrogens(A, depth)
            colors = color_plan(A, B, pairs)
            glyphs = label_plan(A, B, pairs) if blend_labels else {}
            stereo = stereo_plan(A, B, pairs)
            fades = fade_plan(A, pairs)
            labels = hydrogen_slide(A, B, pairs, h_front) if flip_h else {}
            note.update(
                drawn_pairing=how_drawn,
                drawn_atoms=f"{len(pairs)} of {len(A.nodes)}",
                drawn_bonds=f"{len(mo.match_bonds(A, B, pairs))} of "
                            f"{len(A.bonds)}",
                colours_travelling=len(colors["bonds"]) + len(colors["labels"]),
                labels_reshaping=len(glyphs),
                stereo_dissolving=sorted(
                    f"{A.nodes[A.bonds[k]['b']]['atom_id']}-"
                    f"{A.nodes[A.bonds[k]['e']]['atom_id']} "
                    f"{v[0]} to {v[1]}" for k, v in stereo.items()),
                fading_out=sorted(A.nodes[k]["atom_id"]
                                  for k in fades["nodes"]),
                flipping_labels=sorted(
                    A.nodes[k]["label"]["text"]
                    + (" (H in front)" if labels[k]["front"] else " (H behind)")
                    for k in labels))
            poses.append(lambda t, A=A, B=B, pairs=pairs, depth=depth, ft=ft,
                         labels=labels, colors=colors, stereo=stereo,
                         fades=fades, glyphs=glyphs, centre=common:
                         guided(A, B, pairs, depth, ft["axis"], ft["angle"], t,
                                centre_a=centre, centre_b=None,
                                labels=labels, colors=colors, stereo=stereo,
                                fades=fades, glyphs=glyphs))
        else:
            colors = color_plan(A, B, solid_pairs)
            glyphs = label_plan(A, B, solid_pairs) if blend_labels else {}
            labels = (hydrogen_slide(A, B, solid_pairs, h_front)
                      if flip_h else {})
            note.update(
                colours_travelling=len(colors["bonds"]) + len(colors["labels"]),
                labels_reshaping=len(glyphs),
                flipping_labels=sorted(
                    A.nodes[k]["label"]["text"]
                    + (" (H in front)" if labels[k]["front"] else " (H behind)")
                    for k in labels))
            poses.append(lambda t, A=A, ft=ft, labels=labels, colors=colors,
                         glyphs=glyphs, centre=common:
                         oriented(A, ft, t, centre=centre, labels=labels,
                                  colors=colors, glyphs=glyphs))
        notes.append(note)
    return poses, notes
