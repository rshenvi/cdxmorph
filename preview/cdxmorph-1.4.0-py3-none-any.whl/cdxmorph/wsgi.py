"""WSGI entry point for a hosted cdxmorph.

A production server is handed an application object, not a command, so
this exposes one built from the environment:

    gunicorn 'cdxmorph.wsgi:app'

CDXMORPH_DATA    where uploads and rendered files live.  Point it at a
                 volume that survives a restart, or accept the default
                 temporary directory and lose in-flight sessions on
                 deploy.
CDXMORPH_MAX_UPLOAD  bytes; the default is 8 MB, ample for a drawing.
"""

import os

from .web import create_app, MAX_UPLOAD

app = create_app(root=os.environ.get("CDXMORPH_DATA"),
                 max_upload=int(os.environ.get("CDXMORPH_MAX_UPLOAD",
                                               MAX_UPLOAD)))
