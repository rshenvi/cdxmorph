# cdxmorph

Animate one ChemDraw drawing into another as line art.

Nothing here interprets chemistry. A `.cdxml` file is read as positioned
line segments and text with an explicit depth per element; the two drawings
are matched, interpolated, and repainted every frame using ChemDraw's own
occlusion rules. No force field, no valence model, no RDKit in the render
path.

## Install

    pip install .            # or: pip install -e .
    pip install '.[mp4]'     # adds imageio-ffmpeg, for MP4 output

That puts a `cdxmorph` command on your path, so every example below can
drop the `python -m` prefix. Requires `numpy`, `scipy`, `matplotlib`,
`pillow`.

To run without installing, put the directory *containing* `cdxmorph/` on
`PYTHONPATH` — not `cdxmorph/` itself:

    PYTHONPATH=/path/to/parent python -m cdxmorph render ...

Being in that directory is usually enough on its own, but some interpreters
are launched with the working directory stripped from the import path, in
which case the explicit `PYTHONPATH` is required.

## Use

    python -m cdxmorph render start.cdxml product.cdxml -o morph.gif
    python -m cdxmorph render start.cdxml product.cdxml -o morph.gif \
        -c config.json --duration 3 --fps 24 --width 1200 \
        --keyframes filmstrip.png

    python -m cdxmorph editor start.cdxml product.cdxml -o editor.html
    python -m cdxmorph still  start.cdxml -o start.png
    python -m cdxmorph check  start.cdxml product.cdxml -c config.json

Output format follows the extension: `.gif`, `.mp4`, or `.png` for a
numbered frame sequence.

`check` validates a config and reports what the morph will do — how many
atoms and bonds carry over, which bonds break and form — without rendering.
Run it before a long render.

## Browser interface

    pip install 'cdxmorph[web]'
    cdxmorph serve                      # http://127.0.0.1:5000
    cdxmorph serve --open --port 0      # pick a free port, open a browser

`--port 0`, or a port already in use, makes it ask the operating system
for a free one, so two copies can run at once. Where the machine refuses
to open a connection at all -- some managed computers block it -- it says
so in a sentence and suggests an explicit port, rather than failing with
a stack trace.

Upload a scheme file or a start/product pair, and the site walks through the
same loop as the command line: it shows what the automatic match achieved per
transition, lets you correct any transition by clicking atom pairs, then
renders a GIF or MP4 to preview and download.

Every visitor gets an opaque session folder holding only their upload,
mapping and output. Session ids are validated against a fixed pattern, the
uploaded filename is never used as a path, only the rendered file is
servable, and folders are swept after six hours. Uploads are capped at 8 MB
and a single render at 600 frames.

### Deploying it

The app is a plain WSGI callable, so anything that runs Flask will serve it:

    gunicorn -w 4 -t 300 'cdxmorph.web:create_app()'

Three things to size for. Rendering is CPU-bound and synchronous — roughly a
second per hundred frames per worker — so give each worker a request timeout
well above the frame ceiling and run one worker per core. Sessions are
**files on local disk**, so either pin a visitor to one worker, point
`CDXMORPH_DATA` at shared storage, or run a single machine. And a public
instance wants its own limits: lower `MAX_FRAMES`, `MAX_UPLOAD` and `MAX_AGE`
in `web.py`, and put a rate limiter in front, since one request can occupy a
core for a minute.

## The browser interface

    cdxmorph serve --open

Upload one scheme file, or two files, and the page reports what pairs
with what, lets a pairing be corrected by hand, and renders. When the
uploaded file carries 3D coordinates the page also offers to animate the
molecule **turning** rather than the structures changing, with the same
timing and size controls; the length asked for is then one pass, and a
ping-pong tick box adds the way back. Both the page and the command line
assemble a turn through the same code, so a clip made either way is the
same animation.

## Reaction schemes

A single `.cdxml` holding several structures separated by arrows animates
straight through, 1 → 2 → 3 → …:

    cdxmorph render scheme.cdxml -o morph.gif --pause 0.3

Two structures drawn side by side with no arrow between them are one
structure as far as the animation is concerned - the scheme names them
together as one side of its arrow, and they move together into whatever
it points at. A fragment no arrow mentions keeps its place in reading
order after the chain, so a final depiction joined by an equivalency
symbol animates from the structure above it.

Order comes from the file. ChemDraw records each arrow as a reaction step
naming its reactant and product fragment, so the sequence is read rather
than guessed; without a scheme the structures are taken left to right.
`--pause` holds on each intermediate. Two separate files still work and
behave exactly as before.

Schemes draw their structures side by side, so each one is superimposed on
the previous by translation — the molecule morphs in place instead of
marching across the page. Only the page offset is removed: any relative
rotation between two drawings is left alone, so it animates as a real
rotation rather than being quietly fitted away.

Each arrow is a separate transition with its own mapping, so `editor`
writes one page per transition (`..._stage1.html`, `..._stage2.html`) and
`check` reports each one separately.

## Mapping

The automatic matcher aligns the two drawings and pairs atoms by position,
label text, and neighbourhood consistency. It will not pair two atoms whose
labels differ, so `OH` onto `O` is a call only you can make.

`editor` writes a self-contained HTML page: both structures drawn live with
every atom numbered. Click an atom on the left, then its partner on the
right. Bonds that break turn red, bonds that form turn green, and the header
tallies them as you go — minimising red is the goal, since every unpaired
bond has to fade through the midpoint. Copy the JSON out of the box at the
bottom.

## Config

Written in the atom numbers the editor shows, and in the **starting**
structure's numbers wherever possible, so it survives a redraw of the
product.

```json
{
  "pairs":  {"14": "2", "15": "17"},
  "exact":  false,
  "shifts": [["14-17", "21"]],
  "timing": {"duration": 3.2, "fps": 24, "hold": 0.4, "ease": "smoothstep"},
  "style":  {"scale": 6.0, "dpi": 150, "pad": 8.0, "label_clearance": 0.45}
}
```

- `pairs` — starting atom to product atom. Must be one-to-one; a product
  atom claimed twice is rejected by name.
- `exact` — `true` uses your pairing verbatim; `false` (default) lets the
  matcher fill in whatever you did not pin.
- `shifts` — 1,2-shifts. `["14-17", "21"]` means bond 14–17 keeps its 14 end
  and walks its 17 end along the 17–21 bond onto 21. The terminus is
  interpolated between the two atoms' own trajectories, so it rides that
  bond even as the bond itself moves, instead of flying across open space.
  The product bond it becomes is derived from `pairs`, so no product atom is
  named here.
- `hold` — seconds held at each end before and after the transition.
- `label_clearance` — white space around atom-label letterforms, in
  ChemDraw points. This is *not* `MarginWidth`: that governs where bonds
  attached to a label are trimmed and is read from the file.

Anything unpaired fades out or in. Broken bonds fade in place.

### Config for a sequence

With more than one arrow, per-transition settings go in a `stages` list of
exactly that many blocks. Everything outside `stages` — timing, style,
`pause` — applies to the whole run.

    {
      "pause": 0.3,
      "stages": [
        {"pairs": {"66": "1",  ...}, "shifts": [["66-70", "74"]]},
        {"pairs": {"1": "42",  ...}}
      ]
    }

Atom numbers are per structure, as shown in that stage's editor. A
top-level `pairs` on a multi-arrow file is rejected rather than silently
applied to the first transition only.

### Bonds that appear and disappear

A bond with no counterpart dissolves. Opacity follows a smoothstep, so it
eases away rather than ramping off a corner, and by default the fade spans
the whole transition: what leaves and what arrives are mirror images in
opacity and sum to 1 at every instant, so the drawing never thins out.
Measured on a transition with four bonds each way, total ink varies by
1.1% across the stage; with shorter, non-overlapping fades it dipped 8.4%.

    {"dissolve": 1.0}      whole-transition cross-dissolve (default)
    {"dissolve": 0.6}      shorter fades, fainter crossover between them

### Rotation out of the plane

A structure redrawn after rotating in three dimensions arrives as a
mirror image of the original, and no in-plane motion can reach it. The
matcher always tries both chiralities, so pairing still works. Animating
the turn itself is opt-in:

    {"flip": true}

With it on, a stage whose atoms fit a reflection distinctly better than a
rotation turns about the mirror line: the component across the axis
scales by cos(pi t). This is geometrically faithful but passes through an
edge-on view, where the structure is momentarily a line, so it is off by
default and worth looking at before committing to it.

### Lines that travel

A double bond that reorganises - a ring closing, a conjugated system
shifting along - normally has its inner line fade out on one bond and
fade in on the next. `slides` makes that line MOVE instead: it pivots
about the atom the two bonds share, or swings across onto a bond that
only the product has.

    {"slides": [["7-8", "4-7"], ["9-10", "8-9"], ["4-5", "5-10"]]}

Both members of a pair are atom pairs in STARTING-structure numbers.
The source must be a double bond. The target is named by its two atoms
rather than as a bond, so it may be a bond the start does not have -
which is what a ring closure needs. The target must exist in the
product, and `check` says so if it does not.

This is a drawing choice and nothing more. The program has no model of
electrons or mechanism; it moves a line from where you say to where you
say, and it is on you that the result means what you intend.

### Hashed wedges

The number of rungs follows from the spacing between them. ChemDraw's
own default of 2.1 pt puts seven on an ordinary bond, which is denser
than most figures want, so `hash_spacing` overrides it and defaults to
3.0 pt - five rungs on the same bond. Bond lengths are untouched; only
the rung spacing changes.

    {"style": {"hash_spacing": 3.0}}

Set it to `null` to use whatever the document specifies. The count is
fixed from the structure as drawn, so a bond that stretches during a
transition keeps its rungs rather than gaining one part-way.

### Matching lengths

`--duration` is the moving part only, so a scheme with more structures
runs longer. `--total` fixes the WHOLE clip instead - holds and pauses
come out of it - so animations of different schemes finish together and
can be played side by side:

    cdxmorph render scheme.cdxml -o morph.gif --total 5 --pause 0.3

Equivalently `{"timing": {"total": 5}}`. A total too short to leave room
to move is refused, with the time the holds alone need. The browser
interface asks for the total directly.

### Leaving an atom unpaired

`pairs` are FORCED pairs: the matcher takes them as fixed and then fills
in whatever else it can. So simply omitting an atom does not unpair it -
the matcher puts it back. To pair exactly what you name and nothing
else, add `exact`:

    {"pairs": {"1": "5", ...}, "exact": true}

Both editors write `exact` for you, because they open pre-filled with
the automatic match: what they hand back is the whole intended pairing,
and an atom you removed was removed on purpose. Hand-written configs
without `exact` keep the old behaviour, so a short list of corrections
still lets the matcher do the rest.

### Turning a molecule

`rotate` turns one drawing into another orientation of the same molecule.
Three things about labels and depth are worth knowing.

A label like `NH` or `OH` is centred on its *heteroatom* glyph, not on the
string, so the N or O stays exactly where the bonds meet and only the H
moves: it slides across and passes the heteroatom at the midpoint. Which
side of it the H passes is a style setting, because it reads differently
per label:

    {"style": {"h_front": ["OH"]}}

Those listed pass in front, widening their white pocket to a bond
crossing's margin so the heteroatom is cleanly interrupted rather than
sliced into arcs. Any other flippable label's H passes behind, fading out
as it goes under - behind, the heteroatom's own clearance is narrower than
the H and would leave its edges sticking out either side.

The clip ping-pongs by default. `--oneway 5` sets one pass start to
finish, holds and pauses included, so the way back adds the same again;
`--once` renders a single pass, and `--total` fixes the whole clip
instead. The hold on the final orientation is shared between the two
legs, so a cycle is slightly less than twice a one-way pass.

A file may hold more than one turn. Columns are read left to right - a 3D
pose with, where there is one, a hand-drawn depiction beneath it - and N
columns give N - 1 turns, run back to back with `--pause` holding on each
intermediate orientation. Every turn happens in the same place on the
canvas, since a scheme draws its columns side by side.

Going from a flat structure to a three-dimensional one, wedges and hashes
become ordinary lines. There is no halfway shape - a triangle cannot be
half a line - so the two renderings are cross-dissolved: the wedge fades
out as the plain line fades in, on the same eased schedule a morph uses
for a bond that breaks. An atom the next drawing does not have keeps
turning with the rest and dissolves as it goes.

Labels are carried to where the next drawing puts them. A label is moved
rigidly with its atom, which would otherwise leave it wearing the first
drawing's metrics for the whole turn: a label the two drawings write
slightly differently - a baseline a hundredth of a point apart, or a
group sitting on the other side of its atom - would then be out of place
at the end of the turn, and would step visibly at the seam between one
turn and the next. `--no-label-blend` keeps the old behaviour.

Colours travel from one drawing to the other. The two need not use the
same greys, so each paired bond and label is carried across rather than
held at the first drawing's value.

Lone hydrogens are placed in the plane of the drawing. A depth borrowed
from a crystal structure can make a bond much longer in 3D than it looks
on the page, and turning the molecule swings that hidden length into view
- one C-H grew from 14.4 to 31.9 pt. With the drawing's own depth it can
only foreshorten, and its direction barely changes. `--no-flat-h` keeps
the crystal's depth; `--no-flip-h` leaves every H on the side the first
drawing puts it.

## Pages that both turn and react

A page can hold two kinds of step, and one clip can play both.

An **equivalency sign** - ChemDraw's three short rules - between two
drawings means one molecule redrawn in another orientation, and animates
as a turn. A **reaction arrow** means one structure becoming another, and
animates as a morph. Order comes from the signs and arrows themselves.

A turn needs an axis and an angle, and the neatest way to supply them is
to draw the molecule twice **with 3D coordinates** - ChemDraw writes
those when a structure comes from a crystal file - and place each pose
directly ABOVE the drawing it corresponds to. Those poses are never
drawn: they only say how the drawing beneath them moves. A rigid fit
between two poses gives the rotation exactly, so nothing has to be
specified by hand.

    cdxmorph render page.cdxml -o page.gif

`render` takes this path only when the page holds BOTH a guided turn and
a reaction. A page whose equivalency signs have no poses above them keeps
its previous behaviour: the two drawings are matched by connectivity and
animated as a morph. `rotate` remains for a file that is only turns.

Known limit: on a mixed page each step is taken between one structure and
one other. A reagent joining mid-sequence - several fragments on one side
of an arrow - is handled by the plain morph path but not yet by this one.

## Occlusion

Every node and bond in a CDXML carries an explicit `Z`, so painter's order
is given, not inferred. Gaps are punched per frame from live geometry rather
than baked in, which is what keeps them correct for crossings that exist
only mid-morph.

Details that were arrived at by measuring against ChemDraw's own
`CrossingBonds` bookkeeping, and are easy to get wrong:

- The gap spans where the back stroke's **centreline** enters a band of
  half-width `w_front/2 + MarginWidth`. The back stroke's own width does not
  lengthen the gap.
- The covered extent is computed directly, not as `1/sin θ`. That closed
  form assumes a true intersection and badly overstates the span for two
  bonds that merely pass close.
- Labels clear a halo around the **letterforms**, not their bounding box. A
  bounding box swallows bonds passing under a wide glyph.
- A fragment too short to read as a bond is dropped — unless it is the piece
  still touching a labelled atom, because dropping that one leaves the atom
  floating free.

`check` reports drawn crossings against the file's declarations. Drawn but
not declared would mean invented occlusion; declared but not drawn is
usually stale bookkeeping from an earlier layout, where the strokes no
longer overlap.

### Depth is discrete, so flips must be scheduled

Interpolating two `Z` values makes the order flip at whatever instant the
numbers happen to cross. When two bonds sit adjacent in depth that instant
often falls in the middle of a crossing: the gap jumps from one bond to the
other and back, which reads as flicker.

`animate.plan_swaps` walks the timeline, finds every pair that changes
places, and defers each flip to the first moment the pair is not
overlapping. Detection has to cover the whole timeline, not just compare
`t=0` against `t=1` — a bond that breaks is gone by the end, and flips
cluster exactly where a bond is fading.

### Double-bond inner lines

The offset line stops short of the bonds leaving each end. The stopping
point is found geometrically — where the inner line would meet each
neighbour — and then backed off by `LineWidth + MarginWidth`, measured
perpendicular and divided by `sin θ` so shallow angles get the longer inset
they need. A fixed fractional inset is angle-blind and lets the line touch.

Both forms need it. The symmetric form (used where one end is terminal, as
in C=O) is easy to overlook: each of its two lines is trimmed only by the
neighbours on its own side, and not at all at the terminal atom.

Tunables at the top of `scene.py`: `LABEL_CLEARANCE`, `INNER_DEFAULT_INSET`,
`INNER_MAX_INSET`, `INNER_SIN_FLOOR`, `MIN_FRAGMENT`.

### The reader and the animator are separate paths

`scene.build_strokes` draws one static structure; `animate.assemble` builds
a frame. They implement the same occlusion rules over different geometry,
and a fix applied to one **will not** appear in the other. This has bitten
twice — a correct still image alongside an unchanged animation. Any change
to occlusion, trimming, or fragment handling belongs in both, sharing the
constants above so the two cannot drift.

## Speed

Roughly 30 ms per 1400 px frame end to end, about 15 ms of that rendering.
Three things account for it: frames are read straight out of the Agg buffer
instead of being round-tripped through an encoded PNG; one figure and a
small pool of `LineCollection`s are reused across frames, banded by depth so
painter's order stays exact; and GIF output is indexed against an exact
palette, which is both lossless and far faster than a nearest-colour search.

`-j N` renders frames across N processes. It falls back to one process with
a warning where the OS refuses the needed semaphores.

## Layout

| module | role |
|---|---|
| `scene.py` | CDXML reader, occlusion model, raster and SVG output |
| `animate.py` | matcher, interpolator, 1,2-shifts, per-frame assembly |
| `config.py` | config parsing and validation |
| `render.py` | reusable canvas, timeline, GIF/MP4/PNG encoders |
| `editor.py` | click-to-pair mapping editor |
| `cli.py` | command line |

The reader is the only part that knows about CDXML, so a `.cdx` binary or
SVG importer can be added without touching the animation code.
