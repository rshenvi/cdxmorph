"""Browser interface: upload ChemDraw files, pair the atoms, get an animation.

The rendering here is the same code the command line uses.  This module only
adds a session store, a few pages, and a JSON endpoint; nothing about how a
structure is drawn or animated lives in this file.

Each visitor gets an opaque session directory holding the uploaded CDXML, the
mapping as it is edited, and the rendered output.  Sessions never see each
other's files and are swept after `MAX_AGE`.

    from cdxmorph.web import create_app
    create_app().run()                    # or: cdxmorph serve
"""
import io
import json
import os
import re
import shutil
import time
import uuid

from flask import (Flask, abort, jsonify, redirect, request,
                   send_from_directory, url_for)

from . import animate as mo
from . import config as cfgmod
from . import editor as ed
from . import render as rd
from . import rotate as rot
import numpy as np

from . import scene as cs

MAX_UPLOAD = 8 * 1024 * 1024        # a drawing is tens of KB; this is generous
MAX_AGE = 6 * 3600                  # sweep idle sessions after six hours
MAX_FRAMES = 600                    # ceiling on a single render
SID_RE = re.compile(r"\A[0-9a-f]{32}\Z")


# ----------------------------------------------------------------- sessions

def _sid_dir(root, sid):
    """Validated session directory, or 404.  The id comes from the URL, so
    it is matched against a strict pattern rather than trusted."""
    if not SID_RE.match(sid or ""):
        abort(404)
    d = os.path.join(root, sid)
    if not os.path.isdir(d):
        abort(404)
    return d


def _sweep(root, max_age=MAX_AGE):
    now = time.time()
    try:
        names = os.listdir(root)
    except FileNotFoundError:
        return
    for name in names:
        d = os.path.join(root, name)
        try:
            if os.path.isdir(d) and now - os.path.getmtime(d) > max_age:
                shutil.rmtree(d, ignore_errors=True)
        except OSError:
            pass


def _state(d):
    with open(os.path.join(d, "state.json")) as fh:
        return json.load(fh)


def _save_state(d, st):
    tmp = os.path.join(d, "state.json.tmp")
    with open(tmp, "w") as fh:
        json.dump(st, fh, indent=1)
    os.replace(tmp, os.path.join(d, "state.json"))


def _page_path(d):
    """The single uploaded file's path, or None for several files."""
    st = _state(d)
    if len(st["files"]) != 1:
        return None
    return os.path.join(d, st["files"][0])


def _plan(d):
    """(drawn scenes, stages, guides) for the uploaded page, or None."""
    path = _page_path(d)
    if not path:
        return None
    try:
        return cs.page_stages(path)
    except Exception:
        return None


def _scenes(d, drawn_only=True):
    """The structures to animate.

    A drawing that carries 3D coordinates and sits above another is a
    POSE: it says how the drawing beneath it turns and is never animated
    itself.  Leaving it in the list is what made the browser try to map
    a crystal pose onto a flat structure.  Only a turn needs the poses,
    so only `drawn_only=False` returns them.
    """
    st = _state(d)
    if len(st["files"]) == 1:
        scenes = cs.parse_sequence(_page_path(d))
        if drawn_only:
            plan = _plan(d)
            if plan and plan[2] and plan[0]:
                return plan[0]
        return scenes
    return [cs.parse_cdxml(os.path.join(d, f)) for f in st["files"]]


# -------------------------------------------------------------------- pages

CSS = """
 body{font:14px/1.5 -apple-system,Segoe UI,Helvetica,sans-serif;margin:0;
      background:#fafafa;color:#222}
 header{padding:12px 18px;background:#fff;border-bottom:1px solid #ddd;display:flex;align-items:center;gap:16px}
.lab{margin-left:auto;line-height:0;opacity:.85}
.lab img{height:26px;width:auto;display:block}
 h1{font-size:16px;margin:0;font-weight:600}
 main{max-width:860px;margin:0 auto;padding:18px}
 .card{background:#fff;border:1px solid #ddd;border-radius:7px;padding:14px;
       margin-bottom:14px}
 table{border-collapse:collapse;width:100%;font-size:13px}
 th,td{text-align:left;padding:5px 8px;border-bottom:1px solid #eee}
 th{color:#666;font-weight:600}
 button,input[type=submit]{font:inherit;padding:6px 13px;border:1px solid #bbb;
        background:#fff;border-radius:5px;cursor:pointer}
 button:hover{background:#f0f0f0}
 button.go{background:#1b6ac9;border-color:#1b6ac9;color:#fff}
 button.go:hover{background:#155aad}
 label{display:inline-block;margin-right:14px;color:#444}
 input[type=number]{width:70px;font:inherit;padding:3px 5px;
        border:1px solid #ccc;border-radius:4px}
 select{font:inherit;padding:3px 5px;border:1px solid #ccc;border-radius:4px}
 a{color:#1b6ac9}
 .muted{color:#777;font-size:12px}
 .err{color:#b00}
"""


CREDIT = "Developed by Ryan Shenvi @ ShenviLab"


def _page(title, body):
    return (f"<!DOCTYPE html><html><head><meta charset=\"utf-8\">"
            f"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            f"<title>{title}</title><style>{CSS}</style></head><body>"
            f"<!-- {CREDIT} -->"
            f"<header><h1>{title}</h1>"
            f"<a class=\"lab\" href=\"https://www.shenvilab.org\" "
            f"title=\"{CREDIT}\" target=\"_blank\" rel=\"noopener\">"
            f"<img src=\"/static/shenvi-lab.png\" alt=\"Shenvi Laboratory\" "
            f"height=\"26\"></a></header>"
            f"<main>{body}</main></body></html>")


UPLOAD_BODY = """
<div class="card">
<p>Animate one ChemDraw drawing into another. Upload either a single
<code>.cdxml</code> holding a reaction scheme &mdash; several structures
separated by arrows, animated straight through &mdash; or two files, a start
and a product.</p>
<form method="post" action="{action}" enctype="multipart/form-data">
  <p><input type="file" name="files" accept=".cdxml,.xml" multiple required></p>
  <p><input type="submit" value="Upload"></p>
</form>
<p class="muted">Nothing is interpreted chemically: the file is read as
positioned lines and text with a depth per element, and repainted every frame
using ChemDraw's own occlusion rules. Files are deleted after six hours.</p>
{err}
</div>
"""


def _render_turn(d, sid, scenes, st, oneway, fps, pause, width, fmt, bounce):
    """Render the molecule turning, rather than the structures morphing.

    Same assembly the command line uses, so a clip made here and one made
    with `cdxmorph rotate` are the same animation.
    """
    style = cfgmod.style(st["config"])
    cs.LABEL_CLEARANCE = style["label_clearance"]
    cs.HASH_SPACING = style.get("hash_spacing")
    cs.GAP_SCALE = style.get("gap_scale", cs.GAP_SCALE)
    try:
        poses, notes = rot.build_turns(scenes, style)
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    rate = rd.gif_rate(fps) if fmt == "gif" else fps
    n_hold = int(round(pause * rate))
    try:
        # the length asked for is ONE pass; a ping-pong adds the way back
        seq, forward = rd.turn_sequence(
            len(poses), rate, n_hold, n_hold,
            cfgmod.timing(st["config"])["ease"], oneway=oneway, bounce=bounce)
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    if len(seq) > MAX_FRAMES:
        return jsonify(error=f"that would be over {MAX_FRAMES} frames; "
                             f"shorten the length or lower the fps"), 400
    # one canvas for every angle every turn passes through
    xs, ys = [], []
    for p in poses:
        for k in range(25):
            x0, y0, x1, y1 = p(k / 24.0).extent()
            xs += [x0, x1]
            ys += [y0, y1]
    box = (min(xs) - style["pad"], min(ys) - style["pad"],
           max(xs) + style["pad"], max(ys) + style["pad"])
    scale = width * 72.0 / (style["dpi"] * (box[2] - box[0]))
    t0 = time.time()
    r = rd.Renderer(box, scale=scale, dpi=style["dpi"])
    try:
        frames = [r.draw(cs.build_strokes(poses[si](t))) for si, t in seq]
    finally:
        r.close()
    name = f"morph.{fmt}"
    out = os.path.join(d, name)
    if fmt == "mp4":
        rd.write_mp4(frames, out, fps=fps)
    else:
        rd.write_gif(frames, out, fps=fps)
    h, wpx = frames[0].shape[:2]
    os.utime(d)
    return jsonify(
        url=url_for("out", sid=sid, name=name) + f"?v={int(time.time())}",
        name=name, fmt=fmt, frames=len(frames), size=f"{wpx}x{h}",
        seconds=round(time.time() - t0, 1), turns=len(poses),
        oneway_seconds=round(forward / rate, 3),
        cycle_seconds=round(len(seq) / rate, 3),
        rotation_deg=[n["rotation_deg"] for n in notes])



def _render_mixed(d, sid, st, total, fps, pause, width, fmt):
    """Render a page that both turns and reacts, as the command line does."""
    style = cfgmod.style(st["config"])
    cs.LABEL_CLEARANCE = style["label_clearance"]
    cs.HASH_SPACING = style.get("hash_spacing")
    cs.GAP_SCALE = style.get("gap_scale", cs.GAP_SCALE)
    try:
        funcs, notes, _ = rd.page_clip(_page_path(d), style, st["config"])
    except Exception as exc:
        return jsonify(error=str(exc)), 400
    rate = rd.gif_rate(fps) if fmt == "gif" else fps
    n_hold = int(round(pause * rate))
    n_core = int(round(total * rate)) - n_hold * (len(funcs) + 1)
    if n_core < 2 * len(funcs):
        return jsonify(error=(
            f"a total of {total:g}s leaves no room to move: the holds alone "
            f"take {n_hold * (len(funcs) + 1) / rate:.2f}s over "
            f"{len(funcs)} stage(s); raise the total or shorten the "
            "hold")), 400
    if n_core + n_hold * (len(funcs) + 1) > MAX_FRAMES:
        return jsonify(error=f"that would be over {MAX_FRAMES} frames; "
                             f"shorten the total or lower the fps"), 400
    base, rem = divmod(n_core, len(funcs))
    seq = []
    for i in range(len(funcs)):
        if i == 0:
            seq += [(0, 0.0)] * n_hold
        seq += [(i, t) for t in rd.timeline(max(2, base + (1 if i < rem else 0)),
                                            0, cfgmod.timing(st["config"])["ease"])]
        if i < len(funcs) - 1:
            seq += [(i, 1.0)] * n_hold
    seq += [(len(funcs) - 1, 1.0)] * n_hold
    box = rd.frames_box(funcs, pad=style["pad"])
    scale = width * 72.0 / (style["dpi"] * (box[2] - box[0]))
    t0 = time.time()
    r = rd.Renderer(box, scale=scale, dpi=style["dpi"])
    try:
        frames = [r.draw(funcs[i](t)) for i, t in seq]
    finally:
        r.close()
    name = f"morph.{fmt}"
    out = os.path.join(d, name)
    if fmt == "mp4":
        rd.write_mp4(frames, out, fps=fps)
    else:
        rd.write_gif(frames, out, fps=fps)
    h, wpx = frames[0].shape[:2]
    os.utime(d)
    return jsonify(
        url=url_for("out", sid=sid, name=name) + f"?v={int(time.time())}",
        name=name, fmt=fmt, frames=len(frames), size=f"{wpx}x{h}",
        seconds=round(time.time() - t0, 1), page="turns and reactions",
        stages=[{k: v for k, v in n.items()
                 if k in ("kind", "rotation_deg", "drawn_bonds", "atoms",
                          "bonds")} for n in notes])


def turns_available(scenes):
    """How many reorientations this file holds, if it holds any.

    A file drawn from a crystal structure carries 3D coordinates, and two
    such poses are what a turn is measured from.  Most files have none, so
    the control is simply not offered for them.
    """
    try:
        return len(rot.guide_stages(scenes))
    except Exception:
        return 0


def _overview(sid, scenes, st, msg="", all_scenes=None):
    rows = []
    for i in range(len(scenes) - 1):
        A, B = scenes[i], scenes[i + 1]
        blk = cfgmod.stage(st["config"], i, len(scenes) - 1)
        nmap, bmap, _ = cfgmod.resolve(blk, A, B)
        pinned = len(blk.get("pairs", {}))
        rows.append(
            f"<tr><td>{i + 1}</td>"
            f"<td>{len(nmap)} of {len(A.nodes)} &rarr; {len(B.nodes)}</td>"
            f"<td>{len(bmap)} of {len(A.bonds)} &rarr; {len(B.bonds)}</td>"
            f"<td>{'your mapping (' + str(pinned) + ' pinned)' if pinned else 'automatic'}</td>"
            f"<td><a href=\"{url_for('stage', sid=sid, i=i)}\">edit pairing</a></td></tr>")
    table = ("<table><tr><th>step</th><th>atoms paired</th><th>bonds carried</th>"
             "<th>mapping</th><th></th></tr>" + "".join(rows) + "</table>")
    # a page whose poses are hidden from the animation still HAS turns:
    # ask the full list, or the option to turn vanishes from the page
    n_turns = turns_available(all_scenes if all_scenes is not None
                              else scenes)
    turn_ui = ""
    if n_turns:
        turn_ui = (
            '<p><label>animate <select id="mode" onchange="modeChanged()">'
            '<option value="morph">the structural change (morph)</option>'
            f'<option value="turn">the molecule turning '
            f'({n_turns} reorientation{"s" if n_turns > 1 else ""})</option>'
            '</select></label>'
            '<label id="ppwrap" style="display:none">'
            '<input type="checkbox" id="pingpong" checked> ping-pong</label>'
            '<span class="muted">this file carries 3D coordinates, so it can '
            'also be turned</span></p>')
    return _page("cdxmorph", f"""
{msg}
<div class="card"><h2 style="font-size:14px;margin:0 0 8px">
{len(scenes)} structures, {len(scenes) - 1} transition(s)</h2>
{table}
<p class="muted">More bonds carried means less of the drawing has to dissolve.
Pin a pairing by hand where the automatic match is weak.</p></div>

<div class="card"><h2 style="font-size:14px;margin:0 0 8px">Render</h2>
{turn_ui}
<p>
<label><span id="lenlab">total length s</span>
 <input type="number" id="duration" value="5" min="0.5"
 max="60" step="0.1"></label>
<label>fps <input type="number" id="fps" value="24" min="4" max="60"></label>
<label>hold on each structure <input type="number" id="pause" value="0.3"
 min="0" max="5" step="0.1"></label>
<span class="muted">the whole clip runs this long whatever the number of
 structures, so two animations play side by side</span>
</p><p>
<label>width px <input type="number" id="width" value="1000" min="200"
 max="3000" step="50"></label>
<label>dissolve <input type="number" id="dissolve" value="1.0" min="0.1"
 max="1" step="0.05"></label>
<label>format <select id="fmt"><option value="gif">GIF</option>
 <option value="mp4">MP4</option></select></label>
</p>
<p><button class="go" onclick="go()">Render</button>
   <span id="stat" class="muted"></span></p>
<div id="out"></div></div>

<div class="card"><a href="{url_for('index')}">Start over with different files</a></div>

<script>
function modeChanged(){{
 const turn=document.getElementById('mode').value==='turn';
 // for a turn the length asked for is ONE pass: the way back adds the
 // same again, so the number keeps meaning what the user typed
 document.getElementById('lenlab').textContent=
   turn?'one-way length s':'total length s';
 document.getElementById('ppwrap').style.display=turn?'':'none';
 document.getElementById('dissolve').disabled=turn;
}}
async function go(){{
 const s=document.getElementById('stat'), o=document.getElementById('out');
 s.textContent='rendering\\u2026'; o.innerHTML='';
 const m=document.getElementById('mode');
 const body={{duration:+duration.value, fps:+fps.value, pause:+pause.value,
             width:+width.value, dissolve:+dissolve.value, fmt:fmt.value,
             mode:m?m.value:'morph',
             pingpong:document.getElementById('pingpong')?
                      document.getElementById('pingpong').checked:true}};
 let r;
 try{{ r=await (await fetch('{url_for("api_render", sid=sid)}',
      {{method:'POST',headers:{{'Content-Type':'application/json'}},
        body:JSON.stringify(body)}})).json(); }}
 catch(e){{ s.innerHTML='<span class="err">'+e+'</span>'; return; }}
 if(r.error){{ s.innerHTML='<span class="err">'+r.error+'</span>'; return; }}
 s.textContent=r.frames+' frames, '+r.size+', '+r.seconds+' s';
 o.innerHTML = (r.fmt==='mp4'
   ? '<video src="'+r.url+'" controls loop style="max-width:100%"></video>'
   : '<img src="'+r.url+'" style="max-width:100%">')
   + '<p><a href="'+r.url+'" download>Download '+r.name+'</a></p>';
}}
</script>""")


# ------------------------------------------------------------------ the app

def create_app(root=None, max_upload=MAX_UPLOAD):
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = max_upload
    root = os.path.abspath(root or os.environ.get("CDXMORPH_DATA", "cdxmorph_sessions"))
    os.makedirs(root, exist_ok=True)
    app.config["CDXMORPH_ROOT"] = root

    @app.get("/")
    def index():
        _sweep(root)
        return _page("cdxmorph", UPLOAD_BODY.format(
            action=url_for("upload"), err=""))

    @app.post("/upload")
    def upload():
        _sweep(root)
        allf = [f for f in request.files.getlist("files") if f and f.filename]
        # a .json among the uploads is a saved mapping, not a structure, so
        # an example can be shipped with the pairing its author settled on
        ups = [f for f in allf if not f.filename.lower().endswith(".json")]
        cfgs = [f for f in allf if f.filename.lower().endswith(".json")]
        if not 1 <= len(ups) <= 2 or len(cfgs) > 1:
            return _page("cdxmorph", UPLOAD_BODY.format(
                action=url_for("upload"),
                err='<p class="err">Upload one scheme file, or two files '
                    '(start and product), optionally with one mapping '
                    '.json.</p>')), 400
        preset = {}
        if cfgs:
            try:
                preset = json.loads(cfgs[0].read().decode("utf-8"))
                if not isinstance(preset, dict):
                    raise ValueError("expected a JSON object")
            except Exception as exc:
                return _page("cdxmorph", UPLOAD_BODY.format(
                    action=url_for("upload"),
                    err=f'<p class="err">Could not read that mapping: '
                        f'{exc}</p>')), 400
        sid = uuid.uuid4().hex
        d = os.path.join(root, sid)
        os.makedirs(d)
        names = []
        for n, f in enumerate(ups):
            # the uploaded name is never used as a path
            name = f"input{n}.cdxml"
            f.save(os.path.join(d, name))
            names.append(name)
        st = {"files": names,
              "labels": [os.path.basename(f.filename) for f in ups],
              "config": preset}
        _save_state(d, st)
        try:
            scenes = _scenes(d)
        except Exception as exc:
            shutil.rmtree(d, ignore_errors=True)
            return _page("cdxmorph", UPLOAD_BODY.format(
                action=url_for("upload"),
                err=f'<p class="err">Could not read that file: {exc}</p>')), 400
        if len(scenes) < 2:
            shutil.rmtree(d, ignore_errors=True)
            return _page("cdxmorph", UPLOAD_BODY.format(
                action=url_for("upload"),
                err='<p class="err">That file holds one structure. Upload a '
                    'scheme with an arrow, or a second file.</p>')), 400
        return redirect(url_for("overview", sid=sid))

    @app.get("/m/<sid>")
    def overview(sid):
        d = _sid_dir(root, sid)
        return _overview(sid, _scenes(d), _state(d),
                         all_scenes=_scenes(d, drawn_only=False))

    @app.get("/m/<sid>/stage/<int:i>")
    def stage(sid, i):
        d = _sid_dir(root, sid)
        scenes, st = _scenes(d), _state(d)
        if not 0 <= i < len(scenes) - 1:
            abort(404)
        A, B = scenes[i], scenes[i + 1]
        blk = cfgmod.stage(st["config"], i, len(scenes) - 1)
        nmap, _, _ = cfgmod.resolve(blk, A, B)
        toolbar = (f'<button class="go" onclick="saveMap()">Save pairing</button>'
                   f'<a href="{url_for("overview", sid=sid)}" '
                   f'style="margin-left:6px">back</a>')
        foot = (f'<p style="color:#777;font-size:11px;margin-top:8px">'
                f'Click an atom on the left, then its partner on the right. '
                f'Press <b>Save pairing</b> when the red count is as low as '
                f'you can get it.</p>'
                f'<script>async function saveMap(){{'
                f'const r=await fetch("{url_for("api_stage", sid=sid, i=i)}",'
                f'{{method:"POST",headers:{{"Content-Type":"application/json"}},'
                f'body:document.getElementById("json").value}});'
                f'if(r.ok){{location="{url_for("overview", sid=sid)}";}}'
                f'else{{alert((await r.json()).error||"could not save");}}}}'
                f'</script>')
        return ed.build(A, B, nmap,
                        name_a=f"structure {i + 1}", name_b=f"structure {i + 2}",
                        toolbar=toolbar, footnote=foot)

    @app.post("/api/stage/<sid>/<int:i>")
    def api_stage(sid, i):
        d = _sid_dir(root, sid)
        scenes, st = _scenes(d), _state(d)
        if not 0 <= i < len(scenes) - 1:
            abort(404)
        body = request.get_json(silent=True) or {}
        pairs = body.get("pairs")
        if not isinstance(pairs, dict):
            return jsonify(error='expected {"pairs": {...}}'), 400
        # The editor always opens pre-filled with the automatic match, so
        # what comes back IS the whole intended pairing - including the
        # atoms deliberately left unpaired.  Without "exact" the matcher
        # would fill those back in and the unpairing would not stick.
        blk = {"pairs": {str(k): str(v) for k, v in pairs.items()},
               "exact": True}
        try:                                  # reject before storing
            cfgmod.resolve(blk, scenes[i], scenes[i + 1])
        except Exception as exc:
            return jsonify(error=str(exc)), 400
        n = len(scenes) - 1
        stages = st["config"].get("stages")
        if n == 1:
            st["config"].update(blk)
        else:
            if not stages:
                stages = [{} for _ in range(n)]
            stages[i] = blk
            st["config"]["stages"] = stages
        _save_state(d, st)
        return jsonify(ok=True, pairs=len(blk["pairs"]))

    @app.post("/api/render/<sid>")
    def api_render(sid):
        d = _sid_dir(root, sid)
        scenes, st = _scenes(d), _state(d)
        body = request.get_json(silent=True) or {}

        def num(key, default, lo, hi):
            try:
                return min(hi, max(lo, float(body.get(key, default))))
            except (TypeError, ValueError):
                return default

        total = num("duration", 5.0, 0.5, 60.0)
        fps = int(num("fps", 24, 4, 60))
        pause = num("pause", 0.3, 0.0, 5.0)
        width = int(num("width", 1000, 200, 3000))
        fmt = "mp4" if str(body.get("fmt", "gif")).lower() == "mp4" else "gif"
        mo.DISSOLVE = num("dissolve", 1.0, 0.1, 1.0)
        mo.ALLOW_FLIP = bool(st["config"].get("flip", False))

        if str(body.get("mode", "morph")) == "turn":
            return _render_turn(d, sid, _scenes(d, drawn_only=False), st,
                                total, fps, pause, width, fmt,
                                bool(body.get("pingpong", True)))

        # A page holding both an equivalency sign with poses above it and a
        # reaction arrow animates as one clip: turn, then react.
        plan = _plan(d)
        if plan and any(s["kind"] == "turn" and s["solid"] for s in plan[1]) \
                and any(s["kind"] == "morph" for s in plan[1]):
            return _render_mixed(d, sid, st, total, fps, pause, width, fmt)

        n = len(scenes) - 1
        # `total` fixes the WHOLE clip, holds included, so a four-structure
        # scheme and a two-structure one finish together.  A GIF can only
        # store delays in hundredths of a second, so count frames at the
        # rate it will actually play at.
        rate = rd.gif_rate(fps) if fmt == "gif" else fps
        hold = int(round(pause * rate))
        n_core = int(round(total * rate)) - hold * (n + 1)
        if n_core < 2 * n:
            return jsonify(error=(
                f"a total of {total:g}s leaves no room to move: the holds "
                f"alone take {hold * (n + 1) / rate:.2f}s over {n} "
                f"transition(s); raise the total or shorten the hold")), 400
        if n_core + hold * (n + 1) > MAX_FRAMES:
            return jsonify(error=f"that would be over {MAX_FRAMES} frames; "
                                 f"shorten the total or lower the fps"), 400

        maps = []
        try:
            for i in range(n):
                blk = cfgmod.stage(st["config"], i, n)
                maps.append(cfgmod.resolve(blk, scenes[i], scenes[i + 1]))
        except Exception as exc:
            return jsonify(error=str(exc)), 400

        placed = rd.align_chain(list(scenes), [m[0] for m in maps])
        style = cfgmod.style(st["config"])
        cs.LABEL_CLEARANCE = style["label_clearance"]
        cs.HASH_SPACING = style.get("hash_spacing")
        cs.GAP_SCALE = style.get("gap_scale", cs.GAP_SCALE)
        box = rd.canvas_box(placed, pad=style["pad"])
        scale = width * 72.0 / (style["dpi"] * (box[2] - box[0]))
        t0 = time.time()
        frames = rd.render_chain(placed, maps, box, n_core, hold,
                                 hold_mid=hold,
                                 easing=cfgmod.timing(st["config"])["ease"],
                                 scale=scale, dpi=style["dpi"], workers=1)
        name = f"morph.{fmt}"
        out = os.path.join(d, name)
        if fmt == "mp4":
            rd.write_mp4(frames, out, fps=fps)
        else:
            rd.write_gif(frames, out, fps=fps)
        h, w = frames[0].shape[:2]
        os.utime(d)
        return jsonify(url=url_for("out", sid=sid, name=name) + f"?v={int(time.time())}",
                       name=name, fmt=fmt, frames=len(frames),
                       size=f"{w}x{h}", seconds=round(time.time() - t0, 1))

    @app.get("/out/<sid>/<name>")
    def out(sid, name):
        d = _sid_dir(root, sid)
        if name not in ("morph.gif", "morph.mp4"):
            abort(404)
        return send_from_directory(d, name)

    @app.errorhandler(413)
    def too_big(_):
        return _page("cdxmorph", UPLOAD_BODY.format(
            action=url_for("upload"),
            err='<p class="err">That file is too large.</p>')), 413

    return app
