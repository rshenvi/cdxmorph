"""Reading and validating a morph config.

The config is written entirely in the atom numbers ChemDraw shows (AtomID),
and entirely in terms of the STARTING structure where possible, so it keeps
working if the product is redrawn or renumbered.

    {
      "pairs":  {"14": "2", ...},        A atom -> B atom
      "exact":  false,                   true = use pairs verbatim,
                                         false = matcher fills the rest
      "shifts": [["14-17", "21"]],       1,2-shift: bond 14-17 keeps its 14
                                         end and walks its 17 end onto 21
      "timing": {"duration": 3.2, "fps": 24, "hold": 0.4,
                 "ease": "smoothstep"},
      "style":  {"scale": 6.0, "dpi": 150, "pad": 8.0,
                 "label_clearance": 0.45}
    }
"""
import json

from . import animate as mo


# "duration" is the moving part only.  "total", when set, fixes the whole
# clip instead - holds and pauses come out of it, so files with different
# numbers of structures still finish together.
DEFAULT_TIMING = {"duration": 3.2, "fps": 24, "hold": 0.4, "ease": "smoothstep",
                  "total": None}
DEFAULT_STYLE = {"scale": 6.0, "dpi": 150, "pad": 8.0,
                 "label_clearance": 0.45, "hash_spacing": 3.0,
                 # labels whose hydrogen passes IN FRONT of its
                 # heteroatom as the molecule turns; any other flippable
                 # label's hydrogen passes behind it
                 "h_front": ["OH"],
                 # fraction of the document's MarginWidth a crossing gap
                 # uses; 1.0 is ChemDraw's own, which can swallow a narrow
                 # angle just past the crossing
                 "gap_scale": 0.75}


class ConfigError(ValueError):
    """A config that names something the structures do not contain."""


def load(path):
    if path is None:
        return {}
    with open(path) as fh:
        return json.load(fh)


def _index(sc):
    return {v["atom_id"]: k for k, v in sc.nodes.items()}


def _bond_between(sc, u, v):
    for k, b in sc.bonds.items():
        if {b["b"], b["e"]} == {u, v}:
            return k
    return None


def stage(cfg, i, n_stages):
    """The config block for stage `i` of a multi-structure sequence.

    A two-structure job is written flat (`pairs`, `shifts`, ...).  A longer
    sequence puts one such block per arrow under `stages`; anything outside
    `stages` (timing, style) still applies to the whole run.
    """
    if "stages" not in cfg:
        if n_stages > 1 and any(k in cfg for k in ("pairs", "shifts")):
            raise ConfigError(
                f"this file has {n_stages} transitions, so per-transition "
                f"mappings go in a \"stages\" list of {n_stages} blocks; "
                "a top-level \"pairs\" applies to one transition only")
        # a single transition uses the flat config as its only block
        return cfg if n_stages == 1 else {}
    blocks = cfg["stages"]
    if not isinstance(blocks, list):
        raise ConfigError('"stages" must be a list, one block per arrow')
    if len(blocks) != n_stages:
        raise ConfigError(f'"stages" has {len(blocks)} blocks but this file '
                          f"has {n_stages} transitions")
    return blocks[i]


class Overrides(dict):
    """Per-bond overrides for a transition.

    Behaves as the shift dictionary it always was, with `slides` carried
    alongside: a slide cannot be keyed by bond because its target may be
    a bond that exists only in the product.
    """

    slides = ()


def resolve(cfg, A, B):
    """Config -> (nmap, bmap, bover).  Raises ConfigError on anything the
    two structures cannot support, naming the offending entry."""
    byA, byB = _index(A), _index(B)

    forced = {}
    seen = {}
    for a, b in (cfg.get("pairs") or cfg.get("forced") or {}).items():
        a, b = str(a), str(b)
        if a not in byA:
            raise ConfigError(f"pairs: no atom {a} in the starting structure")
        if b not in byB:
            raise ConfigError(f"pairs: no atom {b} in the product")
        if b in seen:
            raise ConfigError(
                f"pairs: product atom {b} is claimed by both {seen[b]} and "
                f"{a}; each product atom may appear at most once")
        seen[b] = a
        forced[byA[a]] = byB[b]

    # `and "pairs" in cfg`, not `and forced`: a mapping that deliberately
    # pairs nothing is still a decision, and must not fall back to the
    # matcher
    if cfg.get("exact") and "pairs" in cfg:
        nmap = forced
    elif getattr(B, "equiv_to_prev", False):
        # an equivalency sign says these are one molecule redrawn, so pair
        # by connectivity; fall back to geometry if no isomorphism exists
        # (the drawings may differ in what they leave out)
        iso = mo.match_equivalent(A, B)
        if forced:
            iso = {k: v for k, v in iso.items()
                   if forced.get(k, v) == v and k not in forced}
            iso.update(forced)
        nmap = iso or mo.match_nodes(A, B, forced=forced)
    else:
        # Four ways to pair, kept as candidates rather than a single rule:
        # position fitted over the whole scene (right for one molecule
        # redrawn nearby), position per drawn fragment, connectivity grown
        # along the bonds (right when a piece is also rotated), and
        # connectivity per fragment (right for a reagent joining, where
        # growth along bonds cannot cross from one piece to the other).
        # Whichever carries the most bonds wins.
        cands = [mo.match_nodes(A, B, forced=forced),
                 mo.match_connectivity(A, B, forced=forced),
                 mo.match_fragments(A, B, forced=forced),
                 mo.match_fragments(A, B, forced=forced,
                                    matcher=mo.match_connectivity)]
        if forced:
            # A pair the user asked for is not a hint.  The candidates do
            # not all honour `forced` - growth along bonds can walk away
            # from it - and picking on bond count alone silently threw the
            # request away.  Prefer a candidate that keeps every requested
            # pair; if none does, impose them on the best one, evicting
            # whatever else had claimed those atoms.
            keep = [c for c in cands
                    if c and all(c.get(k) == v for k, v in forced.items())]
            if keep:
                cands = keep
            else:
                fixed = []
                for c in cands:
                    if not c:
                        continue
                    taken = set(forced.values())
                    m = {k: v for k, v in c.items()
                         if k not in forced and v not in taken}
                    m.update(forced)
                    fixed.append(m)
                cands = fixed
        nmap = max((c for c in cands if c),
                   key=lambda c: len(mo.match_bonds(A, B, c)), default={})
    bmap = mo.match_bonds(A, B, nmap)

    nbA = mo.adj(A)
    bover = Overrides()
    for entry in cfg.get("shifts", []):
        spec, dest_id = entry[0], str(entry[1])
        try:
            a1, a2 = str(spec).split("-")
        except ValueError:
            raise ConfigError(f"shifts: {spec!r} should look like \"14-17\"")
        for n in (a1, a2, dest_id):
            if n not in byA:
                raise ConfigError(
                    f"shift {spec} -> {dest_id}: no atom {n} in the "
                    "starting structure (shifts are written in starting-"
                    "structure atom numbers)")
        u, v, dest = byA[a1], byA[a2], byA[dest_id]
        ab = _bond_between(A, u, v)
        if ab is None:
            raise ConfigError(f"shift {spec}: {spec} is not a bond")
        if ab in bmap:
            raise ConfigError(
                f"shift {spec}: that bond is already matched by the atom "
                "mapping, so it has nowhere to shift to; unpair one of its "
                "atoms or drop the shift")
        movers = [x for x in (u, v) if dest in nbA[x]]
        if len(movers) != 1:
            raise ConfigError(
                f"shift {spec} -> {dest_id}: exactly one end of {spec} must "
                f"be bonded to {dest_id}, found {len(movers)}")
        mover = movers[0]
        anchor = v if mover == u else u
        for k, role in ((anchor, "anchor"), (mover, "moving"),
                        (dest, "destination")):
            if k not in nmap:
                raise ConfigError(
                    f"shift {spec} -> {dest_id}: the {role} atom "
                    f"{A.nodes[k]['atom_id']} is unpaired")
        tgt = _bond_between(B, nmap[anchor], nmap[dest])
        if tgt is None:
            raise ConfigError(
                f"shift {spec} -> {dest_id}: the product has no bond "
                f"{B.nodes[nmap[anchor]]['atom_id']}-"
                f"{B.nodes[nmap[dest]]['atom_id']} for it to become")
        bover[ab] = (tgt, mover, dest)

    bover.slides = _slides(cfg, A, B, byA, nmap, bmap)
    return nmap, bmap, bover


def _slides(cfg, A, B, byA, nmap, bmap):
    """Parse "slides": the inner line of one bond travels to another.

    Written as pairs of atom pairs in STARTING-structure numbers,
    [["7-8", "4-7"], ...].  The target need not be a bond in the start -
    naming it by its two atoms lets a line slide onto a bond that only
    the product has, which is what closing a ring looks like.
    """
    out = []
    for entry in cfg.get("slides", []):
        try:
            src_spec, tgt_spec = entry
            s1, s2 = str(src_spec).split("-")
            t1, t2 = str(tgt_spec).split("-")
        except (ValueError, TypeError):
            raise ConfigError(
                f"slides: {entry!r} should look like [\"7-8\", \"4-7\"]")
        for n in (s1, s2, t1, t2):
            if n not in byA:
                raise ConfigError(
                    f"slide {src_spec} -> {tgt_spec}: no atom {n} in the "
                    "starting structure (slides are written in starting-"
                    "structure atom numbers)")
        su, sv = byA[s1], byA[s2]
        tu, tv = byA[t1], byA[t2]
        src = _bond_between(A, su, sv)
        if src is None:
            raise ConfigError(f"slide {src_spec}: that is not a bond")
        if A.bonds[src]["order"] != 2:
            raise ConfigError(
                f"slide {src_spec}: only a double bond has an inner line "
                "to slide")
        for k in (tu, tv):
            if k not in nmap:
                raise ConfigError(
                    f"slide {src_spec} -> {tgt_spec}: target atom "
                    f"{A.nodes[k]['atom_id']} is unpaired")
        tgt_b = _bond_between(B, nmap[tu], nmap[tv])
        if tgt_b is None:
            raise ConfigError(
                f"slide {src_spec} -> {tgt_spec}: the product has no bond "
                f"{B.nodes[nmap[tu]]['atom_id']}-"
                f"{B.nodes[nmap[tv]]['atom_id']} to slide onto")
        tgt_a = _bond_between(A, tu, tv)
        if tgt_a is not None and A.bonds[tgt_a]["order"] == 2 \
                and B.bonds[tgt_b]["order"] == 2:
            raise ConfigError(
                f"slide {src_spec} -> {tgt_spec}: {tgt_spec} is already a "
                "double bond in both structures, so it has no line to gain")
        out.append((src, tu, tv, tgt_a, tgt_b))
    return tuple(out)


def timing(cfg):
    t = dict(DEFAULT_TIMING); t.update(cfg.get("timing") or {})
    return t


def style(cfg):
    s = dict(DEFAULT_STYLE); s.update(cfg.get("style") or {})
    return s


def summary(A, B, nmap, bmap, bover):
    inv = set(nmap.values())
    return {
        "atoms": f"{len(nmap)} paired of {len(A.nodes)} -> {len(B.nodes)}",
        "bonds": f"{len(bmap)} carried of {len(A.bonds)} -> {len(B.bonds)}",
        "shifts": len(bover),
        "breaking": [f"{A.nodes[b['b']]['atom_id']}-{A.nodes[b['e']]['atom_id']}"
                     for k, b in A.bonds.items()
                     if k not in bmap and k not in bover],
        "forming": [f"{B.nodes[b['b']]['atom_id']}-{B.nodes[b['e']]['atom_id']}"
                    for k, b in B.bonds.items()
                    if k not in set(bmap.values())
                    and k not in {v[0] for v in bover.values()}],
        "unpaired_start": sorted((v["atom_id"] for k, v in A.nodes.items()
                                  if k not in nmap), key=int),
        "unpaired_product": sorted((v["atom_id"] for k, v in B.nodes.items()
                                    if k not in inv), key=int),
    }
