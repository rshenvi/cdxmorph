"""The interface the in-browser build calls: bytes in, bytes out.

A browser tab has no command line and no server, so this module is the
whole boundary between JavaScript and the program.  Everything here
drives the SAME entry point the desktop build uses, so an animation made
in a browser is the one `cdxmorph render` would make: the frame
scheduling, the pairing rules and the occlusion rules are not
reimplemented, and cannot drift from the desktop version.

Two desktop features are unavailable in a browser and are refused rather
than faked: MP4 output, whose encoder is not compiled for WebAssembly,
and rendering across processes, which a tab cannot do.
"""

import contextlib
import io
import json
import os
import sys

from . import cli

WORK = "/tmp/cdxmorph"


def _put(name, data):
    """Write uploaded bytes into the virtual filesystem, return the path."""
    os.makedirs(WORK, exist_ok=True)
    safe = os.path.basename(str(name)) or "input.cdxml"
    path = os.path.join(WORK, safe)
    with open(path, "wb") as fh:
        fh.write(bytes(data))
    return path


def _clean(*paths):
    for p in paths:
        try:
            os.remove(p)
        except OSError:
            pass


def _run(argv):
    """Run one command and return its JSON report.

    The commands print a report to stdout; a browser has no stdout worth
    reading, so it is captured and parsed here.  A failure raises with
    whatever the command said, which the page shows verbatim.
    """
    out, err = io.StringIO(), io.StringIO()
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = cli.main([str(a) for a in argv])
    except SystemExit as exc:                      # argparse or a refusal
        raise RuntimeError(err.getvalue().strip()
                           or f"command failed ({exc.code})") from None
    except Exception as exc:
        raise RuntimeError(f"{type(exc).__name__}: {exc}") from None
    if code:
        raise RuntimeError(err.getvalue().strip() or f"command failed ({code})")
    text = out.getvalue().strip()
    if not text:
        return {}
    starts = [i for i in (text.find("{"), text.find("[")) if i >= 0]
    try:
        return json.loads(text[min(starts):]) if starts else {"output": text}
    except ValueError:
        return {"output": text}


def _transitions(path):
    """How many transitions this file animates, as the renderer counts them."""
    from . import scene as cs
    stages, mixed = cli._mixed_page(path)
    if mixed:
        return len(stages)
    try:
        return max(1, len(cs.parse_sequence(path)) - 1)
    except Exception:
        return 1


def _normalise(cfg, path):
    """Accept a mapping for one transition and place it where it belongs.

    The editor knows which transition it was built for, so the page sends
    that number along with the pairing.  Turning it into the `stages` list
    the renderer expects is this function's job - not the chemist's, and
    not a copy-and-paste step.
    """
    if not cfg:
        return None
    cfg = dict(cfg)
    by_stage = cfg.pop("by_stage", None)
    if not by_stage:
        return cfg
    n = _transitions(path)
    blocks = [dict(by_stage.get(str(i + 1), by_stage.get(i + 1, {}) or {}))
              for i in range(n)]
    if n == 1:
        cfg.update(blocks[0])
    else:
        cfg["stages"] = blocks
    return cfg


def _config(cfg, path=None):
    """A config dict written where the commands can read it, or None."""
    if path is not None:
        cfg = _normalise(cfg, path)
    if not cfg:
        return None
    path = os.path.join(WORK, "config.json")
    os.makedirs(WORK, exist_ok=True)
    with open(path, "w") as fh:
        json.dump(cfg, fh)
    return path


def version():
    from . import __version__
    return __version__


def describe(name, data, config=None):
    """What this file holds: its stages, and whether it can be turned."""
    path = _put(name, data)
    rep = _run(["check", path] + (["-c", _config(config, path)] if config else []))
    from . import rotate as rot, scene as cs
    try:
        turns = len(rot.guide_stages(cs.parse_sequence(path)))
    except Exception:
        turns = 0
    rep["turns"] = turns
    rep["file"] = os.path.basename(path)
    return rep


def animate(name, data, opts=None):
    """Render an animation; returns the report plus the file's bytes.

    `opts` keys: mode ("morph" or "turn"), seconds, fps, width, pause,
    bounce, fmt ("gif" or "png"), config (a mapping/style dict).
    """
    opts = dict(opts or {})
    fmt = str(opts.get("fmt", "gif")).lower()
    if fmt in ("mp4", "m4v"):
        raise RuntimeError(
            "MP4 needs an encoder that is not available in a browser; "
            "render a GIF here, or use the download for MP4")
    if fmt not in ("gif", "png"):
        raise RuntimeError(f"unknown format {fmt!r}; use gif or png")
    path = _put(name, data)
    out = os.path.join(WORK, "out." + ("gif" if fmt == "gif" else "png"))
    _clean(out)
    cfg = _config(opts.get("config"), path)
    seconds = float(opts.get("seconds", 6.0))
    argv = ([("rotate" if opts.get("mode") == "turn" else "render"), path,
             "-o", out, "--width", int(opts.get("width", 900)),
             "--pause", float(opts.get("pause", 0.3))]
            + (["-c", cfg] if cfg else []))
    if opts.get("mode") == "turn":
        argv += ["--oneway", seconds]
        if not opts.get("bounce", True):
            argv += ["--once"]
    else:
        argv += ["--duration", seconds, "--fps", float(opts.get("fps", 20))]
        if opts.get("bounce"):
            argv += ["--bounce"]
    rep = _run(argv)
    if fmt == "png":
        # a numbered sequence: hand back a zip of the frames
        import glob
        import zipfile
        frames = sorted(glob.glob(os.path.splitext(out)[0] + "_*.png"))
        zpath = os.path.join(WORK, "frames.zip")
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in frames:
                zf.write(f, os.path.basename(f))
        _clean(*frames)
        rep["data"] = open(zpath, "rb").read()
        rep["name"] = "frames.zip"
    else:
        rep["data"] = open(out, "rb").read()
        rep["name"] = "animation.gif"
    return rep


def still(name, data, config=None, dpi=200):
    """Every structure as drawn, as PNG bytes."""
    path = _put(name, data)
    out = os.path.join(WORK, "still.png")
    _clean(out)
    cfg = _config(config, path)
    _run(["still", path, "-o", out, "--dpi", int(dpi)]
         + (["-c", cfg] if cfg else []))
    return {"data": open(out, "rb").read(), "name": "structures.png"}


def editors(name, data, config=None):
    """The click-to-pair page for every transition, as standalone HTML.

    Each page carries a Save button that hands its pairing straight back
    to the page that opened it, tagged with the transition it belongs to,
    so nobody has to copy JSON anywhere.
    """
    from . import editor as ed, scene as cs
    path = _put(name, data)
    full = _normalise(config, path)
    n = _transitions(path)
    stages, mixed = cli._mixed_page(path)

    def block(i):
        from . import config as cfgmod
        return cfgmod.stage(full or {}, i, n)

    pairs_for = []
    if mixed:
        # A reorientation is pairable too: the poses give the axis, but which
        # atom becomes which is still a choice, and the drawings either side
        # of an equivalency sign need not be drawn the same way.
        for i, sp in enumerate(stages):
            pairs_for.append((i, sp["A"], sp["B"], sp["kind"]))
    else:
        scenes = cs.parse_sequence(path)
        for i in range(len(scenes) - 1):
            pairs_for.append((i, scenes[i], scenes[i + 1], "morph"))

    from . import config as cfgmod
    from . import rotate as rot
    pages = []
    for i, A, B, kind in pairs_for:
        blk = block(i)
        if blk.get("pairs") or kind != "turn" or not stages[i]["solid"]:
            nmap = cfgmod.resolve(blk, A, B)[0]
        else:
            # A turn's own pairing is composed through its 3D poses and is
            # better than a plain geometric match, so the editor must open
            # on THAT - otherwise saving what is shown would make the
            # animation worse than leaving it alone.
            SA, SB = stages[i]["solid"]
            nmap = rot.pair_drawn(A, B, SA, SB, rot.pair_solid(SA, SB)[0])[0]
        html = ed.build(
            A, B, nmap,
            name_a=f"structure {i + 1}", name_b=f"structure {i + 2}",
            toolbar=_SAVE_BUTTON, show_json=False,
            footnote=_SAVE_SCRIPT.replace("__STAGE__", str(i + 1)))
        pages.append({"stage": i + 1, "kind": kind,
                      "name": ("reorientation" if kind == "turn" else "reaction")
                              + f" {i + 1}",
                      "pairs": len(nmap), "html": html})
    return pages


# The Save button lives in the editor's own header, and posts the pairing
# to whichever page opened the editor.  Nothing is uploaded: the message
# never leaves the browser.
_SAVE_BUTTON = (
    '<button onclick="cdxSave()" style="font-weight:600;background:#1668dc;'
    'color:#fff;border:1px solid #1059c0;border-radius:6px;padding:6px 13px;'
    'cursor:pointer;box-shadow:0 1px 2px rgba(0,0,0,.18)" '
    'onmouseover="this.style.background=\'#1059c0\'" '
    'onmouseout="this.style.background=\'#1668dc\'">Save mapping</button>')

_SAVE_SCRIPT = """<p style="color:#777;font-size:11px;margin-top:8px">
Atom numbers are the red labels in the drawings. Click <b>Save mapping</b> and
this pairing goes straight back to the page that opened it &mdash; then render
again.</p>
<script>
function cdxSave(){
  var m;
  try { m = JSON.parse(text()); } catch (e) { return; }
  var msg = {cdxmorph: "mapping", stage: __STAGE__, mapping: m};
  try { if (window.parent && window.parent !== window) window.parent.postMessage(msg, "*"); } catch (e) {}
  try { if (window.opener) window.opener.postMessage(msg, "*"); } catch (e) {}
  var s = document.getElementById("stat");
  if (s) s.textContent = Object.keys(m.pairs || {}).length +
      " pairs saved for transition __STAGE__";
}
</script>"""
