"""cdxmorph - animate one ChemDraw drawing into another as line art.

Nothing here interprets chemistry: structures are read as positioned line
segments and text, matched geometrically, interpolated, and repainted with
ChemDraw's own occlusion rules.
"""
__version__ = "1.45.0"
__author__ = "Ryan Shenvi"
__credits__ = "Developed by Ryan Shenvi @ ShenviLab"

from . import scene, animate, config, render, editor   # noqa: F401
