"""Match two CDXML scenes element-by-element and interpolate between them.
Purely geometric / topological - no chemistry is consulted."""
import numpy as np
from scipy.optimize import linear_sum_assignment

from . import scene as cs


# ------------------------------------------------------------- matching

def adj(sc):
    nbr = {k: set() for k in sc.nodes}
    for b in sc.bonds.values():
        if b["b"] in nbr and b["e"] in nbr:
            nbr[b["b"]].add(b["e"]); nbr[b["e"]].add(b["b"])
    return nbr


def _lab(n):
    """Label text in a form that ignores glyph order.

    ChemDraw stores a right-aligned group reversed so it reads outward
    from the bond - the same hydroxyl is "OH" on one side of a structure
    and "HO" on the other.  Matching on the literal string makes those two
    unpairable, which silently costs real pairs, so compare a canonical
    form instead.
    """
    if not n["label"]:
        return ""
    t = n["label"]["text"]
    return min(t, cs.reverse_label(t))



_ENDS = 1e-3          # how close to an end counts as at rest


def _attach(n):
    """The glyph a node's bonds meet, or "" for an unlabelled atom.

    "NH" and "N" are one nitrogen with and without a drawn hydrogen;
    "OTES" and "O" are one oxygen with and without a silyl group.  In
    both the atom the bonds meet is unchanged and should MOVE, not fade
    out while another fades in - which is what made a deprotection read
    as one atom replacing another.  So pairing turns on the attachment
    glyph, and only what hangs off it dissolves.
    """
    if not n["label"]:
        return ""
    return cs.label_parts(n["label"], n["p"])[0]


def match_nodes(A, B, max_cost=22.0, forced=None, iters=6, consistency=3.0):
    """Hungarian assignment on aligned position + label text + degree,
    refined by neighbour consistency (pairs whose neighbours also pair
    get cheaper).  forced : {A_node_id: B_node_id} pinned by the user."""
    ka, kb = list(A.nodes), list(B.nodes)
    ia = {k: i for i, k in enumerate(ka)}
    ib = {k: j for j, k in enumerate(kb)}
    na, nb = adj(A), adj(B)
    PA = np.array([A.nodes[k]["p"] for k in ka])
    PB = np.array([B.nodes[k]["p"] for k in kb])
    forced = forced or {}

    pen = np.zeros((len(ka), len(kb)))
    for i, a in enumerate(ka):
        for j, b in enumerate(kb):
            la, lb = _lab(A.nodes[a]), _lab(B.nodes[b])
            if la != lb:
                ea, eb = _attach(A.nodes[a]), _attach(B.nodes[b])
                if ea and ea == eb:
                    # the same atom, differently substituted: pay for the
                    # substituent that changes, but do not forbid the pair
                    pen[i, j] += 6.0 + 1.5 * abs(len(la) - len(lb))
                else:
                    # two different letters are never the same object
                    pen[i, j] += 1e3 if (la and lb) else 16.0
            pen[i, j] += 2.5 * abs(len(na[a]) - len(nb[b]))

    # Start from a centroid alignment.  Structures drawn side by side in one
    # file are hundreds of points apart, and every pair would sit above
    # max_cost on the first pass - the matcher would return nothing and never
    # get a chance to refit.  For two structures drawn at the same place this
    # offset is ~0, so it changes nothing there.
    def fit(P):
        """Iterated assignment + rigid refit from a given layout of A."""
        R, t = np.eye(2), PB.mean(0) - P.mean(0)
        m, bonus, C = {}, np.zeros_like(pen), None
        for _ in range(iters):
            Q = P @ R.T + t
            C = (np.linalg.norm(Q[:, None, :] - PB[None, :, :], axis=2)
                 + pen - bonus)
            for a, b in forced.items():
                if a in ia and b in ib:
                    C[ia[a], :] += 1e6
                    C[:, ib[b]] += 1e6
                    C[ia[a], ib[b]] = -1e6
            ri, ci = linear_sum_assignment(C)
            m = {ka[i]: kb[j] for i, j in zip(ri, ci)
                 if C[i, j] <= max_cost or ka[i] in forced}
            if len(m) < 3:
                break
            X = np.array([P[ia[a]] for a in m])
            Y = np.array([PB[ib[b]] for b in m.values()])
            xc, yc = X.mean(0), Y.mean(0)
            U, _, Vt = np.linalg.svd((X - xc).T @ (Y - yc))
            d = np.sign(np.linalg.det(Vt.T @ U.T))
            R = Vt.T @ np.diag([1.0, d]) @ U.T
            t = yc - R @ xc
            # reward candidate pairs whose neighbourhoods are already paired
            bonus = np.zeros_like(pen)
            for a, b in m.items():
                for x in na[a]:
                    for y in nb[b]:
                        bonus[ia[x], ib[y]] += consistency
        resid = (sum(float(np.linalg.norm(P[ia[a]] @ R.T + t - PB[ib[b]]))
                     for a, b in m.items()) if m else 0.0)
        return m, resid

    # Try the drawing both ways round.  The refit above is constrained to a
    # proper rotation, so it can never fit two drawings that are mirror
    # images - which is exactly how a structure redrawn after a rotation in
    # three dimensions tends to appear on the page.  Whichever layout pairs
    # more atoms wins; ties go to the lower residual, and for the ordinary
    # case the reflected fit simply loses.
    best = None
    for flip in (1.0, -1.0):
        m, resid = fit(PA * np.array([flip, 1.0]))
        key = (len(m), -resid)
        if best is None or key > best[0]:
            best = (key, m)
    return best[1]




def _fragment_scene(sc, frag_id):
    """A view of `sc` holding only the nodes and bonds of one fragment."""
    import copy
    sub = copy.copy(sc)
    sub.nodes = {k: v for k, v in sc.nodes.items()
                 if v.get("frag") == frag_id}
    sub.bonds = {k: v for k, v in sc.bonds.items()
                 if v["b"] in sub.nodes and v["e"] in sub.nodes}
    return sub



def _ring_order(sc, k):
    """Neighbours of `k` in the order they are drawn around it."""
    p = np.asarray(sc.nodes[k]["p"], float)
    out = []
    for q in adj(sc)[k]:
        d = np.asarray(sc.nodes[q]["p"], float) - p
        out.append((float(np.arctan2(d[1], d[0])), q))
    return [q for _, q in sorted(out)]


def _grow_embedding(A, B, a0, b0, flip, compat):
    """Grow a correspondence outward from one paired atom.

    Rotating or moving a drawing does not change the order in which bonds
    come off an atom, and reflecting it simply reverses that order.  So
    the cyclic order of the neighbours is the part of the drawing worth
    trusting when the two structures sit anywhere on the page - unlike
    raw position, which a rigid fit has to guess at.
    """
    from collections import deque
    nA, nB = adj(A), adj(B)
    m, inv = {a0: b0}, {b0: a0}
    dq = deque([(a0, b0)])
    while dq:
        a, b = dq.popleft()
        oa, ob = _ring_order(A, a), _ring_order(B, b)
        if flip:
            ob = list(reversed(ob))
        if not oa or not ob:
            continue
        best, best_off = -1, 0
        for off in range(len(ob)):
            sc_ = 0
            for i, x in enumerate(oa):
                y = ob[(i + off) % len(ob)]
                if x in m:
                    sc_ += 3 if m[x] == y else -3
                elif y in inv:
                    sc_ -= 1
                elif compat(x, y):
                    sc_ += 1
            if sc_ > best:
                best, best_off = sc_, off
        for i, x in enumerate(oa):
            y = ob[(i + best_off) % len(ob)]
            if x in m or y in inv or not compat(x, y):
                continue
            m[x] = y
            inv[y] = x
            dq.append((x, y))
    return m


def match_connectivity(A, B, forced=None, seeds=None):
    """Pair two drawings by their connectivity, not their positions.

    Seeded at every compatible pair of atoms and grown along the bonds in
    both chiralities; the correspondence carrying the most bonds wins.
    This finds a shared skeleton wherever it sits on the page, which is
    what a rigid fit cannot do when one scene holds two molecules drawn
    apart that the next structure folds together.
    """
    nA, nB = adj(A), adj(B)
    lab = lambda sc, k: _lab(sc.nodes[k])
    def compat(x, y):
        la, lb = lab(A, x), lab(B, y)
        ea, eb = _attach(A.nodes[x]), _attach(B.nodes[y])
        same = la == lb or (ea and ea == eb)
        return same and abs(len(nA[x]) - len(nB[y])) <= 1
    forced = forced or {}
    cands = [(a, b) for a in A.nodes for b in B.nodes if compat(a, b)]
    if seeds:
        cands = [(a, b) for a, b in cands if a in seeds]
    best, best_n = {}, -1
    for a0, b0 in (list(forced.items()) + cands):
        if not compat(a0, b0):
            continue
        for flip in (False, True):
            m = _grow_embedding(A, B, a0, b0, flip, compat)
            if forced and any(m.get(k, v) != v for k, v in forced.items()):
                m = {k: v for k, v in m.items()
                     if forced.get(k, v) == v and k not in forced}
                m.update(forced)
            n = len(match_bonds(A, B, m))
            if n > best_n:
                best, best_n = m, n
    return best


def match_fragments(A, B, forced=None, matcher=None, **kw):
    """Pair A onto B one drawn fragment at a time.

    `match_nodes` aligns A onto B as ONE rigid body.  That is right for a
    single molecule, but a scene may hold two molecules drawn apart on the
    page which the next structure folds together - a reagent joining.  No
    single alignment can put both near their partners, so it splits the
    difference and neither pairs.  Fitting each fragment on its own finds
    both; the results are merged one-to-one, larger fragment first, and
    the caller keeps whichever of the two matches carries more bonds.
    """
    frags = sorted({v.get("frag") for v in A.nodes.values() if v.get("frag")},
                   key=lambda f: -sum(1 for v in A.nodes.values()
                                      if v.get("frag") == f))
    if len(frags) < 2:
        return {}
    forced = forced or {}
    out, taken = {}, set(forced.values())
    out.update(forced)
    for f in frags:
        sub = _fragment_scene(A, f)
        if len(sub.nodes) < 2:
            continue
        keep = {k: v for k, v in forced.items() if k in sub.nodes}
        m = (matcher or match_nodes)(sub, B, forced=keep, **kw)
        for k, v in m.items():
            if k in out or v in taken:
                continue
            out[k] = v
            taken.add(v)
    return out


def match_equivalent(A, B, limit=400):
    """Atoms of two drawings of the SAME molecule, paired by connectivity.

    An equivalency sign says the two pictures are one molecule redrawn,
    so position carries little information - the geometric matcher pairs
    by where things sit and does badly on a reorientation.  The bonds do
    carry it: this searches for an isomorphism of the drawn connectivity,
    with atom labels and degrees as constraints, and where a molecule has
    symmetry it keeps the solution that moves the atoms least once the
    two drawings are superimposed.
    """
    nA, nB = adj(A), adj(B)
    ka = sorted(A.nodes, key=lambda k: -len(nA[k]))
    lab = lambda sc, k: _lab(sc.nodes[k])
    compat = {}
    for u in A.nodes:
        compat[u] = [v for v in B.nodes
                     if len(nB[v]) == len(nA[u]) and lab(B, v) == lab(A, u)]
        if not compat[u]:
            return {}
    sols = []

    def walk(i, m, inv):
        if len(sols) >= limit:
            return
        if i == len(ka):
            sols.append(dict(m))
            return
        u = ka[i]
        for v in compat[u]:
            if v in inv:
                continue
            ok = True
            for w in nA[u]:
                if w in m and m[w] not in nB[v]:
                    ok = False
                    break
            if not ok:
                continue
            # every already-placed B neighbour must correspond to an A bond
            for x in nB[v]:
                if x in inv and inv[x] not in nA[u]:
                    ok = False
                    break
            if ok:
                m[u] = v
                inv[v] = u
                walk(i + 1, m, inv)
                del inv[v]
                del m[u]

    walk(0, {}, {})
    if not sols:
        return {}
    if len(sols) == 1:
        return sols[0]

    def cost(m):
        P = np.array([A.nodes[u]["p"] for u in m], float)
        Q = np.array([B.nodes[v]["p"] for v in m.values()], float)
        pc, qc = P.mean(0), Q.mean(0)
        H = (P - pc).T @ (Q - qc)
        U, _, Vt = np.linalg.svd(H)
        best = 1e18
        for det in (1.0, -1.0):
            R = Vt.T @ np.diag([1.0, det * np.sign(np.linalg.det(Vt.T @ U.T))]) @ U.T
            best = min(best, float((((P - pc) @ R.T - (Q - qc)) ** 2).sum()))
        return best

    return min(sols, key=cost)


def match_bonds(A, B, nmap):
    inv = {v: k for k, v in nmap.items()}
    bkey = {}
    for bid, b in B.bonds.items():
        if b["b"] in inv and b["e"] in inv:
            bkey[frozenset((inv[b["b"]], inv[b["e"]]))] = bid
    return {aid: bkey[frozenset((a["b"], a["e"]))]
            for aid, a in A.bonds.items()
            if frozenset((a["b"], a["e"])) in bkey}


# --------------------------------------------------------- interpolation

def znorm(sc):
    zs = sorted({v["z"] for v in
                 list(sc.nodes.values()) + list(sc.bonds.values())})
    return {z: i / max(len(zs) - 1, 1) for i, z in enumerate(zs)}


# Out-of-plane flip is OFF unless a config asks for it.  It is only
# right when a structure was genuinely redrawn after rotating in three
# dimensions, and it passes through an edge-on view, so it should
# never be applied automatically.
ALLOW_FLIP = False

# How much of a transition a bond takes to dissolve, as a fraction of it.
# 1.0 is a full cross-dissolve: what leaves and what arrives are mirror
# images in opacity, summing to 1 at every instant, so the drawing never
# thins out.  Lower values give each a shorter fade with a fainter
# crossover in between.
DISSOLVE = 1.0


def turn_end(p, origin, u):
    """Where `p` lands after a half turn about the axis - its mirror."""
    d = np.asarray(p, float) - origin
    par = float(d @ u) * u
    return origin + par - (d - par)


def mirror_turn(A, B, nmap, fixed_tol=0.5, along_tol=0.5, min_across=1.0):
    """A fragment turned over about a line through two atoms, or None.

    `turn_plan` looks for a BOND to turn about, which cannot describe a
    ring turning over: there the axis is a diagonal, through two atoms
    that stay put while the rest of the ring swaps sides.  Two drawings
    often place a benzene on the same six points with the substituents
    moved round it, and that is exactly this motion - the ring turns
    through edge-on rather than its atoms sliding through each other,
    which would make the hexagon a bow tie for most of the transition
    and leave the inner lines of its double bonds with no inside to be
    on.

    The signature is a mirror's: every moving atom of the fragment keeps
    its coordinate ALONG the axis and has its coordinate ACROSS the axis
    negated.  That is a half turn, so the angle is not estimated.
    """
    pa = {k: np.asarray(A.nodes[k]["p"], float) for k in nmap}
    pb = {k: np.asarray(B.nodes[nmap[k]]["p"], float) for k in nmap}
    if len(nmap) < 4:
        return None
    med = np.median(np.asarray([pb[k] - pa[k] for k in nmap]), axis=0)
    res = {k: float(np.hypot(*(pb[k] - pa[k] - med))) for k in nmap}
    movers = {k for k, v in res.items() if v > fixed_tol}
    if not movers:
        return None
    nb = adj(A)
    # candidate axes: two atoms that stay put and share a ring
    seen, best = set(), None
    for bid in A.bonds:
        ring = cs.double_ring(A, bid, nb)
        if not ring or frozenset(ring) in seen:
            continue
        seen.add(frozenset(ring))
        still = [k for k in ring if k in res and res[k] <= fixed_tol]
        if len(still) != 2 or not (set(ring) & movers):
            continue
        o = pa[still[0]]
        ax = pa[still[1]] - o
        n = float(np.hypot(*ax))
        if n < 1e-9:
            continue
        ax = ax / n
        nr = np.array([-ax[1], ax[0]])
        grp, worst = [], 0.0
        for k in nmap:
            a0 = float((pa[k] - o) @ nr)
            a1 = float((pb[k] - med - o) @ nr)
            l0 = float((pa[k] - o) @ ax)
            l1 = float((pb[k] - med - o) @ ax)
            if abs(a0) > min_across and abs(a1 + a0) < along_tol \
                    and abs(l1 - l0) < along_tol:
                grp.append(k)
                worst = max(worst, abs(a1 + a0), abs(l1 - l0))
        if len(grp) < 3 or not (set(grp) & movers):
            continue
        # carry along anything hanging off the fragment that the next
        # drawing does not contain, so a substituent is not left behind
        extra = [k for k in A.nodes if k not in nmap
                 and any(x in grp for x in nb.get(k, ()))]
        rank = (-len(grp), worst)
        if best is None or rank < best[0]:
            best = (rank, o, ax, nr, grp + extra, worst)
    if best is None:
        return None
    _r, o, ax, nr, grp, worst = best
    drawn = {k: np.asarray(A.nodes[k]["p"], float) for k in A.nodes}
    solved = {}
    for k in grp:
        a0 = float((drawn[k] - o) @ nr)
        l0 = float((drawn[k] - o) @ ax)
        l1 = (float((pb[k] - med - o) @ ax) if k in pb else l0)
        solved[k] = (a0, 0.0, l0, l1)
    return dict(bond=None, theta=float(np.pi),
                origin=[float(v) for v in o], axis=[float(v) for v in ax],
                along=float(worst), swing=0.0, degrees=180.0,
                shift=[float(v) for v in med],
                group=sorted(grp), solved=solved, mirror=True)


def turn_plan(A, B, nmap, fixed_tol=0.5, along_tol=0.5, min_across=1.0,
              min_turn=15.0, depth=0):
    """How a group turns about a single bond, or None - no marking needed.

    A single bond is a rotation axis, and a group rotating about one in
    3D leaves a signature in the two drawings that sliding atoms across
    the page cannot produce: every moving atom keeps its coordinate
    ALONG the bond exactly, while its coordinate across the bond
    changes.  That identifies both THAT a turn happened and WHICH bond
    it happened about.

    The angle is then read off rather than assumed.  An atom bonded to
    the axis has a fixed distance from it in 3D - the drawn bond length
    with the along-axis part removed - and its on-page offset is that
    radius times the cosine of the dihedral, so the two drawings pin the
    rotation.  On the test case here the answer is an exact half turn:
    across-axis offsets of +12.47 and +24.94 pt become -12.47 and
    -24.95, with the along-axis offsets unchanged to 0.006 pt.

    Returned as plain numbers rather than a closure so the plan survives
    being handed to another process.  None means nothing about the pair
    looks like a turn, and the morph proceeds in the plane as always.
    """
    pa = {k: np.asarray(A.nodes[k]["p"], float) for k in nmap}
    pb = {k: np.asarray(B.nodes[nmap[k]]["p"], float) for k in nmap}
    if len(nmap) < 4:
        return None
    med = np.median(np.asarray([pb[k] - pa[k] for k in nmap]), axis=0)
    res = {k: float(np.hypot(*(pb[k] - pa[k] - med))) for k in nmap}
    movers = {k for k, v in res.items() if v > fixed_tol}
    if not movers or len(nmap) - len(movers) < 3:
        return None
    allk, nb = set(A.nodes), adj(A)
    big = max(movers, key=lambda k: res[k])
    best = None
    for bid, bd in A.bonds.items():
        u_, v_ = bd["b"], bd["e"]
        if bd["order"] != 1 or u_ in movers or v_ in movers:
            continue
        if u_ not in pa or v_ not in pa:
            continue
        sides = []
        for seed, block in ((u_, v_), (v_, u_)):
            seen, stack = {seed}, [seed]
            while stack:
                x = stack.pop()
                for y in nb[x]:
                    if x == seed and y == block:
                        continue
                    if y not in seen:
                        seen.add(y)
                        stack.append(y)
            sides.append(seen)
        if len(sides[0]) + len(sides[1]) != len(allk):
            continue                  # a ring bond is not free to turn
        # The turning group is the side carrying the atom that moves
        # furthest.  Movers on the OTHER side are left alone and
        # interpolate as always: a reaction can turn a group about a bond
        # and change something else at the same time - on the siccanin
        # page the arene swings while a methyl moves to the carbon being
        # attacked - and insisting that nothing else move would miss it.
        grp = next((s - {u_, v_} for s in sides if big in s), None)
        if not grp:
            continue
        inside = [k for k in grp if k in movers]
        if len(inside) < 2:
            continue
        o = pa[u_]
        ax = pa[v_] - o
        n = float(np.hypot(*ax))
        if n < 1e-9:
            continue
        ax = ax / n
        nr = np.array([-ax[1], ax[0]])
        along = max(abs(float((pb[k] - med - o) @ ax) - float((pa[k] - o) @ ax))
                    for k in inside)
        swing = max(abs(float((pb[k] - med - o) @ nr) - float((pa[k] - o) @ nr))
                    for k in inside)
        if along > along_tol or swing < min_across:
            continue
        # most of the movement explained, then the most local explanation
        rank = (-len(inside), len(grp), along)
        if best is None or rank < best[0]:
            best = (rank, bid, grp, along, o, ax, nr, med, swing)
    if best is None:
        # no bond works as an axis; a fragment may still have turned over
        # about a line through two atoms, which is how a ring turns
        return mirror_turn(A, B, nmap, fixed_tol, along_tol, min_across)
    _rank, bid, grp, along, o, ax, nr, med, swing = best
    ends = (A.bonds[bid]["b"], A.bonds[bid]["e"])
    angles = []
    for k in grp:
        host = [x for x in adj(A)[k] if x in ends]
        if not host or k not in pa:
            continue
        L = float(np.hypot(*(pa[k] - pa[host[0]])))
        da = float((pa[k] - o) @ ax) - float((pa[host[0]] - o) @ ax)
        r = float(np.sqrt(max(L * L - da * da, 0.0)))
        a0 = float((pa[k] - o) @ nr)
        a1 = float((pb[k] - med - o) @ nr)
        if r < 1e-6 or max(abs(a0), abs(a1)) > r * 1.05:
            continue
        # The sign is not recoverable from a flat drawing - a cosine
        # cannot tell a turn towards the viewer from one away - so only
        # the MAGNITUDE is read here.  Taking it signed makes the two
        # sides of a ring cancel: they give +180 and -180 degrees, whose
        # median is zero, which read as "no turn at all".
        angles.append(abs(float(np.arccos(np.clip(a1 / r, -1, 1))
                                - np.arccos(np.clip(a0 / r, -1, 1)))))
    if not angles:
        return None
    theta = float(np.median(angles))
    if abs(np.degrees(theta)) < min_turn:
        return None
    solved = {}
    drawn = {k: np.asarray(A.nodes[k]["p"], float) for k in A.nodes}
    for k in grp:
        a0 = float((drawn[k] - o) @ nr)
        if k in pb:
            a1 = float((pb[k] - med - o) @ nr)
            s = ((a0 * np.cos(theta) - a1) / np.sin(theta)
                 if abs(np.sin(theta)) > 1e-6 else 0.0)
            l0, l1 = float((drawn[k] - o) @ ax), float((pb[k] - med - o) @ ax)
        else:
            # nothing in the other drawing to land on - a substituent the
            # next structure omits - so it is carried round with the rest
            # of the group as if it were drawn in the plane
            s, l0 = 0.0, float((drawn[k] - o) @ ax)
            l1 = l0
        solved[k] = (a0, float(s), l0, l1)
    plan = dict(bond=bid, theta=theta, origin=[float(v) for v in o],
                axis=[float(v) for v in ax], along=along, swing=swing,
                degrees=float(np.degrees(theta)),
                # the axis is measured with the drawings' common offset
                # removed, so the offset has to be put back on the way out
                shift=[float(v) for v in med],
                group=sorted(grp), solved=solved)
    # One axis explains one group.  A figure redrawn with two arenes both
    # turned over needs two, so whatever this turn did not explain is
    # searched again, and the further plans ride along with the first.
    rest = {k: v for k, v in nmap.items() if k not in set(plan["solved"])}
    if depth < 3 and len(rest) >= 4:
        more = turn_plan(A, B, rest, fixed_tol, along_tol, min_across,
                         min_turn, depth + 1)
        if more is not None:
            plan["more"] = [more] + list(more.pop("more", []))
            plan["group"] = sorted(set(plan["group"])
                                   | {k for m in plan["more"] for k in m["group"]})
    return plan


def turn_at(plan, t):
    """Where each turning atom sits at `t`, and how far out of the page.

    Across the axis the atom follows a cosine, as a point going round a
    circle does seen edge-on, so the group foreshortens through the turn
    instead of sliding.  Both ends are the drawings exactly.
    """
    o = np.asarray(plan["origin"], float)
    ax = np.asarray(plan["axis"], float)
    nr = np.array([-ax[1], ax[0]])
    th = plan["theta"] * float(t)
    out = {}
    shift = np.asarray(plan.get("shift", (0.0, 0.0)), float) * float(t)
    for k, (a0, s, l0, l1) in plan["solved"].items():
        ac = a0 * np.cos(th) - s * np.sin(th)
        out[k] = (o + (l0 * (1 - t) + l1 * t) * ax + ac * nr + shift,
                  float(a0 * np.sin(th) + s * np.cos(th)))
    # a transition can turn more than one group - a figure redrawn with
    # two arenes both turned over - and each needs its own axis, so
    # further turns hang off the first and are merged here
    for sub in plan.get("more", ()):
        out.update(turn_at(sub, t))
    return out


def turn_pairs(A, B, nmap, tol=0.45):
    """Extra atom pairs that only the turn can see.

    Matching atoms by where they sit on the page cannot pair a
    substituent that swapped sides during a turn - the two drawings put
    it in quite different places.  Once the axis and angle are known
    from the atoms that DID pair, every remaining atom of the turning
    group has a predicted landing place, and pairing against that works:
    on the test case the methyl's predicted position is 4.7 pt from the
    methyl in the other drawing and 18.7 pt or more from anything else.

    `tol` is a fraction of a bond length.  Returns {} unless the pair
    looks like a turn at all.
    """
    plan = turn_plan(A, B, nmap)
    if plan is None:
        return {}
    taken = set(nmap.values())
    free_b = [k for k in B.nodes if k not in taken]
    free_a = [k for k in plan["group"] if k not in nmap]
    if not free_a or not free_b:
        return {}
    lengths = [float(np.hypot(*(np.asarray(A.nodes[b["e"]]["p"], float)
                                - np.asarray(A.nodes[b["b"]]["p"], float))))
               for b in A.bonds.values()]
    near = tol * float(np.median(lengths)) if lengths else 6.0
    landed = turn_at(plan, 1.0)
    out = {}
    for k in free_a:
        if k not in landed:
            continue
        want = landed[k][0]
        best = sorted(((float(np.hypot(*(np.asarray(B.nodes[j]["p"], float) - want))), j)
                       for j in free_b if j not in out.values()),
                      key=lambda q: q[0])
        if not best or best[0][0] > near:
            continue
        # the glyph has to agree: a methyl does not become an oxygen
        la = (A.nodes[k]["label"] or {}).get("text") or ""
        lb = (B.nodes[best[0][1]]["label"] or {}).get("text") or ""
        if la != lb:
            continue
        out[k] = best[0][1]
    return out


def rings_of(sc, size=6):
    """Rings of `size` atoms, each as an ordered cycle of node keys."""
    nb = adj(sc)
    seen, out = set(), []
    for start in sc.nodes:
        stack = [(start, [start])]
        while stack:
            node, path = stack.pop()
            if len(path) == size:
                if path[0] in nb[node]:
                    key = frozenset(path)
                    if key not in seen:
                        seen.add(key)
                        out.append(path)
                continue
            for nxt in nb[node]:
                if nxt in path or nxt < start:
                    continue
                stack.append((nxt, path + [nxt]))
    return out


def mirrored_rings(A, B, nmap):
    """Aromatic rings a mapping turns inside out, as atom-id lists.

    Two drawings often place a benzene on the SAME six points, and a
    hexagon's points are symmetric, so a pairing can map the ring onto
    its own mirror image without breaking a single bond.  Nothing is
    wrong with the bonds - every double still meets a double - but each
    double bond lands on its mirror partner, so the double bonds swap
    places in the ring, and getting there the ring flattens to a line
    and turns inside out.  Both are visible, and neither is what the
    drawings show, so a mapping that does this is worth reporting.
    """
    def area(poly):
        s = 0.0
        for i in range(len(poly)):
            x0, y0 = poly[i]
            x1, y1 = poly[(i + 1) % len(poly)]
            s += x0 * y1 - x1 * y0
        return 0.5 * s

    nb = adj(A)
    out, seen = [], set()
    for bid in A.bonds:
        ring = cs.double_ring(A, bid, nb)
        if not ring or not cs._alternating(A, ring, nb):
            continue
        key = frozenset(ring)
        if key in seen or not all(k in nmap for k in ring):
            continue
        seen.add(key)
        pa = [tuple(A.nodes[k]["p"]) for k in ring]
        pb = [tuple(B.nodes[nmap[k]]["p"]) for k in ring]
        if area(pa) * area(pb) < 0:
            out.append([A.nodes[k]["atom_id"] for k in ring])
    return out


def kekule_shift(A, B, nmap, bmap):
    """Ring bonds whose double bonds only MOVE round the ring.

    A benzene ring drawn with its double bonds in the other three
    positions is the same aromatic ring, not a different one - the two
    Kekule forms are a drawing choice.  Animating the change makes every
    double bond in the ring fade out while its neighbour fades in, so the
    ring appears to pulse, which is what a chemist reads as the double
    bonds moving.

    Returned only when the ring is untouched by the reaction: every ring
    bond carried through, the orders strictly alternating in both
    drawings, and every one of them swapped.  A ring with a bond being
    made or broken is a real change and is animated as one.
    """
    out = set()
    for ring in rings_of(A, 6):
        ids, orders_a, orders_b, ok = [], [], [], True
        for i in range(6):
            u, v = ring[i], ring[(i + 1) % 6]
            bid = next((b for b, bd in A.bonds.items()
                        if {bd["b"], bd["e"]} == {u, v}), None)
            if bid is None or bid not in bmap:
                ok = False
                break
            ids.append(bid)
            orders_a.append(A.bonds[bid]["order"])
            orders_b.append(B.bonds[bmap[bid]]["order"])
        if not ok or sorted(orders_a) != [1, 1, 1, 2, 2, 2]:
            continue
        if any(orders_a[i] == orders_a[(i + 1) % 6] for i in range(6)):
            continue                      # not alternating: not aromatic
        if any(oa == ob for oa, ob in zip(orders_a, orders_b)):
            continue                      # some bond really does change
        if sorted(orders_b) != [1, 1, 1, 2, 2, 2]:
            continue
        out.update(ids)
    return out


def kekule_time(A, bids, plan=None):
    """When to switch a ring from one Kekule form to the other.

    The switch is discrete - three inner lines move to the other three
    bonds - so it is made in a single frame rather than faded, and put
    where it cannot be seen.  If the ring turns, that is the moment it
    passes edge-on: the ring is a line then and has no inner lines to
    notice.  Otherwise it falls at the midpoint, where it is a single
    frame's change rather than six bonds pulsing throughout.
    """
    if plan is None or not bids:
        return 0.5
    ring = {k for b in bids for k in (A.bonds[b]["b"], A.bonds[b]["e"])}
    if not ring <= set(plan["group"]):
        return 0.5
    th = abs(plan["theta"])
    if th < 1e-6:
        return 0.5
    return float(min(1.0, max(0.0, (np.pi / 2) / th)))


def reflection_axis(A, B, nmap, margin=1.25):
    """Axis to turn about when the two drawings are mirror images.

    A structure redrawn after a rotation in three dimensions usually
    arrives on the page as a reflection of the original.  No in-plane
    motion can reach it, so interpolating positions straight across
    crushes the structure through a degenerate midpoint instead of
    turning it over.  Detect that case by comparing the best proper fit
    against the best improper one; `margin` is how much better the
    reflection must be before it is believed.

    Returns (point on axis, unit direction) or None.
    """
    if not ALLOW_FLIP or len(nmap) < 3:
        return None
    X = np.array([A.nodes[a]["p"] for a in nmap], float)
    Y = np.array([B.nodes[b]["p"] for b in nmap.values()], float)
    xc, yc = X.mean(0), Y.mean(0)
    U, _, Vt = np.linalg.svd((X - xc).T @ (Y - yc))
    # det(Vt.T @ diag(1, s) @ U.T) = s * det(Vt.T @ U.T), so which sign of s
    # gives a rotation and which gives a reflection depends on d0
    d0 = np.sign(np.linalg.det(Vt.T @ U.T)) or 1.0
    fit = {}
    for want in (1.0, -1.0):                      # +1 rotation, -1 reflection
        M = Vt.T @ np.diag([1.0, want * d0]) @ U.T
        fit[want] = (float(np.sqrt((((Y - yc) - (X - xc) @ M.T) ** 2)
                                   .sum(1).mean())), M)
    proper, improper = fit[1.0], fit[-1.0]
    if improper[0] * margin >= proper[0]:
        return None
    # a 2-D improper orthogonal map is a reflection; its +1 eigenvector is
    # the mirror line, which is the axis the structure turns about
    w, v = np.linalg.eig(improper[1])
    axis = np.real(v[:, int(np.argmin(np.abs(w - 1.0)))])
    n = float(np.hypot(*axis))
    return (xc, axis / n) if n > 1e-9 else None


def flow(sc, other, nmap, t, flip=None, pinned=None):
    """Node positions of `sc` at time t: matched nodes interpolate toward
    their partner, unmatched nodes ride along with matched neighbours.

    `flip` is a (point, direction) axis from `reflection_axis`.  When set,
    the structure turns about that in-plane axis through half a turn as t
    runs 0 -> 1: the component across the axis scales by cos(pi t), so the
    drawing is seen edge-on at the midpoint and arrives mirrored, which is
    what a molecule rotating out of the page actually looks like.  The
    residual difference to the target is carried on top, so t = 1 still
    lands exactly on the partner structure.
    """
    nbr = adj(sc)
    P, disp = {}, {}
    if flip is not None:
        origin, u = flip
        c = float(np.cos(np.pi * t))

        def turn(p):
            d = p - origin
            par = float(d @ u) * u
            return origin + par + c * (d - par)
    for a in sc.nodes:
        pa = np.asarray(sc.nodes[a]["p"], float)
        if a in nmap:
            pb = np.asarray(other.nodes[nmap[a]]["p"], float)
            if pinned is not None and a in pinned:
                P[a] = pinned[a]
            elif flip is None:
                P[a] = pa * (1 - t) + pb * t
            else:
                # turn, then carry the leftover difference linearly
                P[a] = turn(pa) + t * (pb - turn_end(pa, origin, u))
            disp[a] = P[a] - pa
    for _ in range(8):
        for a in sc.nodes:
            if a in disp:
                continue
            d = [disp[n] for n in nbr[a] if n in disp]
            if d:
                disp[a] = np.mean(d, axis=0)
    for a in sc.nodes:
        if a not in P:
            if pinned is not None and a in pinned:
                P[a] = pinned[a]       # carried round with its group
            else:
                P[a] = (np.asarray(sc.nodes[a]["p"], float)
                        + disp.get(a, np.zeros(2)))
    return P


def ramp(t, lo, hi, smooth=True):
    """0 below `lo`, 1 above `hi`.

    Eased by default: a bond that appears or disappears should dissolve,
    and a linear ramp has a corner at each end, so the stroke snaps into
    view at full rate and stops dead at the other end.  Smoothstep leaves
    zero slope at both ends, which reads as a fade rather than a switch.
    """
    u = float(np.clip((t - lo) / (hi - lo), 0.0, 1.0))
    return u * u * (3.0 - 2.0 * u) if smooth else u


def _double_side(sc, bid, P, nbr):
    """+-1 offset side for a double bond, 0 for a symmetric one.

    One implementation, in scene.double_side, so the still renderer and
    the animator cannot disagree about which side the inner line is on.

    Where the rule cannot decide - a terminal C=O, whose oxygen has no
    second neighbour to weigh - the still renderer falls back to one side,
    and so must this: without the fallback the offset is zero, both lines
    land on top of each other, and a ketone draws as a single bond for the
    whole of a reaction, its first frame included.
    """
    # Zero means the rule cannot place an inner line - a terminal C=O,
    # whose oxygen has no second neighbour to weigh.  Pass it through:
    # the emitter draws those as a pair straddling the axis, which is
    # what the still renderer draws.  Forcing it to one side here made
    # a ketone change shape at the join between a turn and a reaction.
    return cs.double_side(sc, bid, P, nbr)


def _neighbours(sc, bid, P, nbr):
    """Positions of the bonds leaving each end of `bid`, in current frame
    coordinates - what the inner line of a double bond must stop short of."""
    b = sc.bonds[bid]
    return ([P[m] for m in nbr[b["b"]] if m != b["e"]],
            [P[m] for m in nbr[b["e"]] if m != b["b"]])


def _splittable(lab, p=None):
    """Whether a label can be drawn as attachment glyph plus remainder.

    The split keeps the attachment glyph anchored while the rest of the
    group swings round the atom, which is what a flipping NH needs.  It
    places the two pieces by their own ink, so a label the canvas
    RESTYLES - a subscript drawn smaller, an italic prefix - would land
    its pieces a point or two from where the same label is drawn at
    rest.  Those cross-dissolve instead: the endpoints are then exactly
    the two drawings, which matters more than the glyph staying put.
    """
    if not lab:
        return False
    d = dict(kind="text", text=_shown(lab, p), size=lab["size"],
             bold=lab["bold"], italic=lab.get("italic", False),
             weight=lab.get("weight"), runs=lab.get("runs"),
             anchor=(0.0, 0.0), just="Left")
    try:
        return len(cs.styled_pieces(d)) <= 1
    except Exception:
        return False


def _shown(lab, p=None):
    """The string a label actually draws.

    A group is reordered so the atom its bond meets sits against the
    bond, so the same stored text displays two different ways depending
    on which side of its atom the label was drawn.  Takes the atom so it
    asks the same question `scene.build_strokes` does - the two must
    agree exactly or a label jumps between the still and the animation.
    """
    if not lab:
        return None
    return cs.drawn_order(lab["text"], cs.label_side(lab, p), lab.get("runs"),
                          lab.get("attach"))


def _stereo_of(sc, bid, P):
    """(display, begin point) for a wedge or hash bond, else None."""
    bd = sc.bonds[bid]
    d = bd.get("display", "Solid")
    if d not in cs.WEDGE_DISPLAYS or bd["order"] != 1 or bd["b"] not in P:
        return None
    return (d, np.asarray(P[bd["b"]], float), cs.hash_count(sc, bid))


_STEREO_FLIP = {"WedgeBegin": "WedgeEnd", "WedgeEnd": "WedgeBegin",
                "WedgedHashBegin": "WedgedHashEnd",
                "WedgedHashEnd": "WedgedHashBegin"}


def _stereo_as_drawn(display, B, bid_B, A_begin, nmap):
    """`display` for a B bond, expressed along the A bond's direction.

    ChemDraw says which END of a bond a wedge narrows to, so the label is
    only meaningful together with the direction the bond is stored in.
    The two drawings may store the same bond the opposite way round - a
    methyl wedge written C->Me in one and Me->C in the other - and the
    stroke is drawn along A's direction, so B's word has to be turned
    around with it or the wedge points at the wrong atom.
    """
    if display == "Solid" or bid_B not in B.bonds:
        return display
    same = nmap.get(A_begin) == B.bonds[bid_B]["b"]
    return display if same else _STEREO_FLIP.get(display, display)


def _scaled(flanks, alpha):
    """The same tracks at a fraction of their opacity (for a crossfade)."""
    if flanks is None:
        return None
    return [(m, al * float(alpha), meta) for m, al, meta in flanks]


def _order_tracks(oa, ob, t, side_a, side_b, sep, nbrs, margin):
    """The parallel lines a bond draws while its ORDER changes.

    A triple bond is a centre line with a flank either side; a double drawn
    to one side is the centre line and ONE flank; a symmetric double is the
    two flanks at half the spacing and no centre.  Writing all three as the
    same three tracks - centre, near flank, far flank - means an alkyne
    becoming an alkene keeps the lines the two drawings share exactly where
    they are, and only the line that is not in the product fades.  Before
    this, nothing scheduled the change at all: a triple stayed a triple
    through the whole reaction and into the product.

    Each track is (offset in units of `sep`, opacity, inner-line metadata).
    """
    ref = side_b if side_b else (side_a if side_a else 1.0)

    def side_of(order, s):
        if order >= 3:
            return [(0.0, 1.0), (1.0, 1.0), (-1.0, 1.0)]
        if order == 2:
            if s:
                near = 1.0 if s * ref > 0 else -1.0
                return [(0.0, 1.0), (near, 1.0), (-near, 0.0)]
            return [(0.0, 0.0), (0.5, 1.0), (-0.5, 1.0)]
        return [(0.0, 1.0), (1.0, 0.0), (-1.0, 0.0)]

    fa, fb = side_of(oa, side_a), side_of(ob, side_b)
    inner_at = None
    if ob == 2 and side_b:
        inner_at, trim = 1, float(t)          # becomes a double's inner line
    elif oa == 2 and side_a:
        inner_at, trim = 1, 1.0 - float(t)    # was one
    out = []
    for i, ((ma, aa), (mb, ab)) in enumerate(zip(fa, fb)):
        m = ma * (1.0 - t) + mb * t
        al = aa * (1.0 - t) + ab * t
        meta = None
        if i == inner_at and nbrs:
            meta = dict(off=m * ref * sep, trim=trim,
                        nbrs=([np.asarray(x, float) for x in nbrs[0]],
                              [np.asarray(x, float) for x in nbrs[1]]))
        out.append((m * ref, al, meta))
    return out


def _emit(lines, p0, p1, side, sep, col, z, alpha, w, ends, grp, second_alpha,
          nbrs=None, margin=0.0, stereo=None, triple=False, flanks=None):
    """Append the 1 or 2 strokes of a bond.

    `stereo` is (display, begin_point) for a wedge or hash; it only applies
    to a single bond, which is the only kind ChemDraw draws that way.
    `triple` draws three lines instead of two.
    """
    if triple:
        # centre line plus one either side, at the spacing a double bond
        # uses between its two.  A triple bond is linear, so it is always
        # symmetric - `side` does not apply.  The flanking pair carries
        # `second_alpha`, so a bond becoming or ceasing to be a triple
        # opens out of, and collapses back into, the single line.
        #
        # `flanks` overrides that pair where the two drawings disagree about
        # which lines exist - an alkyne that becomes an alkene keeps the
        # flank on the side the product draws its double, and loses the
        # other one.  Each entry is (sign, alpha, inner-metadata or None).
        d = p1 - p0
        n = np.array([-d[1], d[0]]) / np.hypot(*d)
        frac = min(1.0, second_alpha / alpha) if alpha > 1e-6 else 1.0
        tracks = flanks if flanks is not None else (
            (0, alpha, None), (+1, second_alpha, None), (-1, second_alpha, None))
        for sgn, al, inner in tracks:
            if al <= 0.004:
                continue
            off = sgn * frac * sep * n
            row = dict(p0=p0 + off, p1=p1 + off, color=col, z=z,
                       alpha=al, w=w, ends=ends, grp=grp,
                       stereo=stereo if sgn == 0 else None)
            if inner is not None:
                row["base"] = (p0.copy(), p1.copy())
                row["inner"] = inner
            lines.append(row)
        return
    if second_alpha <= 0.01:
        lines.append(dict(p0=p0, p1=p1, color=col, z=z, alpha=alpha,
                          w=w, ends=ends, grp=grp, stereo=stereo))
        return
    d = p1 - p0
    n = np.array([-d[1], d[0]]) / np.hypot(*d)
    # How "double" the bond is right now.  The separation grows with it, so
    # a forming double bond opens out of the single line rather than having
    # the first line jump sideways the instant the second one appears.
    frac = min(1.0, second_alpha / alpha) if alpha > 1e-6 else 1.0
    if side == 0.0:
        # symmetric pair: both lines run the FULL length, so the double
        # bond reaches its own atoms (see scene.build_strokes)
        for sgn in (+1, -1):
            off = sgn * frac * sep / 2 * n
            a = alpha if sgn > 0 else second_alpha
            # the stereo artwork belongs to the bond, so it rides the first
            # stroke only - a hash on both lines would double the rungs
            lines.append(dict(p0=p0 + off, p1=p1 + off, color=col, z=z,
                              alpha=a, w=w, ends=ends, grp=grp,
                              stereo=stereo if sgn > 0 else None,
                              base=(p0.copy(), p1.copy()),
                              inner=dict(off=sgn * frac * sep / 2, nbrs=None,
                                         full=True)))
    elif abs(float(side)) < 1e-9:
        # The side rule cannot place an inner line when one end is terminal
        # - a ketone's oxygen has nothing to weigh against - and ChemDraw,
        # like the still renderer, draws those as two lines straddling the
        # axis at half the spacing, both running the full length.  Drawing
        # them any other way here makes the bond change shape at the seam
        # between the animation and the drawings it runs between.
        for sgn in (+1.0, -1.0):
            off = sgn * frac * sep / 2 * n
            # `base` is the bond itself: both lines are trimmed through it,
            # not each on its own, or the one nearer a label is cut back at
            # that label's box and the pair comes out uneven.
            lines.append(dict(p0=p0 + off, p1=p1 + off, color=col, z=z,
                              alpha=alpha, w=w, ends=ends, grp=grp,
                              stereo=stereo if sgn > 0 else None,
                              base=(p0.copy(), p1.copy()),
                              inner=dict(off=sgn * frac * sep / 2, nbrs=None,
                                         full=True)))
        return
    else:
        lines.append(dict(p0=p0, p1=p1, color=col, z=z, alpha=alpha,
                          w=w, ends=ends, grp=grp, stereo=stereo))
        q0 = p0 + side * frac * sep * n
        q1 = p1 + side * frac * sep * n
        if nbrs:
            a, b = cs.inner_span(q0, q1, p0, nbrs[0], p1, nbrs[1],
                                 w + margin)
        else:
            a, b = cs.INNER_DEFAULT_INSET, 1.0 - cs.INNER_DEFAULT_INSET
        # The inner line is rebuilt in assemble() once the main stroke has
        # been trimmed at its labels, which is the order the still
        # renderer uses; computing it here off the untrimmed bond would
        # place it differently from the drawing it has to reproduce.
        lines.append(dict(p0=q0 + a * (q1 - q0), p1=q0 + b * (q1 - q0),
                          color=col, z=z, alpha=second_alpha, w=w,
                          ends=ends, grp=grp, base=(p0.copy(), p1.copy()),
                          inner=dict(off=side * frac * sep,
                                     nbrs=([np.asarray(x, float) for x in nbrs[0]],
                                           [np.asarray(x, float) for x in nbrs[1]])
                                     if nbrs else None)))


def _side_for(B, bid_B, PB, nB, A_begin, nmap):
    """`_double_side` for a B bond, expressed in the A bond's direction.

    The stroke is drawn along the A bond, so its offset normal comes from
    A's begin->end direction.  When the matched B bond runs the other way
    that normal is flipped, and an inner line meant for the inside of a
    ring lands outside it.
    """
    side = _double_side(B, bid_B, PB, nB)
    return -side if nmap.get(A_begin) != B.bonds[bid_B]["b"] else side


def frame(A, B, nmap, bmap, t, out_end=None, in_start=None, bover=None,
          flip=None, turn=None, kekule=None):
    """Everything drawn at time t: (lines, labels, boxes).

    bover : {A_bond_id: (B_bond_id, mover_A_node, dest_A_node)}
        A 1,2-shift.  The bond keeps its other end on its own atom; the
        `mover` end walks along the mover-dest bond until it sits on `dest`.
        Because the terminus is interpolated between the two atoms' own
        trajectories, it stays on the line joining them for the whole
        transit instead of cutting across open space."""

    if out_end is None:
        out_end = DISSOLVE
    if in_start is None:
        in_start = 1.0 - DISSOLVE
    inv = {v: k for k, v in nmap.items()}
    # not `bover or {}`: an override object carrying only slides is an
    # empty mapping, and so falsy, which would discard the slides
    bover = {} if bover is None else bover
    binv = {v: k for k, v in bmap.items()}
    binv.update({v[0]: k for k, v in bover.items()})
    # a group turning about a single bond: one set of positions, used for
    # both structures, so a surviving bond cannot disagree with itself
    pin_a = pin_b = None
    if turn is not None:
        pos = {k: v[0] for k, v in turn_at(turn, float(t)).items()}
        pin_a = pos
        pin_b = {nmap[k]: v for k, v in pos.items() if k in nmap}
    PA = flow(A, B, nmap, t, flip=flip, pinned=pin_a)
    # B is the destination, so it is placed by turning backwards from
    # its own frame - both structures agree at every t
    PB = flow(B, A, inv, 1.0 - t,
              flip=None if flip is None else (flip[0], flip[1]),
              pinned=pin_b)
    nA, nB = adj(A), adj(B)
    zA, zB = znorm(A), znorm(B)
    lw = A.doc["LineWidth"]
    sep = A.doc["BondSpacing"] / 100.0 * A.doc["BondLength"]
    fade_out = 1.0 - ramp(t, 0.0, out_end)
    fade_in = ramp(t, in_start, 1.0)

    # A sliding line is drawn once, travelling; the bond it leaves and the
    # bond it joins must not also fade one in and out underneath it.
    slides = getattr(bover, "slides", ())
    hush_second = {s[0] for s in slides} | {s[3] for s in slides
                                            if s[3] is not None}
    hush_arrive = {s[4] for s in slides if s[3] is None}

    def ka(a):
        return "M:" + a if a in nmap else "A:" + a

    def kb(b):
        return "M:" + inv[b] if b in inv else "B:" + b

    lines, labels, boxes = [], [], {}

    for aid, a in A.bonds.items():
        p0, p1 = PA[a["b"]], PA[a["e"]]
        col = np.array(A.rgb(a["color"]))
        z, alpha = zA[a["z"]], 1.0
        second = 1.0 if a["order"] >= 2 else 0.0
        side = _double_side(A, aid, PA, nA) if a["order"] == 2 else 0.0
        triple = a["order"] >= 3
        flanks = None
        hushed = aid in hush_second
        if aid in bmap:
            bb = B.bonds[bmap[aid]]
            col = col * (1 - t) + np.array(B.rgb(bb["color"])) * t
            z = z * (1 - t) + zB[bb["z"]] * t
            # a triple at EITHER end draws three lines throughout, the
            # flanking pair fading in or out; switching on the count
            # mid-way would show a double bond in between
            triple = a["order"] >= 3 or bb["order"] >= 3
            kek = kekule is not None and aid in kekule[0]
            if kek:
                # the ring's double bonds hold where they are drawn and
                # change in one frame, instead of each fading out while
                # its neighbour fades in - which reads as the double
                # bonds travelling round the ring
                src = bb if float(t) >= kekule[1] else a
                second = 1.0 if src["order"] >= 2 else 0.0
                side = 0.0
                if src["order"] == 2:
                    side = (_side_for(B, bmap[aid], PB, nB, a["b"], nmap)
                            if src is bb else _double_side(A, aid, PA, nA))
            elif bb["order"] >= 2 and a["order"] < 2:
                second, side = t, _side_for(B, bmap[aid], PB, nB,
                                            a["b"], nmap)
            elif a["order"] >= 2 and bb["order"] < 2:
                second = 1.0 - t
            if kek:
                pass
            elif max(a["order"], bb["order"]) >= 3 and a["order"] != bb["order"]:
                # an alkyne becoming an alkene, or the reverse
                flanks = _order_tracks(
                    a["order"], bb["order"], t,
                    _double_side(A, aid, PA, nA) if a["order"] == 2 else 0.0,
                    _side_for(B, bmap[aid], PB, nB, a["b"], nmap)
                    if bb["order"] == 2 else 0.0,
                    sep, _neighbours(A, aid, PA, nA), A.doc["MarginWidth"])
                second = 1.0
            elif a["order"] == 2 and bb["order"] == 2:
                # The two drawings may put the inner line on opposite
                # sides.  Which side it is on is a CHOICE, not a quantity:
                # blending -1 to +1 walks the line through the bond and
                # out the other side, so a ring's inner line spends half
                # the transition outside its ring.
                #
                # Inside a ring there is no choice to carry across - the
                # inner line belongs inside, at every frame - so the side
                # is taken from the frame's own geometry, which is what
                # `_double_side` measures.  Elsewhere the drawn side is
                # held and changed in a single frame, at the midpoint.
                side_b = _side_for(B, bmap[aid], PB, nB, a["b"], nmap)
                ring = cs.double_ring(A, aid, nA)
                if side == 0.0 and side_b == 0.0:
                    # Neither drawing puts an inner line on a side, because
                    # one end is terminal - a ketone.  There is nothing to
                    # slide, and nudging the side off zero turns the pair
                    # that straddles the bond into a main line with an inner
                    # one almost on top of it, which is a visible change of
                    # shape where a turn hands over to a reaction.
                    pass
                elif not (ring and cs._alternating(A, ring, nA)):
                    # outside a ring there is nothing for the line to leave,
                    # so rather than switching in a single frame it closes
                    # onto its bond and opens on the other side, over a short
                    # window around the midpoint
                    w = min(max((float(t) - 0.35) / 0.30, 0.0), 1.0)
                    side = side * (1.0 - w) + side_b * w
                    if abs(side) < 0.02:
                        side = 0.02 * (1.0 if side_b > 0 else -1.0)
            if hushed:
                second = 0.0
        elif aid in bover:
            tgt, mover, dest = bover[aid]
            bb = B.bonds[tgt]
            # the migrating end rides the segment joining the two atoms'
            # own trajectories, so it never leaves the mover-dest line
            walk = PA[mover] * (1 - t) + PA[dest] * t
            if a["b"] == mover:
                p0, p1 = walk, PA[a["e"]]
            else:
                p0, p1 = PA[a["b"]], walk
            col = col * (1 - t) + np.array(B.rgb(bb["color"])) * t
            z = z * (1 - t) + zB[bb["z"]] * t
            # a triple at EITHER end draws three lines throughout, the
            # flanking pair fading in or out; switching on the count
            # mid-way would show a double bond in between
            triple = a["order"] >= 3 or bb["order"] >= 3
            if bb["order"] >= 2 and a["order"] < 2:
                second, side = t, _side_for(B, tgt, PB, nB,
                                            a["b"], nmap)
            elif a["order"] >= 2 and bb["order"] < 2:
                second = 1.0 - t
            ends = (ka(a["b"]), ka(a["e"]), ka(dest))
        else:
            alpha = fade_out
        if alpha > 0.01:
            e = ends if aid in bover else (ka(a["b"]), ka(a["e"]))
            st_a = _stereo_of(A, aid, PA)
            # A stereocentre that changes between the two drawings - a wedge
            # that becomes plain, or becomes a hash - cannot be interpolated,
            # so the two renderings cross-dissolve on the bond schedule.
            tgt_b = bmap.get(aid) or (bover[aid][0] if aid in bover else None)
            st_b = _stereo_of(B, tgt_b, PB) if tgt_b else None
            da = st_a[0] if st_a else "Solid"
            db = st_b[0] if st_b else "Solid"
            if da != db:
                # A stereo rendering has no halfway shape - a wedge is not
                # half a hash - and cross-dissolving the two draws the bond
                # TWICE: two parallel lines at half opacity, which read as a
                # double bond appearing where there is none.  So the change
                # is made in a single frame, as the ring's Kekule switch is,
                # at the midpoint - or where the bond passes edge-on, if its
                # group turns, since nothing of it is visible there.
                t_sw = 0.5
                if turn is not None and abs(turn["theta"]) > 1e-6 \
                        and a["b"] in set(turn["group"]) \
                        and a["e"] in set(turn["group"]):
                    t_sw = min(1.0, max(0.0,
                                        (np.pi / 2) / abs(turn["theta"])))
                st_use = st_a
                if float(t) >= t_sw:
                    st_use = ((_stereo_as_drawn(db, B, tgt_b, a["b"], nmap),
                               st_a[1] if st_a else PA[a["b"]],
                               cs.hash_count(B, tgt_b))
                              if db != "Solid" else None)
                _emit(lines, p0, p1, side, sep, tuple(col), z, alpha, lw,
                      e, "A" + aid, second * alpha,
                      _neighbours(A, aid, PA, nA), A.doc["MarginWidth"],
                      stereo=st_use, triple=triple,
                      flanks=_scaled(flanks, alpha))
            else:
                _emit(lines, p0, p1, side, sep, tuple(col), z, alpha, lw,
                      e, "A" + aid, second * alpha,
                      _neighbours(A, aid, PA, nA), A.doc["MarginWidth"],
                      stereo=st_a, triple=triple,
                      flanks=_scaled(flanks, alpha))

    for bid, b in B.bonds.items():
        if bid in binv or fade_in <= 0.01 or bid in hush_arrive:
            continue
        side = _double_side(B, bid, PB, nB) if b["order"] == 2 else 0.0
        _emit(lines, PB[b["b"]], PB[b["e"]], side, sep, B.rgb(b["color"]),
              zB[b["z"]], fade_in, lw, (kb(b["b"]), kb(b["e"])), "B" + bid,
              fade_in if b["order"] >= 2 else 0.0,
              _neighbours(B, bid, PB, nB), B.doc["MarginWidth"],
              stereo=_stereo_of(B, bid, PB), triple=b["order"] >= 3)


    # ---- lines that travel from one bond to another -------------------
    # A pi bond reorganising round a ring is drawn as its inner line
    # MOVING, rather than fading out here and in there: it pivots about
    # the atom the two bonds share, or swings across to become a bond the
    # ring closure creates.  Purely a drawing choice - nothing here
    # models electrons.
    def _offset_line(sc, bid, P, nbr, s_side):
        """The inner line of a double bond, in current geometry."""
        q0, q1 = np.asarray(P[sc.bonds[bid]["b"]], float), \
                 np.asarray(P[sc.bonds[bid]["e"]], float)
        d = q1 - q0
        n = np.array([-d[1], d[0]]) / max(float(np.hypot(*d)), 1e-9)
        s = s_side if s_side else 1.0
        r0, r1 = q0 + s * sep * n, q1 + s * sep * n
        nb = _neighbours(sc, bid, P, nbr)
        if nb:
            u, v = cs.inner_span(r0, r1, q0, nb[0], q1, nb[1],
                                 lw + sc.doc["MarginWidth"])
        else:
            u, v = cs.INNER_DEFAULT_INSET, 1.0 - cs.INNER_DEFAULT_INSET
        return r0 + u * (r1 - r0), r0 + v * (r1 - r0)

    for src, tu, tv, tgt_a, tgt_b in slides:
        a0, a1 = _offset_line(A, src, PA, nA, _double_side(A, src, PA, nA))
        if tgt_a is not None:
            # onto a neighbouring bond, which gains the inner line
            b0, b1 = _offset_line(A, tgt_a, PA, nA,
                                  _side_for(B, tgt_b, PB, nB,
                                            A.bonds[tgt_a]["b"], nmap))
        else:
            # onto a bond only the product has: become that bond itself
            b0, b1 = np.asarray(PA[tu], float), np.asarray(PA[tv], float)
            if float(np.hypot(*(b0 - np.asarray(a0, float)))) > \
               float(np.hypot(*(b1 - np.asarray(a0, float)))):
                b0, b1 = b1, b0           # travel the shorter way round
        # Where the two bonds share an atom the line PIVOTS about it:
        # interpolating the endpoints in a straight line would cut the
        # chord, so the line visibly shortens mid-way instead of sweeping.
        # Turning it in polar coordinates about the shared atom keeps its
        # length and reads as one line swinging onto the next bond.
        piv = None
        if tgt_a is not None:
            shared = ({A.bonds[src]["b"], A.bonds[src]["e"]} &
                      {A.bonds[tgt_a]["b"], A.bonds[tgt_a]["e"]})
            if len(shared) == 1:
                piv = np.asarray(PA[next(iter(shared))], float)
        if piv is not None:
            a0, a1 = sorted((a0, a1), key=lambda p: np.hypot(*(np.asarray(p, float) - piv)))
            b0, b1 = sorted((b0, b1), key=lambda p: np.hypot(*(np.asarray(p, float) - piv)))
            ends_now = []
            for pa, pb in ((a0, b0), (a1, b1)):
                da = np.asarray(pa, float) - piv
                db = np.asarray(pb, float) - piv
                th_a, th_b = np.arctan2(da[1], da[0]), np.arctan2(db[1], db[0])
                d_th = (th_b - th_a + np.pi) % (2 * np.pi) - np.pi   # shorter way
                th = th_a + d_th * t
                r = float(np.hypot(*da)) * (1 - t) + float(np.hypot(*db)) * t
                ends_now.append(piv + r * np.array([np.cos(th), np.sin(th)]))
            q0, q1 = ends_now
        else:
            q0 = np.asarray(a0, float) * (1 - t) + np.asarray(b0, float) * t
            q1 = np.asarray(a1, float) * (1 - t) + np.asarray(b1, float) * t
        col = np.array(A.rgb(A.bonds[src]["color"])) * (1 - t) + \
              np.array(B.rgb(B.bonds[tgt_b]["color"])) * t
        lines.append(dict(
            p0=q0, p1=q1,
            color=tuple(col),
            z=zA[A.bonds[src]["z"]] * (1 - t) + zB[B.bonds[tgt_b]["z"]] * t,
            alpha=1.0, w=lw,
            # name the atoms it runs between, or bonds meeting there are
            # mistaken for crossings and punch a gap into each end
            ends=(ka(tu), ka(tv)) if tgt_a is None
                 else (ka(A.bonds[tgt_a]["b"]), ka(A.bonds[tgt_a]["e"])),
            grp="S" + src, stereo=None))

    def push(sc, nid, P, key, z, alpha, tint=None, tt=0.0, to=None):
        """Emit an atom label.

        `to` is the partner label this one becomes.  A label's box and
        anchor are given per structure, and its justification can differ
        between the two even when the text is identical - ChemDraw writes
        the same methyl Left-aligned in one drawing and Right-aligned in
        the next.  Holding the source's values for the whole transition
        makes the glyph jump to the target's at the stage boundary, so
        both are interpolated, and a justification that changes is
        resolved by positioning from the box instead.
        """
        lab = sc.nodes[nid]["label"]
        if not lab or alpha <= 0.01:
            return
        # A label is placed by its OFFSET from its own atom, and that offset
        # is what interpolates - never the absolute box.  Averaging absolute
        # boxes puts the label halfway between where the atom is now and
        # where it ends up, so it drifts off its own atom mid-morph while
        # still landing correctly at both ends.
        here = np.asarray(P[nid], float)
        pa = np.asarray(sc.nodes[nid]["p"], float)
        obx = [lab["bbox"][i] - pa[i % 2] for i in range(4)]
        oan = [lab["anchor"][i] - pa[i] for i in range(2)]
        if to is not None:
            pb = np.asarray(to["p"], float)
            obx = [obx[i] * (1 - tt) + (to["bbox"][i] - pb[i % 2]) * tt
                   for i in range(4)]
            oan = [oan[i] * (1 - tt) + (to["anchor"][i] - pb[i]) * tt
                   for i in range(2)]
        bx = [here[i % 2] + obx[i] for i in range(4)]
        anc = [here[i] + oan[i] for i in range(2)]
        # the order ChemDraw draws it in - shared with scene.build_strokes
        txt = cs.drawn_order(lab["text"], cs.label_side(lab, pa),
                             lab.get("runs"), lab.get("attach"))
        # Each drawing's OWN justification and anchor are used, so either
        # end of the transition is exactly what ChemDraw drew.  Where the
        # two agree - nearly always - the anchor simply interpolates.
        # Where they disagree the placement cannot be averaged here,
        # because it depends on how wide the canvas lays the text out;
        # the canvas is told both and blends them itself.
        just = lab["just"]
        ax_a = here[0] + (lab["anchor"][0] - pa[0])
        just_b, ax_b = just, ax_a
        if to is not None:
            tb = cs.drawn_order(to["text"], cs.label_side(to, pb),
                                to.get("runs"), to.get("attach"))
            if tb == txt:
                just_b = to["just"]
                ax_b = here[0] + (to["anchor"][0] - pb[0])
        blend = None
        if just_b == just:
            anc = [ax_a * (1 - tt) + ax_b * tt, anc[1]]
        else:
            anc = [ax_a, anc[1]]
            blend = (just_b, ax_b, float(tt))
        col = np.array(sc.rgb(lab["color"]))
        if tint is not None:
            col = col * (1 - tt) + np.array(tint) * tt
        # size travels too: the two drawings may set a label a twentieth
        # of a point apart, which is invisible in motion but leaves the
        # last frame not quite the structure as drawn
        size = lab["size"]
        if to is not None:
            size = lab["size"] * (1 - tt) + to["size"] * tt
        common = dict(size=size, bold=lab["bold"], color=tuple(col),
                      z=z, alpha=alpha, margin=sc.doc["MarginWidth"])
        if blend is not None:
            common["blend"] = blend
        # A label ChemDraw stacks stays stacked as it moves, computed from
        # the interpolated box so the lines travel with it.  Whether it is
        # stacked at all can CHANGE between drawings - the same group
        # written on one line in one structure and over two in the next -
        # and there is no halfway between the two layouts, so they
        # cross-dissolve, as a changing wedge does.
        def emit(text, one_line_txt, one_line_just, align, weight,
                 stacked=True):
            if weight <= 0.01:
                return
            kw = dict(common, alpha=common["alpha"] * weight)
            # the LINES come from the travelling box, so they move with the
            # label; whether there are lines at all was settled at the ends
            ls = (cs.stacked_lines(text, bx, common["size"], lab["bold"], align)
                  if stacked else None)
            if ls:
                kw.pop("blend", None)
                for line, lx, ly in ls:
                    labels.extend(cs.styled_pieces(dict(
                        text=line, anchor=(lx, ly), bbox=bx,
                        just="Left", id=nid, runs=lab.get("runs"), **kw)))
            else:
                labels.extend(cs.styled_pieces(dict(
                    text=one_line_txt, anchor=tuple(anc), bbox=bx,
                    just=one_line_just, id=nid, runs=lab.get("runs"), **kw)))

        align_a = lab["align"]
        align_b = to["align"] if to is not None else align_a
        # Decide stacked-or-not from each drawing's OWN box, never from the
        # interpolated one.  stacked_lines answers by comparing the string's
        # width to the width of the box it is given, so asking it about a box
        # that is itself travelling lets the answer flip over mid-motion - and
        # the label jumps between one line and two in the middle of a frame
        # sequence where nothing discrete should be happening.  Holding the
        # decision at the two ends is the general rule here: only continuous
        # quantities - positions, sizes, colours, alphas - may interpolate.
        stack_a = bool(cs.stacked_lines(lab["text"], lab["bbox"], lab["size"],
                                        lab["bold"], align_a))
        stack_b = bool(cs.stacked_lines(
            (to or lab)["text"], (to or lab)["bbox"], (to or lab)["size"],
            (to or lab)["bold"], align_b))
        if stack_a == stack_b:
            emit(lab["text"], txt, just, align_a, 1.0, stack_a)
        else:
            emit(lab["text"], txt, just, align_a, 1.0 - tt, stack_a)
            emit(lab["text"], txt, just, align_b, tt, stack_b)
        prev = boxes.get(key)
        if prev is None or alpha > prev[1]:
            # bonds are cut at the ATTACHMENT glyph, which for a stacked
            # label is only part of the box (see cs.attachment_box)
            box_a = cs.attachment_box(dict(lab, bbox=bx))
            if to is not None and to["align"] != lab["align"]:
                # the two layouts cut the bond at different places, so the
                # cut travels between them rather than stepping at the end
                box_b = cs.attachment_box(dict(lab, bbox=bx,
                                               align=to["align"]))
                box_a = [box_a[i] * (1 - tt) + box_b[i] * tt for i in range(4)]
            boxes[key] = (box_a, alpha)

    def push_label_change(a, b, z):
        """An atom keeping its place while its substituent changes.

        Crossfading the whole label dissolves the atom itself and reads
        as one atom replacing another.  The glyph the bonds meet is drawn
        solid and travels; only what hangs off it dissolves - the old
        substituent out, the new one in.
        """
        la, lb = A.nodes[a]["label"], B.nodes[b]["label"]
        aa, ca_, ra, rca = cs.label_parts(la, A.nodes[a]["p"])
        ab, cb_, rb, rcb = cs.label_parts(lb, B.nodes[b]["p"])
        pos = np.asarray(PA[a], float) * (1 - t) + np.asarray(PB[b], float) * t
        base = ((la["anchor"][1] - A.nodes[a]["p"][1]) * (1 - t)
                + (lb["anchor"][1] - B.nodes[b]["p"][1]) * t)
        size = la["size"] * (1 - t) + lb["size"] * t
        col = (np.array(A.rgb(la["color"])) * (1 - t)
               + np.array(B.rgb(lb["color"])) * t)
        common = dict(size=size, bold=la["bold"], color=tuple(col), z=z,
                      margin=A.doc["MarginWidth"], id=a)
        def glyph(text, cx, alpha, runs=None):
            if not text or alpha <= 0.01:
                return
            # the piece carries the runs of the LABEL IT CAME FROM, so a
            # substituent dissolving in keeps its own italics rather than
            # the departing one's
            labels.extend(cs.styled_pieces(dict(
                text=text, anchor=(pos[0] + cx, pos[1] + base),
                just="Center", alpha=alpha, runs=runs,
                bbox=[pos[0] + cx, pos[1] + base,
                      pos[0] + cx, pos[1] + base], **common)))
        glyph(aa, ca_ * (1 - t) + cb_ * t, 1.0, la.get("runs"))
        if ra == rb:
            glyph(ra, rca * (1 - t) + rcb * t, 1.0, la.get("runs"))
        else:
            glyph(ra, rca, fade_out, la.get("runs"))
            glyph(rb, rcb, fade_in, lb.get("runs"))
        # bonds are cut at the glyph that stays
        cx = ca_ * (1 - t) + cb_ * t
        w, rise, drop = cs._ink_box(aa, size, la["bold"])
        boxes[ka(a)] = ([pos[0] + cx - w / 2, pos[1] + base - rise,
                         pos[0] + cx + w / 2, pos[1] + base + drop], 1.0)

    for a in A.nodes:
        if not A.nodes[a]["label"]:
            continue
        if a in nmap:
            bn = B.nodes[nmap[a]]
            la, lb = A.nodes[a]["label"], bn["label"]
            z = zA[A.nodes[a]["z"]] * (1 - t) + \
                (zB[bn["z"]] if lb else zA[A.nodes[a]["z"]]) * t
            if lb and _shown(la, A.nodes[a]["p"]) == _shown(lb, bn["p"]):
                push(A, a, PA, ka(a), z, 1.0, tint=B.rgb(lb["color"]),
                     tt=t, to=dict(lb, p=bn["p"]))
            elif lb and _attach(A.nodes[a]) and \
                    _attach(A.nodes[a]) == _attach(bn) and \
                    _splittable(la, A.nodes[a]["p"]) and \
                    _splittable(lb, bn["p"]):
                # The label is drawn as two glyphs at EVERY t, the ends
                # included.  Drawing the plain string at rest and the split
                # pair once moving looked exact at the ends but stepped by
                # about 4 pt on the first and last moving frame, where the
                # layout changed under the glyphs.  The split and the string
                # differ by a fraction of a point, so this is the smaller
                # error - and, unlike a step, it is not visible as motion.
                push_label_change(a, nmap[a], z)
            elif lb:
                # a label whose text changes crossfades on the same
                # schedule as everything else, so it dissolves rather
                # than blinking through a short private window
                push(A, a, PA, ka(a), z, fade_out)
            else:
                push(A, a, PA, ka(a), z, fade_out)
        else:
            push(A, a, PA, ka(a), zA[A.nodes[a]["z"]], fade_out)

    for b in B.nodes:
        if not B.nodes[b]["label"]:
            continue
        z = zB[B.nodes[b]["z"]]
        if b in inv:
            la = A.nodes[inv[b]]["label"]
            if la and (_shown(la, A.nodes[inv[b]]["p"])
                       == _shown(B.nodes[b]["label"], B.nodes[b]["p"])):
                continue
            if la and _attach(A.nodes[inv[b]]) and \
                    _attach(A.nodes[inv[b]]) == _attach(B.nodes[b]) and \
                    _splittable(la, A.nodes[inv[b]]["p"]) and \
                    _splittable(B.nodes[b]["label"], B.nodes[b]["p"]):
                continue                  # the A copy draws both glyphs, always
            push(B, b, PB, kb(b), z, fade_in)
        else:
            push(B, b, PB, kb(b), z, fade_in)

    def push_charge(sc, nid, P, z, alpha, other=None):
        """Charges follow their atom and fade on the same schedule as
        labels.  They are appended to `labels` but never to `boxes`:
        ChemDraw does not trim bonds at a charge.

        A charge rides its atom, at the offset the drawing gives it.  An
        earlier version eased it outwards where a bond swept past, which
        moved the sign up to 9.6 pt from its own atom mid-way; the
        drawing's placement is what a reader expects to see, and a charge
        that has no counterpart should simply fade.

        Both drawings' placements, though, not just the first.  The sign
        belongs beside the atom it was drawn against - the carboxylate's
        oxygen - and when the label reverses, CO2- becoming -O2C, that
        atom is at the other end of the label: here by +15.3 pt in one
        drawing and -16.1 pt in the other.  Riding the first offset the
        whole way leaves the sign 13.7 pt clear of the letters at the
        end, on the side the oxygen has left.  So it travels from one
        placement to the other, as the letters it sits beside do.
        """
        nd = sc.nodes[nid]
        if not nd.get("charge") or alpha <= 0.01:
            return
        d = P[nid] - np.asarray(nd["p"], float)
        if other is not None:
            osc, onid = other
            off_a = np.asarray(cs.charge_offset(sc, nid), float)
            off_b = np.asarray(cs.charge_offset(osc, onid), float)
            d = d + (off_b - off_a) * float(t)
        g = cs.charge_glyph(sc, nid, d[0], d[1],
                            rgb=sc.rgb(nd["label"]["color"] if nd["label"]
                                       else nd["color"]),
                            z=z + cs.CHARGE_Z, alpha=alpha)
        if g is not None:
            labels.append({k: v for k, v in g.items() if k != "kind"})
            # the circle rides with the glyph; assemble() copies it through

    for a in A.nodes:
        if not A.nodes[a].get("charge"):
            continue
        z = zA[A.nodes[a]["z"]]
        if a in nmap:
            z = z * (1 - t) + zB[B.nodes[nmap[a]]["z"]] * t
            same = B.nodes[nmap[a]].get("charge") == A.nodes[a]["charge"]
            push_charge(A, a, PA, z, 1.0 if same else fade_out,
                        other=(B, nmap[a]) if same else None)
        else:
            push_charge(A, a, PA, z, fade_out)

    for b in B.nodes:
        if not B.nodes[b].get("charge"):
            continue
        if b in inv and A.nodes[inv[b]].get("charge") == B.nodes[b]["charge"]:
            continue                      # already carried by the A copy
        push_charge(B, b, PB, zB[B.nodes[b]["z"]], fade_in)

    # An atom whose label text changes crossfades between two glyphs, but its
    # bond must not: interpolate the trim box itself so the bond end travels
    # continuously instead of popping when a crossfade alpha crosses the
    # threshold (and never falling away entirely while both halves are faint).
    for a, b in nmap.items():
        la, lb = A.nodes[a]["label"], B.nodes[b]["label"]
        if not (la and lb) or la["text"] == lb["text"]:
            continue
        da = PA[a] - np.asarray(A.nodes[a]["p"], float)
        db = PB[b] - np.asarray(B.nodes[b]["p"], float)
        ba = [la["bbox"][i] + da[i % 2] for i in range(4)]
        bb = [lb["bbox"][i] + db[i % 2] for i in range(4)]
        boxes[ka(a)] = ([ba[i] * (1 - t) + bb[i] * t for i in range(4)], 1.0)

    return lines, labels, boxes


def plan_swaps(A, B, nmap, bmap, ts, bover, margin):
    """Reschedule z-order flips so none happens while the two strokes are
    crossing.

    Depth is discrete: a bond is either in front of another or behind it.
    Interpolating the two z values makes the order flip at whatever instant
    the numbers cross, and when two bonds sit adjacent in z that instant
    often falls in the middle of a crossing - the white gap jumps from one
    bond to the other and back, which reads as flickering.  Here the flip
    is moved to the first moment the pair is not overlapping.

    Returns {frozenset({grp, grp}): (t_flip, front_before, front_after)}.
    """
    def visible(t):
        out = {}
        for l in frame(A, B, nmap, bmap, t, bover=bover)[0]:
            if l["alpha"] > 0.5:
                out.setdefault(l["grp"], []).append(l)
        return out

    frames = [(t, visible(t)) for t in ts]

    # Which pairs ever change places?  Comparing only the two endpoints
    # would miss a bond that fades out partway, which is exactly when a
    # flip tends to happen - so walk the whole timeline.  This uses z only,
    # no geometry, so it is cheap enough to do for every pair.
    signs = {}
    for t, vis in frames:
        gs = sorted(vis)
        for i in range(len(gs)):
            for j in range(i + 1, len(gs)):
                g1, g2 = gs[i], gs[j]
                signs.setdefault((g1, g2), []).append(
                    vis[g1][0]["z"] > vis[g2][0]["z"])
    cand = [(g1, g2, s[0], s[-1]) for (g1, g2), s in signs.items()
            if len(set(s)) > 1]
    if not cand:
        return {}

    def overlaps(a_list, b_list):
        if set(a_list[0]["ends"]) & set(b_list[0]["ends"]):
            return False
        for a in a_list:
            for b in b_list:
                th = a["w"] / 2 + b["w"] / 2 + margin
                if cs._overlap_span(a["p0"], a["p1"], b["p0"], b["p1"],
                                    th) is not None:
                    return True
        return False

    out = {}
    for g1, g2, s0, s1 in cand:
        seq = []
        for t, vis in frames:
            if g1 not in vis or g2 not in vis:
                seq.append((t, None, False))
                continue
            seq.append((t, vis[g1][0]["z"] > vis[g2][0]["z"],
                        overlaps(vis[g1], vis[g2])))
        nat = next((k for k, (t, s, o) in enumerate(seq)
                    if s is not None and s != s0), None)
        if nat is None or not seq[nat][2]:
            continue                       # flips in clear air already
        k = nat
        while k + 1 < len(seq) and seq[k + 1][2]:
            k += 1                         # to the end of this crossing
        if k + 1 < len(seq):
            t_flip = seq[k + 1][0]
        else:                              # overlapping to the end: flip early
            k = nat
            while k - 1 >= 0 and seq[k - 1][2]:
                k -= 1
            t_flip = seq[k][0]
        out[frozenset((g1, g2))] = (t_flip,
                                    g1 if s0 else g2,
                                    g1 if s1 else g2)
    return out


def assemble(lines, labels, boxes, doc, t=0.0, swaps=None):
    """Trim strokes at label boxes, punch crossing gaps, z-sort."""
    margin = doc["MarginWidth"]
    raw = []
    for ln in lines:
        # An offset stroke - either line of a double bond - is trimmed
        # through the bond it belongs to, not on its own: offsetting a
        # trimmed line and trimming an offset line do not give the same
        # ends, and the still renderer does the former.
        base = ln.get("base")
        p0, p1 = (np.asarray(base[0], float), np.asarray(base[1], float)) \
            if base is not None else (np.asarray(ln["p0"], float),
                                      np.asarray(ln["p1"], float))
        anchors = (p0.copy(), p1.copy())
        for k, anchor in zip(ln["ends"], anchors):
            ent = boxes.get(k)
            if ent and ent[1] > 0.01:
                # A bond is trimmed at its label's box, so switching the box
                # on at a threshold made the bond end jump in one frame as a
                # group faded in.  Grow the box out of the atom centre in
                # step with the label's opacity instead: no trim at all when
                # the label is invisible, full trim when it is solid, and a
                # continuously travelling bond end in between.
                # Collapse the box onto the ATOM, not onto its own centre:
                # a right-aligned label sits to one side of its atom, so a
                # box shrinking toward its centre slides off the bond end
                # and the trim stops in one frame.  Anchored at the atom it
                # goes to zero continuously.
                bx, la = ent[0], float(np.clip(ent[1], 0.0, 1.0))
                cx, cy = float(anchor[0]), float(anchor[1])
                grown = [cx + la * (bx[0] - cx), cy + la * (bx[1] - cy),
                         cx + la * (bx[2] - cx), cy + la * (bx[3] - cy)]
                r = cs._clip_to_box(p0, p1, grown, margin * la)
                # a box that swallows the whole bond would delete the only
                # thing joining its label to the drawing - leave it alone
                if r is not None:
                    p0, p1 = r
        if np.hypot(*(p1 - p0)) < 1e-6:
            continue
        raw.append(dict(ln, p0=p0, p1=p1, trimmed=(p0.copy(), p1.copy())))

    # rebuild each double bond's inner line from its main stroke now that
    # the main stroke has been trimmed - the order the still renderer uses
    for r in raw:
        info = r.get("inner")
        if not info:
            continue
        p0, p1 = r["trimmed"]
        d = p1 - p0
        L = float(np.hypot(*d))
        if L < 1e-9:
            continue
        nrm = np.array([-d[1], d[0]]) / L
        q0, q1 = p0 + info["off"] * nrm, p1 + info["off"] * nrm
        nb = info["nbrs"]
        if info.get("full"):
            # a symmetric pair runs the whole length of its bond, so that
            # a double bond reaches its own atoms
            u, v = 0.0, 1.0
        elif nb:
            u, v = cs.inner_span(q0, q1, p0, nb[0], p1, nb[1],
                                 r["w"] + margin)
        else:
            u, v = cs.INNER_DEFAULT_INSET, 1.0 - cs.INNER_DEFAULT_INSET
        # A line that is a triple's flank at one end of the transition and a
        # double's inner line at the other is full length in the first case
        # and shortened in the second, so the shortening travels with it.
        g = float(info.get("trim", 1.0))
        if g < 1.0:
            u, v = u * g, 1.0 + (v - 1.0) * g
        r["p0"], r["p1"] = q0 + u * (q1 - q0), q0 + v * (q1 - q0)

    cuts = {i: [] for i in range(len(raw))}
    for i in range(len(raw)):
        for j in range(i + 1, len(raw)):
            r, s = raw[i], raw[j]
            if r["grp"] == s["grp"] or set(r["ends"]) & set(s["ends"]):
                continue
            # only an opaque stroke occludes; band is the FRONT stroke's
            # half-width plus margin (see cdxml_scene.build_strokes)
            sched = swaps.get(frozenset((r["grp"], s["grp"]))) if swaps else None
            if sched is not None:
                t_flip, before, after = sched
                front_grp = before if t < t_flip else after
                bi, fi = (j, i) if r["grp"] == front_grp else (i, j)
            elif r["z"] < s["z"]:
                bi, fi = i, j
            else:
                bi, fi = j, i
            if raw[fi]["alpha"] <= 0.5:
                continue
            back, front = raw[bi], raw[fi]
            if not cs.crosses_transversely(back["p0"], back["p1"],
                                           front["p0"], front["p1"]):
                continue
            sp = cs._overlap_span(back["p0"], back["p1"],
                                  front["p0"], front["p1"],
                                  front["w"] / 2 + margin * cs.GAP_SCALE)
            if sp is None:
                continue
            cuts[bi].append((sp[0] - back["w"] / 2, sp[1] + back["w"] / 2))

    out = []
    for i, r in enumerate(raw):
        lab = tuple((boxes.get(k) or (None, 0.0))[1] > 0.45
                    for k in (list(r["ends"]) + [None, None])[:2])
        segs = cs.punch_surviving(r["p0"], r["p1"], cuts[i], r["w"], lab,
                                  max_gap=cs.GAP_MAX * (r["w"] + 2 * margin),
                                  whole=(r.get("stereo") or ("",))[0] != "Dash")
        if segs:
            st = r.get("stereo")
            firm = [(a, b) for a, b, wt in segs if wt >= 0.999 or st is not None]
            faint = [] if st is not None else [(a, b, wt) for a, b, wt in segs
                                               if wt < 0.999]
            if not firm and faint:
                # nothing solid left: draw the faintest pieces alone
                firm, faint = [(a, b) for a, b, _ in faint], []
            d = dict(kind="line", pts=firm, color=r["color"],
                     width=r["w"], z=r["z"], alpha=r["alpha"],
                     ends=r["ends"], grp=r["grp"])
            for a, b, wt in faint:
                # a piece near the length that stops reading as a bond
                # fades rather than blinking off between frames
                out.append(dict(kind="line", pts=[(a, b)], color=r["color"],
                                width=r["w"], z=r["z"],
                                alpha=r["alpha"] * wt,
                                ends=r["ends"], grp=r["grp"]))
            if st is not None and st[0] == "Dash":
                # the contact is laid out along its whole trimmed length and
                # the crossings remove marks from it, so one near an end
                # interrupts the contact instead of shortening it
                d = dict(d, pts=cs.dash_segments(r["p0"], r["p1"], doc, firm,
                                                 r["w"]),
                         width=max(0.5 * r["w"], 0.25))
                out.append(d)
                continue
            if st is not None:
                pts = np.asarray([q for sg in firm for q in sg], float)
                j0 = int(np.argmin(np.hypot(*(pts - st[1]).T)))
                j1 = int(np.argmax(np.hypot(*(pts - pts[j0]).T)))
                sh = cs.stereo_shape(st[0], pts[j0], pts[j1], doc, r["w"],
                                     rungs=st[2] if len(st) > 2 else None)
                if sh is not None:
                    if sh[0] == "poly":
                        d = dict(d, kind="poly", pts=sh[1])
                    elif sh[0] == "rungs":
                        d = (dict(d, pts=sh[1], width=sh[2]) if len(sh) > 2
                             else dict(d, pts=sh[1]))
                    else:
                        d = dict(d, pts=sh[1], width=sh[2])
            out.append(d)
    out += [dict(kind="text", **L) for L in labels]
    out.sort(key=lambda d: d["z"])
    return out
