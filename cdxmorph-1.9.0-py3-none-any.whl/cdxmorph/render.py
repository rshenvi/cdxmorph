"""Frame rendering and encoding.

Speed comes from three things, in order of how much they mattered when this
was profiled against the original one-figure-per-frame driver:

  * frames are read straight out of the Agg buffer as arrays - the original
    round-tripped every frame through an encoded PNG in memory, which cost
    more than the drawing did;
  * one Figure and one LineCollection are reused for the whole sequence, so
    each frame sets arrays on existing artists instead of building a few
    dozen Line2D objects and a new canvas;
  * text artists are pooled, since their count changes only when labels
    appear or disappear.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import matplotlib.patches as mpatches
from matplotlib.collections import LineCollection

from . import scene as cs
from . import animate as mo



def page_clip(path, style, cfg=None, flip_h=True, flat_h=True,
              blend_labels=True):
    """One clip for a page that mixes reorientations and reactions.

    A page can hold both kinds of step: an equivalency sign asks for a
    turn, an arrow for a morph.  Each becomes the same thing here - a
    function from 0..1 to the drawables of one frame - so the two play
    back to back in a single clip with no seam between them.

    Everything is drawn about ONE centre, the first structure's, because
    a scheme draws its structures side by side and leaving each stage at
    its own column would jump the molecule across the page.

    Returns (funcs, notes, scenes).
    """
    from . import rotate as rot
    from . import config as cfgmod
    cfg = cfg or {}
    cs.GAP_SCALE = style.get("gap_scale", cs.GAP_SCALE)
    scenes, stages, _ = cs.page_stages(path)
    if not stages:
        raise ValueError("no equivalency sign or reaction arrow to animate")
    first = stages[0]["A"]
    centre = np.asarray([first.nodes[k]["p"] for k in first.nodes],
                        float).mean(0)

    def centred(sc):
        """The same drawing with its centre of gravity on the common one."""
        here = np.asarray([sc.nodes[k]["p"] for k in sc.nodes], float).mean(0)
        return translated(sc, centre - here)

    funcs, notes, prev_end, prev_kind, prev_pairs = [], [], None, None, None
    for i, st in enumerate(stages):
        block = cfgmod.stage(cfg, i, len(stages))
        if st["kind"] == "turn":
            plan = dict(mode="guided" if st["solid"] else "drawn",
                        A=st["A"], B=st["B"],
                        solid=st["solid"] or (st["A"], st["B"]))
            if block.get("pairs"):
                # the same mapping file shape a reaction takes
                plan["pairs"] = cfgmod.resolve(block, st["A"], st["B"])[0]
            # A turn after a REACTION has to begin where that reaction left
            # the molecule.  Turns share one centre so a run of them does
            # not wander, but a morph places its product by its own pairing,
            # and a turn that ignored that placement made the structure jump
            # at the junction - which reads as the rotation not happening at
            # all, because the eye sees the new orientation arrive in the cut
            # rather than in the motion.  Turn-to-turn keeps the shared
            # centre exactly as before.
            here = centre
            if prev_kind == "morph" and prev_end is not None:
                here = np.asarray([prev_end.nodes[k]["p"]
                                   for k in prev_end.nodes], float).mean(0)
            poses, ns = rot.build_turns([], style, flip_h=flip_h,
                                        flat_h=flat_h,
                                        blend_labels=blend_labels,
                                        stages=[plan], centre=here)
            funcs.append(lambda t, p=poses[0]: cs.build_strokes(p(t)))
            notes.append(dict(ns[0], kind="turn"))
            prev_end = poses[0](1.0)      # where this turn leaves the molecule
            prev_kind = "turn"
            prev_pairs = ns[0].get("atom_pairs")
        else:
            # Start exactly where the previous stage ended, or the junction
            # shows a jump: a turn leaves the molecule where its own 3D fit
            # puts it, which is not where the drawing sits on the page.
            # Take the previous stage's PLACEMENT, not its posed scene: a
            # turn's last frame carries per-frame machinery (a hydrogen
            # split into its own glyph so it can slide, blended colours),
            # and a morph should start from the plain drawing sitting
            # exactly where the turn left it.
            # A turn's final scene is keyed by the atoms of the drawing it
            # STARTED from, so there are no shared keys to align on - take
            # its centre of gravity instead, which is what the eye tracks.
            A = st["A"]
            if prev_end is not None:
                # Align on the atoms the two stages have IN COMMON.  A turn's
                # final scene is keyed by the drawing it started from, and
                # that drawing may hold atoms this one does not - a hydrogen
                # drawn in one orientation and not the other.  Comparing the
                # centre of gravity of 14 atoms with that of 12 leaves the
                # whole structure a fraction of a point out of place, which
                # is visible as a step of a few pixels at the junction.
                keys = [k for k, v in (prev_pairs or {}).items()
                        if k in prev_end.nodes and v in A.nodes]
                if keys:
                    here = np.asarray([prev_end.nodes[k]["p"]
                                       for k in keys], float).mean(0)
                    mine = np.asarray([A.nodes[prev_pairs[k]]["p"]
                                       for k in keys], float).mean(0)
                else:
                    here = np.asarray([prev_end.nodes[k]["p"]
                                       for k in prev_end.nodes], float).mean(0)
                    mine = np.asarray([A.nodes[k]["p"] for k in A.nodes],
                                      float).mean(0)
                A = translated(A, here - mine)
            else:
                A = centred(A)
            B = st["B"]
            nmap, bmap, bover = cfgmod.resolve(block, A, B)
            if nmap:
                pa = np.asarray([A.nodes[k]["p"] for k in nmap], float).mean(0)
                pb = np.asarray([B.nodes[v]["p"] for v in nmap.values()],
                                float).mean(0)
                B = translated(B, pa - pb)
            else:
                B = centred(B)
            prev_end = B
            prev_kind = "morph"
            prev_pairs = {v: v for v in nmap.values()}
            notes.append(dict(
                kind="morph",
                atoms=f"{len(nmap)} of {len(A.nodes)} -> {len(B.nodes)}",
                bonds=f"{len(bmap)} of {len(A.bonds)} -> {len(B.bonds)}"))
            funcs.append(lambda t, A=A, B=B, nmap=nmap, bmap=bmap, bover=bover:
                         mo.assemble(*mo.frame(A, B, nmap, bmap, t,
                                               bover=bover), A.doc, t))
    return funcs, notes, scenes


def translated(sc, off):
    """A copy of `sc` shifted by `off`, labels and boxes with it."""
    import copy
    out = copy.copy(sc)
    out.nodes, out.bonds = {}, dict(sc.bonds)
    ox, oy = float(off[0]), float(off[1])
    for k, n in sc.nodes.items():
        m = dict(n)
        m["p"] = (n["p"][0] + ox, n["p"][1] + oy)
        if n["label"]:
            lab = dict(n["label"])
            b = lab["bbox"]
            lab["bbox"] = [b[0] + ox, b[1] + oy, b[2] + ox, b[3] + oy]
            a = lab["anchor"]
            lab["anchor"] = (a[0] + ox, a[1] + oy)
            m["label"] = lab
        out.nodes[k] = m
    return out


def frames_box(funcs, pad=8.0, probes=17):
    """A canvas that contains every frame of every stage.

    Labels are measured from their own glyph box, not from their anchor.
    A right-justified label - HO, Ph, Me on the left of a skeleton - sits
    with its anchor ON the atom and its letters to the LEFT of it, so a
    canvas built from anchors alone cut those letters off the edge.
    """
    xs, ys = [], []
    for f in funcs:
        for t in np.linspace(0.0, 1.0, probes):
            for d in f(float(t)):
                if d["kind"] in ("line", "poly"):
                    p = np.asarray(d["pts"], float).reshape(-1, 2)
                    xs += [p[:, 0].min(), p[:, 0].max()]
                    ys += [p[:, 1].min(), p[:, 1].max()]
                    continue
                bb = d.get("bbox")
                if bb is not None:
                    xs += [float(bb[0]), float(bb[2])]
                    ys += [float(bb[1]), float(bb[3])]
                a = d.get("anchor")
                if a is not None:
                    xs.append(float(a[0])); ys.append(float(a[1]))
                    # a label mid-flight between two justifications ends up
                    # drawn from either edge, so allow for both
                    bl = d.get("blend")
                    if bl:
                        xs.append(float(bl[1]))
    return (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)


def canvas_box(scenes, pad=8.0):
    xs, ys = [], []
    for sc in scenes:
        x0, y0, x1, y1 = sc.extent()
        xs += [x0, x1]; ys += [y0, y1]
    return (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)


class Renderer:
    """Reusable Agg canvas.  `draw(drawables)` returns an (H, W, 3) uint8."""

    def __init__(self, box, scale=6.0, dpi=150, background="white"):
        self.scale, self.dpi, self.box = scale, dpi, box
        x0, y0, x1, y1 = box
        w, h = (x1 - x0) * scale / 72.0, (y1 - y0) * scale / 72.0
        self.fig = plt.figure(figsize=(w, h), dpi=dpi)
        self.ax = self.fig.add_axes([0, 0, 1, 1])
        self.ax.set_xlim(x0 * scale, x1 * scale)
        self.ax.set_ylim(-y1 * scale, -y0 * scale)
        self.ax.set_aspect("equal")
        self.ax.axis("off")
        # both patches, or the active style's off-white paper shows through
        self.fig.patch.set_facecolor(background)
        self.ax.set_facecolor(background)
        self.ax.patch.set_visible(True)
        self._bands = []
        self._texts = []
        self._circles = []
        self._polys = []
        self.fig.canvas.draw()          # realise the canvas once

    @property
    def size(self):
        return self.fig.canvas.get_width_height()

    def _advance(self, text, fontsize, bold, italic=False, weight=None):
        """How wide the canvas lays this text out, in points.

        Measured by the canvas rather than from the font file: the two
        disagree by several points on a short label, and it is the
        canvas's figure that decides where a justified string lands.
        """
        cache = getattr(self, "_adv_cache", None)
        if cache is None:
            cache = self._adv_cache = {}
        key = (text, round(float(fontsize), 2), bool(bold), bool(italic), weight)
        if key not in cache:
            from matplotlib.font_manager import FontProperties
            rend = self.fig.canvas.get_renderer()
            fp = FontProperties(family=cs.TEXT_FAMILY,
                                weight=weight or ("bold" if bold else "normal"),
                                style="italic" if italic else "normal",
                                size=fontsize)
            w, _, _ = rend.get_text_width_height_descent(text, fp, False)
            cache[key] = float(w) * 72.0 / float(self.fig.dpi)
        return cache[key]

    def _text(self, i):
        """Text artist `i`, created on first use and reused thereafter."""
        while len(self._texts) <= i:
            t = self.ax.text(0, 0, "", ha="left", va="baseline",
                             fontfamily=cs.TEXT_FAMILY, zorder=0)
            t.set_visible(False)
            self._texts.append(t)
        return self._texts[i]

    def _circle(self, i):
        """Reusable circle patch `i`, for charge signs."""
        while len(self._circles) <= i:
            c = mpatches.Circle((0, 0), 1.0, facecolor="white",
                                edgecolor="black", zorder=0)
            c.set_visible(False)
            self.ax.add_patch(c)
            self._circles.append(c)
        return self._circles[i]

    def _poly(self, i):
        """Reusable filled polygon `i`, for solid stereo wedges."""
        while len(self._polys) <= i:
            p = mpatches.Polygon([(0, 0), (0, 0), (0, 0)], closed=True,
                                 linewidth=0.0, zorder=0)
            p.set_visible(False)
            self.ax.add_patch(p)
            self._polys.append(p)
        return self._polys[i]

    def _band(self, i):
        """LineCollection for depth band `i`, created on first use."""
        while len(self._bands) <= i:
            lc = LineCollection([], capstyle="round")
            self.ax.add_collection(lc)
            self._bands.append(lc)
        return self._bands[i]

    def draw(self, drawables):
        s = self.scale
        texts = sorted((d for d in drawables if d["kind"] == "text"),
                       key=lambda d: d["z"])
        # Strokes and labels interleave by z, so strokes are bucketed into
        # the gaps between label depths.  One collection per band keeps the
        # painter's order exact while still drawing tens of segments per
        # artist instead of one artist per segment.
        tz = [d["z"] for d in texts]
        nb = len(tz) + 1
        band = [([], [], []) for _ in range(nb)]
        import bisect
        for d in drawables:
            if d["kind"] != "line":
                continue
            a = d.get("alpha", 1.0)
            r, g, b = d["color"]
            k = bisect.bisect_left(tz, d["z"])
            segs, cols, lws = band[k]
            for p0, p1 in d["pts"]:
                segs.append(((p0[0] * s, -p0[1] * s), (p1[0] * s, -p1[1] * s)))
                cols.append((r, g, b, a))
                lws.append(d["width"] * s)

        for k in range(nb):
            segs, cols, lws = band[k]
            lc = self._band(k)
            lc.set_segments(segs)
            if segs:
                lc.set_color(cols)
                lc.set_linewidth(lws)
            lc.set_zorder(float(k))
            lc.set_visible(bool(segs))
        for lc in self._bands[nb:]:
            lc.set_segments([])
            lc.set_visible(False)

        # circled charges: the ring is painted with its sign, at the sign's
        # depth, so the two never separate
        nc = 0
        np_ = 0
        for d in drawables:
            if d["kind"] != "poly":
                continue
            a = d.get("alpha", 1.0)
            p = self._poly(np_); np_ += 1
            p.set_visible(True)
            p.set_xy([(q[0] * s, -q[1] * s) for q in d["pts"]])
            p.set_facecolor(d["color"])
            p.set_edgecolor(d["color"])
            p.set_alpha(a)
            p.set_zorder(float(bisect.bisect_left(tz, d["z"])) + 0.2)
        for p in self._polys[np_:]:
            p.set_visible(False)

        for i, d in enumerate(texts):
            circ = d.get("circle")
            if circ is None:
                continue
            ccx, ccy, cr = circ
            a = d.get("alpha", 1.0)
            c = self._circle(nc); nc += 1
            c.set_visible(True)
            c.set_center((ccx * s, -ccy * s))
            c.set_radius(cr * s)
            c.set_edgecolor(d["color"])
            c.set_linewidth(0.5 * s)
            c.set_alpha(a)
            # a white margin outside the ring, so a bond sweeping past is
            # held off it instead of abutting it - the sign itself never
            # moves to make room
            c.set_path_effects([pe.withStroke(
                linewidth=(0.5 + 2 * cs.CHARGE_CLEARANCE) * s,
                foreground="white", alpha=a)])
            c.set_zorder(i + 0.4)          # just under its own sign
        for c in self._circles[nc:]:
            c.set_visible(False)

        for i, d in enumerate(texts):
            t = self._text(i)
            t.set_visible(True)
            t.set_text(d["text"])
            t.set_position((d["anchor"][0] * s, -d["anchor"][1] * s))
            ha = {"Left": "left", "Right": "right",
                  "Center": "center"}.get(d["just"], "left")
            bl = d.get("blend")
            if bl is not None:
                # Two drawings justify this label differently, so its
                # placement is resolved HERE, where the width the canvas
                # lays the text out in is known: each end's justification
                # is turned into a left edge and the two are interpolated.
                just_b, ax_b, tt = bl
                adv = self._advance(d["text"], d["size"] * s, d["bold"],
                                    d.get("italic", False), d.get("weight")) / s
                off = {"Left": 0.0, "Center": 0.5 * adv, "Right": adv}
                left = ((d["anchor"][0] - off.get(d["just"], 0.0)) * (1 - tt)
                        + (ax_b - off.get(just_b, 0.0)) * tt)
                t.set_position((left * s, -d["anchor"][1] * s))
                ha = "left"
            t.set_ha(ha)
            # always the baseline: a charge sign arrives with its anchor
            # already placed so the sign's INK lands in the middle of its
            # ring, which matplotlib's own centring does not do
            t.set_va("baseline")
            t.set_color(d["color"])
            t.set_fontsize(d["size"] * s)
            t.set_fontweight(d.get("weight") or ("bold" if d["bold"] else "normal"))
            t.set_fontstyle("italic" if d.get("italic") else "normal")
            a = d.get("alpha", 1.0)
            t.set_alpha(a)
            t.set_zorder(i + 0.5)          # sits between its two bands
            t.set_path_effects([pe.withStroke(
                linewidth=2 * d.get("clearance", cs.LABEL_CLEARANCE) * s,
                foreground="white", alpha=a)])
        for t in self._texts[len(texts):]:
            t.set_visible(False)

        self.fig.canvas.draw()
        buf = np.asarray(self.fig.canvas.buffer_rgba())
        return buf[..., :3].copy()

    def close(self):
        plt.close(self.fig)


def ease_smoothstep(u):
    return u * u * (3.0 - 2.0 * u)


def ease_linear(u):
    return u


EASINGS = {"smoothstep": ease_smoothstep, "linear": ease_linear}


def timeline(n_frames, hold_frames, easing="smoothstep"):
    f = EASINGS[easing]
    core = [f(i / (n_frames - 1)) for i in range(n_frames)] if n_frames > 1 else [1.0]
    return [0.0] * hold_frames + core + [1.0] * hold_frames


def render_sequence(A, B, nmap, bmap, ts, box, bover=None,
                    scale=6.0, dpi=150, workers=1):
    """Frames for every t in `ts`.  workers>1 splits across processes."""
    if workers and workers > 1 and len(ts) > 2 * workers:
        try:
            return _render_parallel(A, B, nmap, bmap, ts, box, bover,
                                    scale, dpi, workers)
        except (OSError, NotImplementedError, ImportError) as exc:
            # some sandboxes forbid the semaphores a process pool needs
            import warnings
            warnings.warn(f"parallel rendering unavailable ({exc}); "
                          "falling back to one process", RuntimeWarning)
    flip = mo.reflection_axis(A, B, nmap)
    swaps = mo.plan_swaps(A, B, nmap, bmap, ts, bover, A.doc["MarginWidth"])
    r = Renderer(box, scale=scale, dpi=dpi)
    try:
        return [r.draw(mo.assemble(*mo.frame(A, B, nmap, bmap, t, bover=bover,
                                             flip=flip), A.doc, t, swaps))
                for t in ts]
    finally:
        r.close()


def _chunk_worker(args):
    A, B, nmap, bmap, ts, box, bover, scale, dpi, swaps = args
    r = Renderer(box, scale=scale, dpi=dpi)
    try:
        return [r.draw(mo.assemble(*mo.frame(A, B, nmap, bmap, t,
                                             bover=bover), A.doc, t, swaps))
                for t in ts]
    finally:
        r.close()


def _render_parallel(A, B, nmap, bmap, ts, box, bover, scale, dpi, workers):
    from concurrent.futures import ProcessPoolExecutor
    swaps = mo.plan_swaps(A, B, nmap, bmap, ts, bover, A.doc["MarginWidth"])
    bounds = np.linspace(0, len(ts), workers + 1).astype(int)
    chunks = [list(ts[bounds[i]:bounds[i + 1]]) for i in range(workers)]
    jobs = [(A, B, nmap, bmap, c, box, bover, scale, dpi, swaps)
            for c in chunks if c]
    out = []
    with ProcessPoolExecutor(max_workers=len(jobs)) as ex:
        for part in ex.map(_chunk_worker, jobs):
            out.extend(part)
    return out


# ------------------------------------------------------------- encoding

def align_chain(scenes, nmaps):
    """Superimpose each structure on the one before it, by translation.

    A reaction scheme draws its structures side by side; morphing in place
    means removing that page offset.  Only the offset is removed - relative
    rotation between two drawings is left alone so it animates as rotation,
    which is what the two-file case does.  The shift is the centroid
    difference over the atoms that are actually paired, so births and
    deaths do not drag the structure sideways.
    """
    out = [scenes[0]]
    for nxt, nmap in zip(scenes[1:], nmaps):
        prev = out[-1]
        if nmap:
            X = np.array([prev.nodes[a]["p"] for a in nmap if a in prev.nodes])
            Y = np.array([nxt.nodes[b]["p"] for a, b in nmap.items()
                          if a in prev.nodes])
            delta = X.mean(0) - Y.mean(0)
        else:
            px, nx = prev.extent(), nxt.extent()
            delta = np.array([(px[0] + px[2] - nx[0] - nx[2]) / 2.0,
                              (px[1] + px[3] - nx[1] - nx[3]) / 2.0])
        out.append(cs.translated(nxt, delta))
    return out


def render_chain(scenes, maps, box, n_frames, hold, hold_mid=0,
                 easing="smoothstep", scale=6.0, dpi=150, workers=1):
    """Frames for structure 1 -> 2 -> ... -> N, concatenated.

    `scenes` must already be aligned.  Each stage ends on exactly the scene
    the next one starts from, so the junction is continuous and needs no
    crossfade; `hold_mid` simply pauses there.
    """
    # split the moving frames exactly, so the clip is the length asked for
    # rather than drifting by a frame per stage through rounding
    base, rem = divmod(max(n_frames, 2 * len(maps)), max(1, len(maps)))
    frames = []
    for i, (nmap, bmap, bover) in enumerate(maps):
        A, B = scenes[i], scenes[i + 1]
        per = max(2, base + (1 if i < rem else 0))
        head = hold if i == 0 else hold_mid
        tail = hold if i == len(maps) - 1 else 0
        ts = ([0.0] * head + list(timeline(per, 0, easing)) + [1.0] * tail)
        frames += render_sequence(A, B, nmap, bmap, ts, box, bover,
                                  scale=scale, dpi=dpi, workers=workers)
    return frames


def _is_greyscale(frames):
    return all(np.array_equal(f[..., 0], f[..., 1]) and
               np.array_equal(f[..., 1], f[..., 2]) for f in frames)


def _exact_palette(frames, limit=256):
    """(palette, frame->index function), or (None, None) when the art uses
    more than `limit` colours.  An exact palette makes the GIF lossless:
    no drifting off-white paper, no dither speckle on the greys.

    ChemDraw line art is usually greyscale, which can never exceed 256
    distinct values - that case is indexed with a single channel lookup
    rather than a search over packed RGB, which dominates otherwise."""
    if _is_greyscale(frames):
        used = np.zeros(256, bool)
        for f in frames:
            used[np.unique(f[..., 0])] = True
        vals = np.flatnonzero(used).astype(np.uint8)
        if used[255]:                     # paper first, so index 0 is white
            vals = np.concatenate(([255], vals[vals != 255])).astype(np.uint8)
        lut = np.zeros(256, np.uint8)
        lut[vals] = np.arange(len(vals), dtype=np.uint8)
        pal = [(int(v), int(v), int(v)) for v in vals]
        return pal, (lambda f: lut[f[..., 0]])

    keys = set()
    for f in frames:
        a = f.astype(np.uint32)
        packed = (a[..., 0] << 16) | (a[..., 1] << 8) | a[..., 2]
        keys.update(np.unique(packed.ravel()).tolist())
        if len(keys) > limit:
            return None, None
    white = 0xFFFFFF
    ordered = np.array([white] + sorted(k for k in keys if k != white),
                       dtype=np.int64)
    order = np.argsort(ordered)
    skeys, sidx = ordered[order], order.astype(np.uint8)

    def index(f):
        a = f.astype(np.int64)
        packed = (a[..., 0] << 16) | (a[..., 1] << 8) | a[..., 2]
        return sidx[np.searchsorted(skeys, packed)]

    pal = [((int(k) >> 16) & 255, (int(k) >> 8) & 255, int(k) & 255)
           for k in ordered]
    return pal, index


def gif_delay_ms(fps):
    """Frame delay a GIF can actually store, in ms.

    GIF keeps the delay in hundredths of a second, so 24 fps is not
    representable: every frame becomes 40 ms and the clip plays slightly
    fast and lands slightly short.  Rounding to the nearest centisecond
    up front makes the stored timing exact.
    """
    return max(10, int(round(100.0 / max(1e-6, fps))) * 10)


def gif_rate(fps):
    """The frame rate that delay actually gives (25 for a requested 24)."""
    return 1000.0 / gif_delay_ms(fps)


def _nearest_palette(frames, limit=256):
    """(palette, frame->index) for art with more colours than a GIF holds.

    Pillow's own `quantize(palette=...)` resolves colours through a coarse
    cache, so pure white can land on a 252 entry even when the palette
    holds white - the whole animation then sits on a faintly grey card.
    Choosing the most-used colours ourselves, with white reserved, and
    mapping the rest to their true nearest entry avoids that and is
    exact.
    """
    def pack(f):
        return (f[..., 0].astype(np.uint32) << 16
                | f[..., 1].astype(np.uint32) << 8
                | f[..., 2].astype(np.uint32))

    counts = {}
    for f in frames:
        # pack to one integer per pixel first: np.unique on rows sorts a
        # 2.4-million-row array per frame and dominates the whole render
        v, c = np.unique(pack(f).ravel(), return_counts=True)
        for k, n in zip(v.tolist(), c.tolist()):
            counts[k] = counts.get(k, 0) + n
    white = 0xFFFFFF
    ranked = sorted(counts, key=lambda k: -counts[k])
    keep = [white] + [k for k in ranked if k != white][:limit - 1]
    pal = [((k >> 16) & 255, (k >> 8) & 255, k & 255) for k in keep]

    # every colour in the art -> its nearest kept colour, computed once
    allk = np.array(sorted(counts), dtype=np.uint32)
    src = np.stack([(allk >> 16) & 255, (allk >> 8) & 255, allk & 255],
                   axis=1).astype(np.int32)
    tgt = np.array(pal, dtype=np.int32)
    idx = np.empty(len(src), np.uint8)
    for s in range(0, len(src), 4096):          # bounded memory
        chunk = src[s:s + 4096]
        d = ((chunk[:, None, :] - tgt[None, :, :]) ** 2).sum(2)
        idx[s:s + 4096] = d.argmin(1).astype(np.uint8)

    def index(f):
        k = pack(f)
        return idx[np.searchsorted(allk, k.ravel())].reshape(k.shape)

    return pal, index


def write_gif(frames, path, fps=24, loop=0):
    from PIL import Image
    pal, index = _exact_palette(frames)
    if pal is None:
        pal, index = _nearest_palette(frames)
    if True:
        # PIL's quantize(palette=...) falls back to an exhaustive
        # nearest-colour search against a hand-built palette, which costs
        # far more than rendering the frame did - index the frames directly
        flat = [v for c in pal for v in c] + [0] * (3 * (256 - len(pal)))
        h, w = frames[0].shape[:2]
        ims = []
        for f in frames:
            # fromarray(..., mode="P") is ignored by current Pillow and the
            # indices come back read as greys; frombytes is unambiguous
            im = Image.frombytes(
                "P", (w, h), np.ascontiguousarray(index(f)).tobytes())
            im.putpalette(flat)
            ims.append(im)
    # an explicit per-frame delay, so identical hold frames that Pillow
    # merges accumulate to exactly the time they stood for
    ims[0].save(path, save_all=True, append_images=ims[1:],
                duration=[gif_delay_ms(fps)] * len(ims), loop=loop,
                optimize=False)


def write_mp4(frames, path, fps=24):
    import imageio.v2 as imageio
    h, w = frames[0].shape[:2]
    # H.264 requires even dimensions; pad with paper rather than crop art
    ph, pw = h + (h & 1), w + (w & 1)
    if (ph, pw) != (h, w):
        padded = []
        for f in frames:
            g = np.full((ph, pw, 3), 255, np.uint8)
            g[:h, :w] = f
            padded.append(g)
        frames = padded
    with imageio.get_writer(path, fps=fps, codec="libx264",
                            quality=9, macro_block_size=1) as wr:
        for f in frames:
            wr.append_data(f)


def write_pngs(frames, stem, fps=None):
    from PIL import Image
    paths = []
    for i, f in enumerate(frames):
        p = f"{stem}_{i:04d}.png"
        Image.fromarray(f).save(p)
        paths.append(p)
    return paths


def write_filmstrip(frames, path, columns=None):
    from PIL import Image
    ims = [Image.fromarray(f) for f in frames]
    n = len(ims)
    cols = columns or n
    rows = (n + cols - 1) // cols
    w, h = ims[0].size
    sheet = Image.new("RGB", (w * cols, h * rows), "white")
    for i, im in enumerate(ims):
        sheet.paste(im, ((i % cols) * w, (i // cols) * h))
    sheet.save(path)
    return path


def turn_sequence(n_turns, rate, n_hold, n_pause, ease, oneway=None,
                  total=None, duration=None, bounce=True):
    """Which turn, and how far through it, for every frame of a clip.

    Returns (sequence, forward_frames).  The clip runs through each turn
    in order, holding on the intermediate orientations, and - unless
    `bounce` is off - comes back the way it went.  The hold on the final
    orientation is shared between the two legs, so a full cycle is a
    little less than twice the forward pass.
    """
    legs = 2 if bounce else 1
    fixed = n_hold * (legs + 1) + n_pause * (n_turns - 1) * legs
    if oneway:
        c_turn = int(round(oneway * rate)) - 2 * n_hold \
                 - n_pause * (n_turns - 1)
        least = 2 * n_hold + n_pause * (n_turns - 1)
        budget = f"a one-way pass of {oneway:g}s"
    elif total:
        c_turn = (int(round(total * rate)) - fixed) // legs
        least = fixed
        budget = f"a total of {total:g}s"
    else:
        c_turn = max(2, int(round((duration or 2.0) * rate))) * n_turns
        least = budget = None
    if c_turn < 2 * n_turns:
        raise ValueError(
            f"{budget} leaves no room to turn: the holds alone take "
            f"{least / rate:.2f}s over {n_turns} turn(s)")
    # spread the remainder over the turns rather than truncating it away,
    # so the clip lands on the requested length to the frame
    counts = [c_turn // n_turns + (1 if i < c_turn % n_turns else 0)
              for i in range(n_turns)]
    core = []
    for si in range(n_turns):
        core += [(si, t) for t in timeline(counts[si], 0, ease)]
        if si < n_turns - 1:
            core += [(si, 1.0)] * n_pause
    seq = [(0, 0.0)] * n_hold + core + [(n_turns - 1, 1.0)] * n_hold
    forward = len(seq)
    if bounce:
        seq += [(si, t) for si, t in reversed(core)] + [(0, 0.0)] * n_hold
    return seq, forward
