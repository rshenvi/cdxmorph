"""Command line for cdxmorph.

    cdxmorph render A.cdxml B.cdxml -o morph.gif [-c config.json]
    cdxmorph editor A.cdxml B.cdxml -o editor.html
    cdxmorph still  A.cdxml -o A.png
    cdxmorph check  A.cdxml B.cdxml -c config.json
"""
import argparse
import json

import numpy as np
import os
import sys
import time

from . import scene as cs
from . import animate as mo
from . import config as cfgmod
from . import rotate as rot
from . import render as rd
from . import editor as ed


def _load_scenes(args):
    """Structures to animate through, with a display name for each.

    Two files give two structures.  One file gives however many it draws,
    in the order its reaction arrows imply - so a scheme of three
    structures and two arrows animates 1 -> 2 -> 3.
    """
    if getattr(args, "product", None):
        return ([cs.parse_cdxml(args.start), cs.parse_cdxml(args.product)],
                [os.path.basename(args.start), os.path.basename(args.product)])
    scenes = cs.parse_sequence(args.start)
    if len(scenes) < 2:
        raise SystemExit(
            f"{args.start} draws {len(scenes)} structure(s); need at least "
            "two, or pass a second file")
    stem = os.path.splitext(os.path.basename(args.start))[0]
    return scenes, [f"{stem} #{i + 1}" for i in range(len(scenes))]


def _sidecar(args):
    """A mapping saved next to the drawing, used when none is given.

    An example shipped with the pairing its author settled on should
    render that way when a newcomer opens it, rather than falling back to
    the automatic match and looking worse than it is.
    """
    first = getattr(args, "start", None)
    if not first:
        return None
    for cand in (os.path.splitext(first)[0] + ".mapping.json",
                 first + ".mapping.json"):
        if os.path.exists(cand):
            print(f"using mapping {os.path.basename(cand)}", file=sys.stderr)
            return cand
    return None


def _prepare(args):
    """Aligned scenes plus one (nmap, bmap, bover) per transition."""
    scenes, names = _load_scenes(args)
    cfg = cfgmod.load(args.config or _sidecar(args))
    st = cfgmod.style(cfg)
    cfgmod.apply_style(st)
    cs.HASH_SPACING = st.get("hash_spacing")
    cs.GAP_SCALE = st.get("gap_scale", cs.GAP_SCALE)
    mo.ALLOW_FLIP = bool(cfg.get("flip", False))
    mo.DISSOLVE = float(cfg.get("dissolve", 1.0))
    n_stages = len(scenes) - 1
    maps = [cfgmod.resolve(cfgmod.stage(cfg, i, n_stages),
                           scenes[i], scenes[i + 1]) for i in range(n_stages)]
    # superimpose, so the structures morph in place instead of marching
    # across the page in their drawn positions
    scenes = rd.align_chain(scenes, [m[0] for m in maps])
    return scenes, names, cfg, st, maps


def _mixed_page(path):
    """(stages, True) when a page holds BOTH a guided turn and a reaction.

    Only then does the combined path take over.  A page whose equivalency
    signs have no 3D poses above them keeps the behaviour it has always
    had - the turn is matched by connectivity and animated as a morph -
    so nothing already approved changes underneath.
    """
    try:
        _, stages, _ = cs.page_stages(path)
    except Exception:
        return None, False
    kinds = {s["kind"] for s in stages}
    guided = any(s["kind"] == "turn" and s["solid"] for s in stages)
    return stages, bool(guided and "morph" in kinds)


def _pingpong(frames):
    """The clip played forward then backward, without repeating either end.

    A morph that cuts from the product back to the start reads as a jump.
    Playing it back reverses the same frames, so the clip closes on the
    structure it opened with and loops without a cut.
    """
    return frames + list(reversed(frames[1:-1]))


def cmd_render(args):
    t_start = time.time()
    stages, mixed = _mixed_page(args.start)
    if stages and (mixed or any(s["kind"] == "turn" for s in stages)):
        # Not only MIXED pages: a page that is all reorientations holds
        # fewer transitions than it holds structures, and the reaction path
        # counts the raw fragment chain instead - so a mapping saved for the
        # two transitions it animates was rejected as having too few blocks,
        # and the fallback morphed every structure into the next.  The same
        # condition `check` and the mapper already use.
        return _render_page(args, t_start)
    scenes, names, cfg, st, maps = _prepare(args)
    tm = cfgmod.timing(cfg)
    for k, v in (("duration", args.duration), ("fps", args.fps),
                 ("total", getattr(args, "total", None))):
        if v is not None:
            tm[k] = v

    # a GIF can only store delays in hundredths of a second, so count
    # frames at the rate it will actually play at, not the one asked for
    ext = os.path.splitext(args.out)[1].lower()
    rate = rd.gif_rate(tm["fps"]) if ext == ".gif" else tm["fps"]

    n_hold = int(round(tm["hold"] * rate))
    n_mid = int(round((args.pause if args.pause is not None
                       else cfg.get("pause", 0.0)) * rate))
    if tm.get("total"):
        # fix the whole clip: the moving part is what is left after the
        # holds and the pauses between structures, so two files with
        # different numbers of structures still run the same length
        fixed = 2 * n_hold + n_mid * max(0, len(maps) - 1)
        n_core = int(round(tm["total"] * rate)) - fixed
        if n_core < 2 * len(maps):
            raise SystemExit(
                f"total of {tm['total']}s leaves no room to move: holds and "
                f"pauses alone take {fixed / rate:.2f}s over "
                f"{len(maps)} transition(s); raise total or lower "
                "hold/pause")
    else:
        n_core = max(2, int(round(tm["duration"] * rate)))
    box = rd.canvas_box(scenes, pad=st["pad"])

    scale = st["scale"]
    if args.width:                     # honour an explicit pixel width
        scale = args.width * 72.0 / (st["dpi"] * (box[2] - box[0]))

    frames = rd.render_chain(scenes, maps, box, n_core, n_hold,
                             hold_mid=n_mid, easing=tm["ease"],
                             scale=scale, dpi=st["dpi"],
                             workers=args.workers)
    if args.bounce:
        frames = _pingpong(frames)
    if ext == ".gif":
        rd.write_gif(frames, args.out, fps=tm["fps"])
    elif ext in (".mp4", ".m4v"):
        rd.write_mp4(frames, args.out, fps=tm["fps"])
    elif ext == ".png":
        rd.write_pngs(frames, os.path.splitext(args.out)[0])
    else:
        raise SystemExit(f"unsupported output extension {ext!r}; "
                         "use .gif, .mp4 or .png")

    if args.keyframes:
        # every structure, plus the midpoint of every transition
        ims, ts_probe = [], rd.timeline(n_core, 0, tm["ease"])
        r = rd.Renderer(box, scale=scale, dpi=st["dpi"])
        try:
            for i, (nmap, bmap, bover) in enumerate(maps):
                A, B = scenes[i], scenes[i + 1]
                sw = mo.plan_swaps(A, B, nmap, bmap, ts_probe, bover,
                                   A.doc["MarginWidth"])
                fl = mo.reflection_axis(A, B, nmap)
                tn = mo.turn_plan(A, B, nmap)
                kk = mo.kekule_shift(A, B, bmap and nmap, bmap)
                kk = (kk, mo.kekule_time(A, kk, tn)) if kk else None
                keys = [0.0, 0.5] + ([1.0] if i == len(maps) - 1 else [])
                ims += [r.draw(mo.assemble(*mo.frame(A, B, nmap, bmap, t,
                                                     bover=bover, flip=fl,
                                                     turn=tn, kekule=kk),
                                           A.doc, t, sw)) for t in keys]
        finally:
            r.close()
        rd.write_filmstrip(ims, args.keyframes)

    stages = [{"kind": "morph", "from": names[i], "to": names[i + 1],
               **cfgmod.summary(scenes[i], scenes[i + 1], *maps[i])}
              for i in range(len(maps))]
    h, w = frames[0].shape[:2]
    print(json.dumps({"structures": len(scenes), "stages": stages,
                      "frames": len(frames), "size": f"{w}x{h}",
                      "seconds": round(time.time() - t_start, 2),
                      "out": args.out}, indent=1))


def cmd_rotate(args):
    t_start = time.time()
    cfg = cfgmod.load(args.config or _sidecar(args.start))
    st = cfgmod.style(cfg)
    cfgmod.apply_style(st)
    cs.HASH_SPACING = st.get("hash_spacing")
    cs.GAP_SCALE = st.get("gap_scale", cs.GAP_SCALE)
    try:
        scenes = cs.parse_sequence(args.start)
        stages = rot.guide_stages(scenes)
        # A reorientation can be paired by hand too.  Where a ring maps onto
        # its own image a position round, the automatic pairing leaves an
        # atom over - it fades out mid-turn and another fades in - and no
        # amount of 3D helps, because every ring carbon looks alike.  The
        # mapping file a reaction already uses is honoured here as well:
        # the poses still supply the axis and the depth, and only which
        # atom becomes which is taken from the file.
        for i, sp in enumerate(stages):
            block = cfgmod.stage(cfg, i, len(stages))
            if block.get("pairs"):
                sp["pairs"] = cfgmod.resolve(block, sp["A"], sp["B"])[0]
        poses, notes = rot.build_turns(
            scenes, st, flip_h=args.flip_h,
            flat_h=args.flat_h, blend_labels=args.blend_labels,
            guide=args.guide, stages=stages if not args.guide else None)
    except ValueError as exc:
        raise SystemExit(f"{args.start}: {exc}")
    for note in notes:
        if note.get("not_turning"):
            print(f"note: {note['not_turning']} drawn atom(s) have no "
                  "counterpart in the 3D pose and will not turn",
                  file=sys.stderr)
    n_turns = len(poses)

    tm = cfgmod.timing(cfg)
    for k, v in (("duration", args.duration), ("fps", args.fps),
                 ("total", args.total)):
        if v is not None:
            tm[k] = v
    if args.pause is not None:
        tm["pause"] = args.pause

    ext = os.path.splitext(args.out)[1].lower()
    rate = rd.gif_rate(tm["fps"]) if ext == ".gif" else tm["fps"]
    n_hold = int(round(tm["hold"] * rate))
    n_pause = int(round(tm.get("pause", 0.0) * rate))
    try:
        seq, forward = rd.turn_sequence(
            n_turns, rate, n_hold, n_pause, tm["ease"], oneway=args.oneway,
            total=tm.get("total"), duration=tm["duration"],
            bounce=args.bounce)
    except ValueError as exc:
        raise SystemExit(str(exc))

    # one canvas for every angle every turn passes through, so nothing
    # drifts or clips
    xs, ys = [], []
    for si in range(n_turns):
        for t in np.linspace(0.0, 1.0, 25):
            x0, y0, x1, y1 = poses[si](float(t)).extent()
            xs += [x0, x1]; ys += [y0, y1]
    box = (min(xs) - st["pad"], min(ys) - st["pad"],
           max(xs) + st["pad"], max(ys) + st["pad"])
    scale = st["scale"]
    if args.width:
        scale = args.width * 72.0 / (st["dpi"] * (box[2] - box[0]))

    r = rd.Renderer(box, scale=scale, dpi=st["dpi"])
    try:
        frames = [r.draw(cs.build_strokes(poses[si](t))) for si, t in seq]
    finally:
        r.close()

    if ext == ".gif":
        rd.write_gif(frames, args.out, fps=tm["fps"])
    elif ext == ".mp4":
        rd.write_mp4(frames, args.out, fps=tm["fps"])
    else:
        rd.write_pngs(frames, args.out)
    if args.keyframes:
        keys = []
        for si in range(n_turns):
            keys += [(si, 0.0), (si, 0.5)]
        keys.append((n_turns - 1, 1.0))
        r2 = rd.Renderer(box, scale=scale, dpi=st["dpi"])
        try:
            ims = [r2.draw(cs.build_strokes(poses[si](t))) for si, t in keys]
        finally:
            r2.close()
        rd.write_filmstrip(ims, args.keyframes)

    h, w = frames[0].shape[:2]
    print(json.dumps({
        "turns": n_turns,
        "oneway_seconds": round(forward / rate, 3),
        "cycle_seconds": round(len(seq) / rate, 3),
        "stages": notes,
        "frames": len(frames), "size": f"{w}x{h}",
        "seconds": round(time.time() - t_start, 2), "out": args.out},
        indent=1))



def _render_page(args, t_start):
    """Render a page that mixes reorientations and reactions as one clip."""
    cfg = cfgmod.load(args.config or _sidecar(args.start))
    st = cfgmod.style(cfg)
    cfgmod.apply_style(st)
    cs.HASH_SPACING = st.get("hash_spacing")
    cs.GAP_SCALE = st.get("gap_scale", cs.GAP_SCALE)
    funcs, notes, scenes = rd.page_clip(args.start, st, cfg)

    tm = cfgmod.timing(cfg)
    for k, v in (("duration", args.duration), ("fps", args.fps),
                 ("total", args.total)):
        if v is not None:
            tm[k] = v
    if args.pause is not None:
        tm["pause"] = args.pause
    ext = os.path.splitext(args.out)[1].lower()
    rate = rd.gif_rate(tm["fps"]) if ext == ".gif" else tm["fps"]
    n_hold = int(round(tm["hold"] * rate))
    n_pause = int(round(tm.get("pause", 0.0) * rate))
    n_core = max(2 * len(funcs), int(round(tm["duration"] * rate)))
    if tm.get("total"):
        want = int(round(tm["total"] * rate))
        n_core = max(2 * len(funcs),
                     want - 2 * n_hold - n_pause * (len(funcs) - 1))
    base, rem = divmod(n_core, len(funcs))

    # one canvas for every frame of every stage, so nothing drifts or clips
    box = rd.frames_box(funcs, pad=st["pad"])
    scale = st["scale"]
    if args.width:
        scale = args.width * 72.0 / (st["dpi"] * (box[2] - box[0]))

    seq = []
    for i in range(len(funcs)):
        per = max(2, base + (1 if i < rem else 0))
        if i == 0:
            seq += [(0, 0.0)] * n_hold
        seq += [(i, t) for t in rd.timeline(per, 0, tm["ease"])]
        if i < len(funcs) - 1:
            seq += [(i, 1.0)] * n_pause
    seq += [(len(funcs) - 1, 1.0)] * n_hold

    r = rd.Renderer(box, scale=scale, dpi=st["dpi"])
    try:
        frames = [r.draw(funcs[i](t)) for i, t in seq]
        if args.keyframes:
            keys = [(i, u) for i in range(len(funcs)) for u in (0.0, 0.5)]
            keys.append((len(funcs) - 1, 1.0))
            ims = [r.draw(funcs[i](t)) for i, t in keys]
    finally:
        r.close()

    if args.bounce:
        frames = _pingpong(frames)
    if ext == ".gif":
        rd.write_gif(frames, args.out, fps=tm["fps"])
    elif ext == ".mp4":
        rd.write_mp4(frames, args.out, fps=tm["fps"])
    else:
        rd.write_pngs(frames, args.out)
    if args.keyframes:
        rd.write_filmstrip(ims, args.keyframes)
    h, w = frames[0].shape[:2]
    print(json.dumps({"page": "turns and reactions",
                      "stages": notes, "frames": len(frames),
                      "size": f"{w}x{h}",
                      "seconds": round(time.time() - t_start, 2),
                      "out": args.out}, indent=1))


def cmd_editor(args):
    stages, mixed = _mixed_page(args.start) if not getattr(args, "product", None) \
        else (None, False)
    if mixed or any(s["kind"] == "turn" for s in (stages or [])):
        # Every stage this page holds gets an editor, turn or reaction.  A
        # turn takes its motion from the 3D poses, but WHICH atom becomes
        # which still has to be decided, and the poses cannot settle a ring
        # that maps onto itself a position round.  What must not happen is
        # the fallback below taking over on such a page: it pairs the drawn
        # fragments in page order, which on a reorientation means pairing a
        # pose against a drawing - exactly what nobody wants.
        cfg = cfgmod.load(args.config)
        stem, ext = os.path.splitext(args.out)
        written = []
        for i, sp in enumerate(stages):
            if sp["kind"] not in ("morph", "turn"):
                continue
            block = cfgmod.stage(cfg, i, len(stages))
            if sp["kind"] == "turn" and sp.get("solid") and not block.get("pairs"):
                # Show what the TURN actually does.  Prefilling from the
                # reaction matchers would put a different pairing in front of
                # the chemist than the one being animated, and the first
                # thing they would do is correct a mapping that was never used.
                solid_pairs, _how = rot.pair_solid(*sp["solid"])
                nmap = rot.pair_drawn(sp["A"], sp["B"], *sp["solid"],
                                      solid_pairs)[0]
            else:
                nmap = cfgmod.resolve(block, sp["A"], sp["B"])[0]
            path = f"{stem}_stage{i + 1}{ext}"
            with open(path, "w") as fh:
                fh.write(ed.build(sp["A"], sp["B"], nmap,
                                  name_a=f"structure {i + 1}",
                                  name_b=f"structure {i + 2}"))
            written.append({"out": path, "stage": i + 1, "kind": sp["kind"],
                            "prefilled_pairs": len(nmap)})
        if not written:
            print(json.dumps({"note": "this page has nothing to pair"}, indent=1))
            return
        print(json.dumps(written if len(written) > 1 else written[0], indent=1))
        return
    scenes, names, cfg, st, maps = _prepare(args)
    stem, ext = os.path.splitext(args.out)
    written = []
    for i, (nmap, _, _) in enumerate(maps):
        # one editor per transition; a single transition keeps the given name
        path = args.out if len(maps) == 1 else f"{stem}_stage{i + 1}{ext}"
        with open(path, "w") as fh:
            fh.write(ed.build(scenes[i], scenes[i + 1], nmap,
                              name_a=names[i], name_b=names[i + 1]))
        written.append({"out": path, "stage": i + 1,
                        "kind": "morph", "from": names[i], "to": names[i + 1],
                        "prefilled_pairs": len(nmap)})
    print(json.dumps(written if len(written) > 1 else written[0], indent=1))


def cmd_still(args):
    # a still obeys the same style block as an animation, so a figure and
    # the frames around it are drawn with one set of settings
    st = cfgmod.style(cfgmod.load(getattr(args, "config", None)))
    cfgmod.apply_style(st)
    cs.HASH_SPACING = st.get("hash_spacing")
    cs.GAP_SCALE = st.get("gap_scale", cs.GAP_SCALE)
    sc = cs.parse_cdxml(args.start)
    box = rd.canvas_box([sc], pad=st["pad"])
    r = rd.Renderer(box, scale=st["scale"], dpi=args.dpi)
    try:
        img = r.draw(cs.build_strokes(sc))
    finally:
        r.close()
    from PIL import Image
    Image.fromarray(img).save(args.out)
    print(json.dumps({"out": args.out,
                      "size": f"{img.shape[1]}x{img.shape[0]}"}, indent=1))


def cmd_check(args):
    # A page whose 3D poses guide the drawings beneath them holds fewer
    # transitions than it holds fragments, and two kinds of transition.
    # Reporting the raw fragment chain here would describe a file nobody
    # is going to render - including in the browser, which asks this
    # command what the file contains.
    stages, mixed = _mixed_page(args.start) if not getattr(args, "product", None) \
        else (None, False)
    if stages and (mixed or any(s["kind"] == "turn" for s in stages)):
        # The renderer animates an equivalency sign with no 3D copy above it
        # as a move in the plane, since there is no pose to measure a turn
        # from.  Report what it will do, not what the sign says.
        stages = [dict(s, kind="morph")
                  if (s["kind"] == "turn" and rd._flat_pair(s)) else s
                  for s in stages]
        cfg = cfgmod.load(args.config)
        kinds = {s["kind"] for s in stages}
        out = {"page": ("turns and reactions" if mixed else
                        "reorientations" if kinds == {"turn"} else "reactions"),
               "structures": len(stages) + 1, "stages": []}
        for i, sp in enumerate(stages):
            if sp["kind"] == "turn":
                row = {"kind": "turn"}
                blk = cfgmod.stage(cfg, i, len(stages))
                if sp["solid"]:
                    SA, SB = sp["solid"]
                    prs, how = rot.pair_solid(SA, SB)
                    # Ask the renderer what it will do, rather than working
                    # it out again here: a second copy of this reasoning is
                    # how the report came to omit what the turn had decided
                    # - which atoms keep their drawn angle, which crossings
                    # the drawing settled - while the animation used it.
                    plan = dict(mode="guided", A=sp["A"], B=sp["B"],
                                solid=(SA, SB))
                    if blk.get("pairs"):
                        plan["pairs"] = cfgmod.resolve(blk, sp["A"], sp["B"])[0]
                    _, ns = rot.build_turns([], cfgmod.style(cfg),
                                            stages=[plan])
                    row.update({k: v for k, v in ns[0].items()
                                if v not in (None, [], {}, 0)})
                    nmap = (plan.get("pairs")
                            or rot.pair_drawn(sp["A"], sp["B"], SA, SB, prs)[0])
                    row["pairing"] = ("given by hand" if blk.get("pairs")
                                      else "composed through the 3D pair")
                    row["atoms"] = f"{len(nmap)} of {len(sp['A'].nodes)}"
                    row["bonds"] = (f"{len(mo.match_bonds(sp['A'], sp['B'], nmap))}"
                                    f" of {len(sp['A'].bonds)}")
                out["stages"].append(row)
                continue
            blk = cfgmod.stage(cfg, i, len(stages))
            nmap, bmap, bover = cfgmod.resolve(blk, sp["A"], sp["B"])
            out["stages"].append(
                {"kind": "morph",
                 **cfgmod.summary(sp["A"], sp["B"], nmap, bmap, bover)})
        print(json.dumps(out, indent=1))
        return
    scenes, names, cfg, st, maps = _prepare(args)
    out = {"structures": len(scenes),
           "stages": [{"kind": "morph", "from": names[i], "to": names[i + 1],
                       **cfgmod.summary(scenes[i], scenes[i + 1], *maps[i])}
                      for i in range(len(maps))],
           "crossings": {}}
    for nm, sc in zip(names, scenes):
        found, decl = cs.audit_crossings(sc)
        out["crossings"][nm] = {
            "drawn": len(found), "declared_by_chemdraw": len(decl),
            "drawn_but_not_declared": len(found - decl),
            "declared_but_not_drawn": len(decl - found)}
    print(json.dumps(out, indent=1))


def cmd_serve(args):
    """Run the browser interface."""
    try:
        from .web import create_app
    except ImportError:
        sys.stderr.write("the browser interface needs Flask: "
                         "pip install 'cdxmorph[web]'\n")
        return 2
    app = create_app(root=args.data)
    port = args.port
    if port == 0 or _port_busy(args.host, port):
        port = _free_port(args.host) or (args.port or 5000)
    # Check the port BEFORE handing it to the server: werkzeug prints its
    # own terse error and exits, so a failure there never reaches the
    # message below.
    if not _can_bind(args.host, port):
        sys.stderr.write(
            f"\ncdxmorph could not open a connection on this computer.\n"
            f"Something is blocking it - usually security software or a "
            f"firewall.\nTry a different port, for example:\n"
            f"    cdxmorph serve --port 8000\n"
            f"or ask your IT contact to allow this program to open a "
            f"local connection.\n")
        return 1
    url = f"http://{args.host}:{port}"
    sys.stderr.write(f"cdxmorph is running at {url}\n"
                     f"Leave this window open while you use it; "
                     f"close it to stop.\n")
    if args.open:
        import threading
        import webbrowser
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    try:
        app.run(host=args.host, port=port, debug=False)
    except OSError as exc:
        # a plain sentence, not a traceback: whoever sees this is trying to
        # use the program, not debug it
        sys.stderr.write(
            f"\ncdxmorph could not open a connection on this computer "
            f"({exc}).\n"
            f"Something is blocking it - usually security software or a "
            f"firewall.\nTry again with a specific port, for example:\n"
            f"    cdxmorph serve --port 8000\n"
            f"or ask your IT contact to allow this program to open a local "
            f"connection.\n")
        return 1
    return 0


def _can_bind(host, port):
    """True if the server will be able to listen here."""
    import socket
    try:
        with socket.socket() as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, port))
        return True
    except OSError:
        return False


def _port_busy(host, port):
    import socket
    try:
        with socket.socket() as s:
            s.settimeout(0.3)
            return s.connect_ex((host if host != "0.0.0.0" else "127.0.0.1",
                                 port)) == 0
    except OSError:
        return False


def _free_port(host):
    """A port the operating system says is free, so two copies of the
    program - or anything else already using 5000 - do not collide.

    Returns None where the machine refuses to hand one out (some managed
    computers block it); the caller then uses the requested port.
    """
    import socket
    try:
        with socket.socket() as s:
            s.bind((host if host != "0.0.0.0" else "127.0.0.1", 0))
            return s.getsockname()[1]
    except OSError:
        return None          # locked-down machine; caller falls back


def build_parser():
    p = argparse.ArgumentParser(
        prog="cdxmorph",
        description="Animate one ChemDraw structure into another as line art.")
    sub = p.add_subparsers(dest="cmd", required=True)

    def pair(sp, need_out=True):
        sp.add_argument("start", help="a .cdxml holding one structure, or "
                                      "a whole reaction scheme")
        sp.add_argument("product", nargs="?",
                        help="second .cdxml; omit when `start` already "
                             "draws every structure")
        sp.add_argument("-c", "--config", help="mapping / timing JSON")
        if need_out:
            sp.add_argument("-o", "--out", required=True)

    r = sub.add_parser("render", help="write the animation")
    pair(r)
    r.add_argument("--fps", type=float)
    r.add_argument("--duration", type=float, help="seconds, excluding holds")
    r.add_argument("--total", type=float,
                   help="fix the whole clip to this many seconds, holds and "
                        "pauses included, so files with different numbers "
                        "of structures finish together")
    r.add_argument("--width", type=int, help="output width in pixels")
    r.add_argument("--keyframes", help="also write a filmstrip PNG here")
    r.add_argument("--bounce", action="store_true",
                   help="play the clip forward then backward, so it loops "
                        "without cutting from the product back to the start")
    r.add_argument("--pause", type=float,
                   help="seconds to hold on each intermediate structure")
    r.add_argument("-j", "--workers", type=int, default=1,
                   help="render frames across N processes")
    r.set_defaults(func=cmd_render)

    e = sub.add_parser("editor", help="write the click-to-pair mapping editor")
    pair(e)
    e.set_defaults(func=cmd_editor)
    rp = sub.add_parser("rotate", help="turn a 3D depiction from one drawn "
                                       "orientation to the other")
    rp.add_argument("start", help=".cdxml holding two depictions of one "
                                  "molecule, each with 3D coordinates")
    rp.add_argument("-o", "--out", required=True, help=".gif, .mp4 or .png")
    rp.add_argument("-c", "--config")
    rp.add_argument("--duration", type=float, help="seconds per leg")
    rp.add_argument("--total", type=float,
                    help="fix the whole clip to this many seconds")
    rp.add_argument("--oneway", type=float,
                    help="seconds for one pass start to finish; the clip "
                         "ping-pongs by default, so the way back adds the "
                         "same again (--once for a single pass)")
    rp.add_argument("--fps", type=int)
    rp.add_argument("--width", type=int)
    rp.add_argument("--keyframes", help="write a filmstrip PNG here")
    rp.add_argument("--no-label-blend", dest="blend_labels",
                    action="store_false", default=True,
                    help="keep the first drawing's label metrics for the "
                         "whole turn, instead of carrying each label to "
                         "where the next drawing puts it")
    rp.add_argument("--pause", type=float,
                    help="seconds to hold on each intermediate orientation")
    rp.add_argument("--no-flat-h", dest="flat_h", action="store_false",
                    default=True,
                    help="keep the crystal's depth on lone hydrogens, so a "
                         "C-H bond may appear much longer than it is drawn "
                         "as the molecule turns")
    rp.add_argument("--no-flip-h", dest="flip_h", action="store_false",
                    default=True,
                    help="leave the H of an OH or NH on the side the first "
                         "drawing puts it, instead of moving it to the side "
                         "away from the structure as the molecule turns")
    rp.add_argument("--guide", action="store_true",
                    help="turn the 3D pair itself, ignoring any hand-drawn "
                         "pair in the file")
    rp.add_argument("--once", dest="bounce", action="store_false",
                    default=True,
                    help="turn one way only; the default returns")
    rp.set_defaults(func=cmd_rotate)


    s = sub.add_parser("still", help="render one structure")
    s.add_argument("start")
    s.add_argument("-o", "--out", required=True)
    s.add_argument("--dpi", type=int, default=200)
    s.add_argument("-c", "--config", help="style settings to draw with")
    s.set_defaults(func=cmd_still)

    sv = sub.add_parser("serve", help="run the browser interface")
    sv.add_argument("--host", default="127.0.0.1",
                    help="bind address; 0.0.0.0 to expose on the network")
    sv.add_argument("--port", type=int, default=5000,
                help="0, or a busy port, picks a free one")
    sv.add_argument("--open", action="store_true",
                    help="open the page in a browser once the server is up")
    sv.add_argument("--data", default=None,
                    help="where session folders live "
                         "(default $CDXMORPH_DATA or ./cdxmorph_sessions)")
    sv.set_defaults(func=cmd_serve)

    c = sub.add_parser("check", help="validate a config and audit occlusion")
    pair(c, need_out=False)
    c.set_defaults(func=cmd_check)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        # a command that fails returns non-zero; pass it on so scripts and
        # launchers can tell success from failure
        return args.func(args) or 0
    except cfgmod.ConfigError as exc:
        print(f"config error: {exc}", file=sys.stderr)
        return 2
