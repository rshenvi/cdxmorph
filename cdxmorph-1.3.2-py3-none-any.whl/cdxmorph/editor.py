"""Emit a self-contained click-to-pair mapping editor for two CDXML scenes."""
import json, os, sys
from . import scene as cs
from . import animate as mo

CREDIT = "Developed by Ryan Shenvi @ ShenviLab"


def _logo_uri():
    """The lab mark as a data URI.

    An editor page is often saved and opened straight off disk with no
    server behind it, so the image has to travel inside the file.
    """
    import base64
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     "static", "shenvi-lab.png")
    try:
        with open(p, "rb") as fh:
            return "data:image/png;base64," + base64.b64encode(fh.read()).decode()
    except OSError:
        return ""


TPL = """<!DOCTYPE html><html><head><meta charset="utf-8">
<title>__NAMEA__ &rarr; __NAMEB__ &mdash; element mapping</title>
<style>
 body{font:13px/1.45 -apple-system,Segoe UI,Helvetica,sans-serif;margin:0;
      background:#fafafa;color:#222}
 header{padding:10px 16px;background:#fff;border-bottom:1px solid #ddd;
        display:flex;gap:16px;align-items:center;flex-wrap:wrap}
 .lab{margin-left:auto;line-height:0;opacity:.85}
 .lab img{height:24px;width:auto;display:block}
 h1{font-size:15px;margin:0;font-weight:600}
 button{font:inherit;padding:5px 11px;border:1px solid #bbb;background:#fff;
        border-radius:5px;cursor:pointer}
 button:hover{background:#f0f0f0}
 #wrap{display:flex;gap:8px;padding:8px}
 .pane{flex:1;background:#fff;border:1px solid #ddd;border-radius:6px;padding:6px}
 .pane h2{font-size:12px;margin:2px 6px 6px;color:#666;font-weight:600}
 svg{width:100%;height:auto;display:block}
 .hit{cursor:pointer}
 .hit circle{fill:#fff;fill-opacity:0.01;stroke:#c00;stroke-width:0.5;
             stroke-opacity:0.35}
 .hit text{font:3.2px Arial;fill:#c00;text-anchor:middle;pointer-events:none}
 .hit.sel circle{fill:#ffd54a;fill-opacity:0.85;stroke:#b8860b;stroke-width:0.9}
 .hit.paired circle{stroke-width:1.1;stroke-opacity:1;fill-opacity:0.35}
 #side{width:270px;background:#fff;border:1px solid #ddd;border-radius:6px;
       padding:8px;max-height:88vh;overflow:auto}
 #side h2{font-size:12px;margin:2px 0 6px;color:#666}
 .row{display:flex;justify-content:space-between;padding:2px 4px;border-radius:3px}
 .row:hover{background:#f3f3f3}
 .row b{font-weight:600}
 .x{color:#999;cursor:pointer}
 .x:hover{color:#c00}
 code{background:#eee;padding:1px 4px;border-radius:3px}
</style></head><body>
<!-- __CREDIT__ -->
<header>
 <h1>Element mapping &mdash; click a numbered atom on the left, then its partner on the right</h1>
 <button onclick="selAll()">Select the JSON (then &#8984;C / Ctrl-C)</button>
 <button onclick="dl()">Try download</button>
 <button onclick="clearAll()">Clear all</button>
 __TOOLBAR__
 <span id="stat"></span>
 <span id="bstat" style="margin-left:auto"></span>
<span class="lab" title="__CREDIT__"><img src="__LOGO__" alt="Shenvi Laboratory"></span>
</header>
<div id="wrap">
 <div class="pane"><h2>A &mdash; __NAMEA__</h2>__SVGA__</div>
 <div class="pane"><h2>B &mdash; __NAMEB__</h2>__SVGB__</div>
 <div id="side"><h2>Pairs</h2><div id="list"></div>
  <h2 style="margin-top:10px">Unpaired A</h2><div id="ua"></div>
  <h2 style="margin-top:10px">Unpaired B</h2><div id="ub"></div>
  <h2 style="margin-top:12px">mapping.json</h2>
  <textarea id="json" spellcheck="false" style="width:100%;height:150px;
   font:11px/1.35 ui-monospace,Menlo,Consolas,monospace;border:1px solid #ccc;
   border-radius:4px;padding:5px;resize:vertical"></textarea>
  __FOOTNOTE__</div>
</div>
<script>
const NUMA=__NUMA__, NUMB=__NUMB__, BA=__BONDA__, BB=__BONDB__;
let pairs=__PAIRS__, sel=null;
function bonds(){
 // which bonds survive under the current pairing
 const seen={}; for(const id in BB) seen[BB[id][0]+'|'+BB[id][1]]=id;
 const okA={}, okB={};
 for(const id in BA){const [u,v]=BA[id];
  if(!(u in pairs)||!(v in pairs))continue;
  const p=pairs[u],q=pairs[v];
  const j=(seen[p+'|'+q]!==undefined)?seen[p+'|'+q]:seen[q+'|'+p];
  if(j!==undefined){okA[id]=1;okB[j]=1;}}
 return [okA,okB];
}
function paintBonds(){
 const [okA,okB]=bonds();
 let nb=0,nf=0;
 for(const [side,B,ok,col] of [['A',BA,okA,'#d32f2f'],['B',BB,okB,'#2e7d32']]){
  for(const id in B){
   document.querySelectorAll('#s'+side+' [data-b="'+id+'"]').forEach(p=>{
    if(ok[id]){p.style.stroke='';p.style.strokeWidth='';}
    else{p.style.stroke=col;p.style.strokeWidth='1.6';}});
   if(!ok[id]){side==='A'?nb++:nf++;}}}
 document.getElementById('bstat').innerHTML=
  '<b style="color:#2e7d32">'+Object.keys(okA).length+'</b> bonds carried over &nbsp;'+
  '<b style="color:#d32f2f">'+nb+'</b> break &nbsp;'+
  '<b style="color:#2e7d32">'+nf+'</b> form';
}
function hue(i){return 'hsl('+((i*67)%360)+',75%,45%)';}
function el(side,id){return document.querySelector('#s'+side+' [data-id="'+id+'"]');}
function paint(){
 document.querySelectorAll('.hit').forEach(g=>{g.classList.remove('paired','sel');
   g.querySelector('circle').style.stroke='';g.querySelector('circle').style.fill='';});
 let i=0;
 for(const a in pairs){const b=pairs[a],c=hue(i++);
   for(const [s,id] of [['A',a],['B',b]]){const g=el(s,id);if(!g)continue;
     g.classList.add('paired');const ci=g.querySelector('circle');
     ci.style.stroke=c;ci.style.fill=c;}}
 if(sel){const g=el('A',sel);if(g)g.classList.add('sel');}
 const inv={};for(const a in pairs)inv[pairs[a]]=a;
 let h='';i=0;
 for(const a in pairs){h+='<div class="row"><span><b style="color:'+hue(i++)+
   '">&#9679;</b> A'+NUMA[a]+' &rarr; B'+NUMB[pairs[a]]+'</span>'+
   '<span class="x" onclick="unpair(\\''+a+'\\')">&times;</span></div>';}
 document.getElementById('list').innerHTML=h||'<i style="color:#999">none</i>';
 document.getElementById('ua').innerHTML=Object.keys(NUMA).filter(k=>!(k in pairs))
   .map(k=>'A'+NUMA[k]).join(', ')||'<i style="color:#999">none</i>';
 document.getElementById('ub').innerHTML=Object.keys(NUMB).filter(k=>!(k in inv))
   .map(k=>'B'+NUMB[k]).join(', ')||'<i style="color:#999">none</i>';
 document.getElementById('stat').textContent=Object.keys(pairs).length+' pairs';
 document.getElementById('json').value=text();
 paintBonds();
}
function text(){const o={};for(const a in pairs)o[NUMA[a]]=NUMB[pairs[a]];
 // "exact": this page starts from the automatic match, so what it exports
 // is the complete pairing - an atom left out was left out on purpose and
 // must not be matched back in
 return JSON.stringify({pairs:o, exact:true});}
function selAll(){const t=document.getElementById('json');
 t.focus();t.select();t.setSelectionRange(0,t.value.length);
 try{navigator.clipboard.writeText(t.value);}catch(e){}}
function unpair(a){delete pairs[a];paint();}
function clearAll(){pairs={};sel=null;paint();}
document.addEventListener('click',e=>{
 const g=e.target.closest('.hit');if(!g)return;
 const side=g.closest('svg').id.slice(1), id=g.dataset.id;
 if(side==='A'){ if(id in pairs)delete pairs[id]; sel=(sel===id?null:id); }
 else { if(!sel)return;
   for(const a in pairs)if(pairs[a]===id)delete pairs[a];
   pairs[sel]=id; sel=null; }
 paint();});
function dl(){const s=text();
 try{const u=URL.createObjectURL(new Blob([s],{type:'application/json'}));
  const a=document.createElement('a');a.href=u;a.download='mapping.json';
  document.body.appendChild(a);a.click();a.remove();}catch(e){}
 try{window.open('data:application/json;charset=utf-8,'+
  encodeURIComponent(s),'_blank');}catch(e){}
 selAll();}
paint();
</script></body></html>"""


def hits(sc, side):
    x0, y0, x1, y1 = sc.extent()
    g = []
    for k, n in sc.nodes.items():
        p = n["p"]
        g.append(f'<g class="hit" data-id="{k}">'
                 f'<circle cx="{p[0]:.2f}" cy="{p[1]:.2f}" r="2.6"/>'
                 f'<text x="{p[0]:.2f}" y="{p[1]+1.2:.2f}">{n["atom_id"]}</text></g>')
    return "\n".join(g)


def bond_table(sc):
    """bond id -> [node id, node id]; keys match the data-b tags in the SVG."""
    return {bid: [b["b"], b["e"]] for bid, b in sc.bonds.items()}


def svg_for(sc, side, pad=7.0):
    x0, y0, x1, y1 = sc.extent()
    body = cs.to_svg(cs.build_strokes(sc))
    return (f'<svg id="s{side}" viewBox="{x0-pad:.2f} {y0-pad:.2f} '
            f'{x1-x0+2*pad:.2f} {y1-y0+2*pad:.2f}">\n'
            f'<g opacity="0.85">{body}</g>\n{hits(sc, side)}\n</svg>')


DEFAULT_FOOTNOTE = ('<p style="color:#777;font-size:11px;margin-top:8px">'
                    'Atom numbers are the red labels in the drawings. Paste '
                    'this text back into the chat, or save it as '
                    '<code>mapping.json</code> and re-run the morph.</p>')


def build(A, B, nmap=None, name_a="starting structure", name_b="product",
          toolbar="", footnote=None):
    """Self-contained click-to-pair editor for any two parsed scenes.

    `toolbar` is extra HTML placed in the header and `footnote` replaces the
    closing note, so the same page can be served inside a web interface with
    a Save button instead of copy-and-paste instructions.  The editor's
    script uses global element ids, so embed one per page, not several.
    """
    if nmap is None:
        nmap = mo.match_nodes(A, B)
    esc = lambda s: (str(s).replace("&", "&amp;")
                     .replace("<", "&lt;").replace(">", "&gt;"))
    return (TPL.replace("__SVGA__", svg_for(A, "A"))
               .replace("__SVGB__", svg_for(B, "B"))
               .replace("__NUMA__", json.dumps({k: v["atom_id"] for k, v in A.nodes.items()}))
               .replace("__NUMB__", json.dumps({k: v["atom_id"] for k, v in B.nodes.items()}))
               .replace("__BONDA__", json.dumps(bond_table(A)))
               .replace("__BONDB__", json.dumps(bond_table(B)))
               .replace("__PAIRS__", json.dumps(nmap))
               .replace("__CREDIT__", CREDIT)
               .replace("__LOGO__", _logo_uri())
               .replace("__NAMEA__", esc(name_a))
               .replace("__NAMEB__", esc(name_b))
               .replace("__TOOLBAR__", toolbar)
               .replace("__FOOTNOTE__", DEFAULT_FOOTNOTE if footnote is None
                        else footnote))
