"""Read ChemDraw CDXML as pure 2D line-art (no chemistry), and render it
reproducing ChemDraw's occlusion behaviour: painter's order by Z, with the
back element clipped where a front element crosses it.
"""
import math
import re
try:
    # A hosted copy parses files from anyone with the URL, and the stdlib
    # parser will happily expand a small file into gigabytes of entities.
    # defusedxml refuses; without it the stdlib parser is used unchanged.
    import defusedxml.ElementTree as ET
except ImportError:                                  # pragma: no cover
    import xml.etree.ElementTree as ET

from collections import deque

import numpy as np
import matplotlib
import matplotlib.patches
import matplotlib.patheffects as pe

# White space drawn around atom-label letterforms, in ChemDraw points.  This
# is NOT MarginWidth: that governs where bonds attached to a label are
# trimmed, and is applied geometrically.  This is only the separation a
# passing bond or a neighbouring label must keep from the glyphs.
LABEL_CLEARANCE = 0.45

# Gap a circled charge keeps from every bond and every neighbouring
# glyph, in ChemDraw points.  A charge that grazes the structure reads as
# part of it, so the sign is moved out until it clears by this much.
CHARGE_CLEARANCE = 0.8

# Size of the sign inside a circled charge, as a multiple of the ring's
# radius.  A sign much smaller than its ring reads as a dot.
CHARGE_GLYPH = 1.95

# The family the canvas draws text in.  Glyph metrics are measured in the
# SAME font: measuring one font and drawing another put every derived
# position - stacked baselines, the box a bond is cut at, the centre of a
# charge sign - out by the difference between them.
TEXT_FAMILY = "Arial"

# Charges paint above everything: a sign bitten by a neighbouring letter's
# clearance is unreadable, and a charge is never what should give way.
CHARGE_Z = 10000.0

# --- double-bond inner line -------------------------------------------------
# The offset line of a double bond stops short of the bonds leaving each end.
# A fixed inset is angle-blind and lets the line touch a neighbour that leaves
# at a shallow angle, so the stopping point is found geometrically and then
# backed off.  Clearance is LineWidth + MarginWidth (taken from the file, so
# it scales with the drawing): one stroke width to stop the two overlapping,
# plus the document margin so a visible gap is left rather than a butt joint.

# Inset used at an end with no neighbour to measure against, as a fraction of
# bond length.  Applies to the offset form of a double bond; the symmetric
# form is drawn full length at a terminal atom, as ChemDraw does.
INNER_DEFAULT_INSET = 0.14

# Most of one end that may be trimmed away, as a fraction of bond length.
# Without this an almost-parallel neighbour would consume the whole line.
INNER_MAX_INSET = 0.45

# Floor on sin(angle) when converting a perpendicular clearance into a
# distance along the line.  Bounds the 1/sin blow-up at shallow angles.
INNER_SIN_FLOOR = 0.25

# Shortest stroke, in multiples of line width, that still reads as a bond
# rather than a speck.  A shorter leftover is dropped -- unless it is the
# piece still joining an atom label to the drawing.
MIN_FRAGMENT = 1.5



# ---------------------------------------------------------------- parsing

def _pt(s):
    a, b = s.split()
    return float(a), float(b)


def _bbox(s):
    a, b, c, d = (float(v) for v in s.split())
    return [a, b, c, d]          # x0 y0 x1 y1, y grows DOWNWARD


class Scene:
    """Flat drawing: nodes (optionally carrying a text label) and bonds."""

    def __init__(self):
        self.doc = {}
        self.colors = []          # colortable, index i in file -> table[i-2]
        self.fonts = {}
        self.frag_id = None
        self.nodes = {}           # id -> dict(p, z, color, label)
        self.bonds = {}           # id -> dict(b, e, order, z, color, crossing)

    def rgb(self, idx):
        if isinstance(idx, (tuple, list)):
            return tuple(float(v) for v in idx)   # a colour set directly
        if idx is None or idx == 0:
            return (0.0, 0.0, 0.0)
        if idx == 1:
            return (1.0, 1.0, 1.0)
        return self.colors[idx - 2]

    def extent(self):
        xs, ys = [], []
        for n in self.nodes.values():
            xs.append(n["p"][0]); ys.append(n["p"][1])
            if n["label"]:
                x0, y0, x1, y1 = n["label"]["bbox"]
                xs += [x0, x1]; ys += [y0, y1]
        return min(xs), min(ys), max(xs), max(ys)



def page_stages(path, overlap=0.45):
    """Every animated step a page holds, in order, typed turn or morph.

    Two kinds of step can share a page.  An EQUIVALENCY sign - ChemDraw's
    three short rules - between two drawings says one molecule redrawn in
    another orientation, which animates as a TURN.  A reaction ARROW says
    one structure becomes another, which animates as a MORPH.

    A drawing carrying 3D coordinates that sits directly above another is
    not a step of its own: it is the pose that tells a turn how to move,
    and is never drawn.  That is how a reorientation gets its axis and
    angle without anyone specifying them.

    Returns (scenes, stages, guides).  `scenes` are the drawings that will
    actually be animated, in order; each stage is
    {"kind", "A", "B", "solid"}, where `solid` is the pair of 3D poses
    behind a turn, or None when the turn has to be measured from the
    drawings themselves.
    """
    root = ET.parse(path).getroot()
    base = parse_cdxml(path)

    def build(frags):
        sc = Scene()
        sc.doc, sc.colors, sc.fonts = base.doc, base.colors, base.fonts
        sc.frag_id = frags[0].get("id")
        sc.frag_ids = [f.get("id") for f in frags]
        sc.equiv_to_prev = False
        _fill(sc, frags)
        return sc if sc.nodes else None

    frags = _top_fragments(root)
    scenes = {f.get("id"): build([f]) for f in frags}
    scenes = {k: v for k, v in scenes.items() if v}
    has3d = {k: sum(1 for n in v.nodes.values() if n.get("xyz"))
             for k, v in scenes.items()}

    def span(sc):
        x0, y0, x1, y1 = sc.extent()
        return (x0, x1), (y0, y1)

    # A pose guides the drawing beneath it: same column, lower on the page.
    guides = {}
    for k, sc in scenes.items():
        if has3d[k] < 3:
            continue
        (ax0, ax1), (ay0, ay1) = span(sc)
        best = None
        for j, other in scenes.items():
            if j == k or has3d[j] >= 3:
                continue
            (bx0, bx1), (by0, by1) = span(other)
            if by0 <= ay1:                       # not below this pose
                continue
            share = min(ax1, bx1) - max(ax0, bx0)
            frac = share / max(1e-6, min(ax1 - ax0, bx1 - bx0))
            if frac >= overlap and (best is None or by0 < best[1]):
                best = (j, by0)
        if best:
            guides[best[0]] = k                  # drawn id -> pose id

    drawn = [k for k in scenes if has3d[k] < 3 or k in set(guides.values()) and False]
    drawn = [k for k in scenes if k not in set(guides.values())]

    # Equivalency signs join two drawings in the same row into a turn.
    edges = {}
    for cx, cy in _equiv_symbols(root):
        row = []
        for k in drawn:
            (x0, x1), (y0, y1) = span(scenes[k])
            if y0 - 12 <= cy <= y1 + 12:
                row.append((x0, x1, k))
        left = [r for r in row if r[1] <= cx]
        right = [r for r in row if r[0] >= cx]
        if not left or not right:
            continue
        a = max(left, key=lambda r: r[1])[2]
        b = min(right, key=lambda r: r[0])[2]
        edges.setdefault(a, ("turn", b))

    # Reaction arrows join a structure to what it becomes.
    by_id = {f.get("id"): f for f in frags}
    # A step may name a GROUP rather than the fragment inside it - ChemDraw
    # wraps a structure in one whenever it carries a label or annotation -
    # so resolve any id to the fragments it contains.
    alias = {k: [k] for k in scenes}
    for g in root.iter("group"):
        inner = [f.get("id") for f in g.iter("fragment") if f.get("id") in scenes]
        if inner:
            alias[g.get("id")] = inner
    expand = lambda ids: [k for i in ids for k in alias.get(i, [])]
    for step in root.iter("step"):
        r = expand((step.get("ReactionStepReactants") or "").split())
        p = expand((step.get("ReactionStepProducts") or "").split())
        if not r or not p:
            continue
        arrows = set((step.get("ReactionStepArrows") or "").split())
        tail = None
        for g in root.iter("graphic"):
            if g.get("id") in arrows:
                hx, hy, tx, ty = _bbox(g.get("BoundingBox"))
                tail = np.array([tx, ty], float)
        # the reactant the arrow actually leaves from, and the nearest product
        pick = lambda ids: min(
            ids, key=lambda k: float(np.hypot(*(np.asarray(
                _frag_centre(by_id[k]), float) - tail)))) if tail is not None else ids[0]
        a, b = pick(r), pick(p)
        edges.setdefault(a, ("morph", b))

    # Walk the page: start where nothing arrives, follow one edge at a time.
    targets = {v for _, v in edges.values()}
    starts = [k for k in drawn if k not in targets and k in edges]
    if not starts:
        starts = sorted(drawn, key=lambda k: scenes[k].extent()[0])[:1]
    order, stages, cur, seen = [], [], starts[0], set()
    while cur is not None and cur not in seen:
        seen.add(cur)
        order.append(cur)
        nxt = edges.get(cur)
        if not nxt:
            break
        kind, b = nxt
        solid = None
        if kind == "turn" and cur in guides and b in guides:
            solid = (scenes[guides[cur]], scenes[guides[b]])
        stages.append(dict(kind=kind, A=scenes[cur], B=scenes[b], solid=solid))
        cur = b
    if cur is not None and cur not in order:
        order.append(cur)
    return ([scenes[k] for k in order], stages,
            {k: scenes[v] for k, v in guides.items()})

def parse_cdxml(path):
    root = ET.parse(path).getroot()
    sc = Scene()

    for k in ("LineWidth", "MarginWidth", "BoldWidth", "HashSpacing",
              "BondLength", "BondSpacing", "LabelSize"):
        if k in root.attrib:
            sc.doc[k] = float(root.attrib[k])
    sc.doc.setdefault("LineWidth", 1.0)
    sc.doc.setdefault("MarginWidth", 1.6)
    sc.doc.setdefault("BondLength", 14.4)
    sc.doc.setdefault("BondSpacing", 18.0)

    ct = root.find("colortable")
    sc.colors = [(float(c.get("r")), float(c.get("g")), float(c.get("b")))
                 for c in ct.findall("color")] if ct is not None else []
    ft = root.find("fonttable")
    if ft is not None:
        sc.fonts = {f.get("id"): f.get("name") for f in ft.findall("font")}

    _fill(sc, _top_fragments(root))
    return sc


def translated(sc, delta):
    """Copy of `sc` shifted by `delta`, labels and their boxes included.

    Used to superimpose structures that a reaction scheme draws side by
    side.  Only the page offset is removed - any relative rotation between
    the two drawings is left in place, so it animates as a real rotation
    rather than being silently fitted away.
    """
    dx, dy = float(delta[0]), float(delta[1])
    out = Scene()
    out.doc, out.colors, out.fonts = sc.doc, sc.colors, sc.fonts
    out.frag_id = sc.frag_id
    out.bonds = sc.bonds
    for k, n in sc.nodes.items():
        lab = n["label"]
        if lab is not None:
            x0, y0, x1, y1 = lab["bbox"]
            lab = dict(lab, bbox=[x0 + dx, y0 + dy, x1 + dx, y1 + dy],
                       anchor=(lab["anchor"][0] + dx, lab["anchor"][1] + dy))
        out.nodes[k] = dict(n, p=(n["p"][0] + dx, n["p"][1] + dy), label=lab)
    return out


def parse_sequence(path):
    """Every drawn structure in a CDXML, in reaction order.

    A ChemDraw reaction scheme records each arrow as a step naming the
    fragments on either side of it, so the order is read from the file
    rather than guessed.  A side may name SEVERAL fragments - two
    molecules drawn beside each other with no arrow between them - and
    those are ONE structure as far as the animation is concerned: they
    sit together on the page and move together into whatever the arrow
    points at.  Anything no arrow mentions keeps its place in reading
    order after the chain, and a file with no scheme at all is simply
    taken left to right.  Returns a list of Scenes; a one-structure file
    gives a list of one.
    """
    root = ET.parse(path).getroot()
    base = parse_cdxml(path)

    def build(frags):
        sc = Scene()
        sc.doc, sc.colors, sc.fonts = base.doc, base.colors, base.fonts
        sc.frag_id = frags[0].get("id")
        sc.frag_ids = [f.get("id") for f in frags]
        sc.equiv_to_prev = False
        _fill(sc, frags)
        return sc if sc.nodes else None

    chain, rest, equiv_at = _reaction_groups(root)
    scenes = [sc for sc in (build(g) for g in chain) if sc]
    # a scene split off by an equivalency sign is the SAME molecule redrawn
    for k, sc in enumerate(scenes):
        sc.equiv_to_prev = k in equiv_at
    extra = sorted((sc for sc in (build([f]) for f in rest) if sc),
                   key=lambda sc: sc.extent()[0])
    return scenes + extra


def _equiv_symbols(root, max_len=25.0, max_gap=8.0):
    """Centres of equivalency symbols drawn on the page.

    ChemDraw has no object for the three-bar sign that says "this is the
    same molecule drawn another way": it is two or more short parallel
    rules stacked close together.  Reaction arrows carry an ArrowType and
    page furniture is far longer, so a cluster of short headless rules is
    the sign.
    """
    segs = []
    for g in root.iter("graphic"):
        if g.get("ArrowType") or g.get("GraphicType") != "Line":
            continue
        x0, y0, x1, y1 = _bbox(g.get("BoundingBox"))
        L = float(np.hypot(x1 - x0, y1 - y0))
        if L < 1e-6 or L > max_len:
            continue
        segs.append((0.5 * (x0 + x1), 0.5 * (y0 + y1)))
    out, used = [], set()
    for i, a in enumerate(segs):
        if i in used:
            continue
        grp, used_here = [a], {i}
        for j, b in enumerate(segs):
            if j in used or j == i:
                continue
            if abs(a[0] - b[0]) < max_gap and abs(a[1] - b[1]) < 2 * max_gap:
                grp.append(b)
                used_here.add(j)
        if len(grp) >= 2:
            used |= used_here
            out.append((sum(p[0] for p in grp) / len(grp),
                        sum(p[1] for p in grp) / len(grp)))
    return out


def _frag_centre(f):
    pts = [_pt(n.get("p")) for n in f.findall("n") if n.get("p")]
    if not pts:
        return (0.0, 0.0)
    return (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))


def _arrow_dir(root, ids):
    """Direction of travel of the named arrow, tail to head.

    A reaction step names the arrow GRAPHIC, whose BoundingBox holds its
    head first and tail second; the separate <arrow> objects carry their
    own ids and cannot be looked up by the step's.  Travel matters because
    a row of a scheme may read right to left, which is how the page wraps.
    """
    for g in root.iter("graphic"):
        if g.get("id") not in ids:
            continue
        hx, hy, tx, ty = _bbox(g.get("BoundingBox"))
        d = np.array([hx - tx, hy - ty], float)
        n = float(np.hypot(*d))
        if n > 1e-9:
            return d / n
    return np.array([1.0, 0.0])


def _split_side(frags, equivs, direction):
    """One side of an arrow, as one or more consecutive scenes.

    Fragments drawn side by side are ONE scene - a reagent joining the
    picture.  But where an equivalency sign sits between two of them they
    are the same molecule redrawn, which is a reorientation: consecutive
    scenes, ordered along the arrow's own direction of travel.
    """
    if len(frags) < 2 or not equivs:
        return [list(frags)]
    cen = {f.get("id"): np.asarray(_frag_centre(f), float) for f in frags}
    linked = set()
    for a in frags:
        for b in frags:
            if a is b:
                continue
            ca, cb = cen[a.get("id")], cen[b.get("id")]
            for e in equivs:
                e = np.asarray(e, float)
                v = cb - ca
                L2 = float(v @ v)
                if L2 < 1e-9:
                    continue
                u = float(np.clip((e - ca) @ v / L2, 0.0, 1.0))
                if 0.05 < u < 0.95 and float(np.hypot(*(e - (ca + u * v)))) < 40.0:
                    linked.add(frozenset((a.get("id"), b.get("id"))))
    if not linked:
        return [list(frags)]
    order = sorted(frags, key=lambda f: float(cen[f.get("id")] @ direction))
    return [[f] for f in order]


def _reaction_groups(root):
    """(groups along the arrows, fragments no arrow mentions).

    Each group is one scene.  Walking the steps by which fragments they
    SHARE rather than by exact equality matters: a later step may add a
    reactant the previous one never produced - a new structure entering
    the sequence - and demanding identical sides breaks the chain there,
    dropping the whole scheme back to reading order.
    """
    frags = _top_fragments(root)
    by_id = {f.get("id"): f for f in frags}
    equivs = _equiv_symbols(root)
    equiv_at = set()
    steps = []
    for step in root.iter("step"):
        r = tuple(i for i in (step.get("ReactionStepReactants") or "").split()
                  if i in by_id)
        p = tuple(i for i in (step.get("ReactionStepProducts") or "").split()
                  if i in by_id)
        if r and p:
            steps.append((r, p, set((step.get("ReactionStepArrows") or "").split())))
    groups = []
    if steps:
        produced = {i for _, p, _ in steps for i in p}
        starts = [k for k, (r, _, _) in enumerate(steps)
                  if not (set(r) & produced)]
        cur = starts[0] if starts else 0
        seen = set()
        while cur is not None and cur not in seen:
            seen.add(cur)
            r, p, arrows = steps[cur]
            d = _arrow_dir(root, arrows)
            parts = _split_side([by_id[i] for i in r], equivs, d)
            for n_, grp in enumerate(parts):
                ids = [f.get("id") for f in grp]
                if groups and [f.get("id") for f in groups[-1]] == ids:
                    continue
                if n_ and len(parts) > 1:
                    equiv_at.add(len(groups))
                groups.append(grp)
            nxt = None
            for k, (r2, _, _) in enumerate(steps):
                if k not in seen and (set(r2) & set(p)):
                    nxt = k
                    break
            if nxt is None:
                for grp in _split_side([by_id[i] for i in p], equivs, d):
                    groups.append(grp)
            cur = nxt
    used = {f.get("id") for grp in groups for f in grp}
    rest = [f for f in frags if f.get("id") not in used]
    return groups, rest, equiv_at


def _top_fragments(root):
    """Drawn fragments, in document order.  A fragment nested inside a
    Nickname node is the expansion of an abbreviation and is never drawn."""
    nested = {id(f) for n in root.iter("n") for f in n.findall("fragment")}
    return [f for f in root.iter("fragment") if id(f) not in nested]


def _fill(sc, frags):
    """Load nodes and bonds of `frags` into an already-configured Scene.

    Every node remembers which drawn fragment it came from: a scene built
    from several fragments is several molecules on the page, and matching
    them onto the next structure works far better one fragment at a time.
    """
    for frag in frags:
        for n in frag.findall("n"):
            lab = None
            t = n.find("t")
            if t is not None:
                # ChemDraw splits a label into one <s> run per style change,
                # so an italic prefix is its own run: "i-Pr" arrives as "i"
                # + "-Pr".  Taking only the first run truncates the label.
                runs = t.findall("s")
                text = "".join(x.text or "" for x in runs)
                s = max(runs, key=lambda x: len(x.text or ""), default=None)
                face = int(s.get("face", "0")) if s is not None else 0
                lab = dict(
                    text=text,
                    bbox=_bbox(t.get("BoundingBox")),
                    anchor=_pt(t.get("p")),
                    size=float(s.get("size", sc.doc.get("LabelSize", 8))),
                    font=sc.fonts.get(s.get("font"), "Arial"),
                    bold=bool(face & 1),
                    italic=bool(face & 2),
                    color=int(s.get("color", n.get("color", 0))),
                    just=t.get("LabelJustification", "Left"),
                    align=t.get("LabelAlignment", ""),
                )
            # A structure ChemDraw built from a crystal file carries a real
            # 3D coordinate per atom whose first two components ARE the
            # drawing position: the picture is an orthographic projection
            # with depth in the third.  Kept so a depiction can be turned.
            xyz = n.get("xyz")
            sc.nodes[n.get("id")] = dict(
                frag=frag.get("id"),
                p=_pt(n.get("p")),
                xyz=([float(v) for v in xyz.split()] if xyz else None),
                z=float(n.get("Z", 0)),
                color=int(n.get("color", 0)),
                label=lab,
                element=n.get("Element"),
                atom_id=n.get("AtomID"),
                # ChemDraw's own atom numbering, present on a structure
                # built from a crystal file.  It survives redrawing and
                # re-posing, so it pairs two depictions exactly where a
                # geometric match cannot.
                number=n.get("AtomNumber"),
                kind=n.get("NodeType", "Element"),
                charge=int(n.get("Charge", 0) or 0),
            )

        for b in frag.findall("b"):
            sc.bonds[b.get("id")] = dict(
                b=b.get("B"), e=b.get("E"),
                order=int(b.get("Order", 1)),
                z=float(b.get("Z", 0)),
                color=int(b.get("color", 0)),
                display=b.get("Display", "Solid"),
                crossing=(b.get("CrossingBonds", "").split()
                          if b.get("CrossingBonds") else []),
            )
    return sc


# ------------------------------------------------------- geometry helpers

def _clip_to_box(p0, p1, box, margin):
    """Shorten segment p0->p1 so it stops outside `box` (inflated by margin).
    Only the end(s) that start inside the box are moved."""
    x0, y0, x1, y1 = box
    x0 -= margin; y0 -= margin; x1 += margin; y1 += margin

    def inside(p):
        return x0 <= p[0] <= x1 and y0 <= p[1] <= y1

    p0 = np.asarray(p0, float); p1 = np.asarray(p1, float)
    d = p1 - p0
    L = np.hypot(*d)
    if L < 1e-9:
        return p0, p1
    ts = [0.0, 1.0]
    for lo, hi, ax in ((x0, x1, 0), (y0, y1, 1)):
        if abs(d[ax]) > 1e-12:
            for v in (lo, hi):
                t = (v - p0[ax]) / d[ax]
                if 0 < t < 1:
                    q = p0 + t * d
                    o = 1 - ax
                    lo2, hi2 = (y0, y1) if ax == 0 else (x0, x1)
                    if lo2 - 1e-9 <= q[o] <= hi2 + 1e-9:
                        ts.append(t)
    ts = sorted(set(ts))
    keep = []
    for a, b in zip(ts[:-1], ts[1:]):
        mid = p0 + 0.5 * (a + b) * d
        if not inside(mid):
            keep.append((a, b))
    if not keep:
        return None
    return p0 + keep[0][0] * d, p0 + keep[-1][1] * d


def _seg_cross(a0, a1, b0, b1):
    """Intersection of two segments -> (s_along_a, sin_angle) or None."""
    r = a1 - a0
    s = b1 - b0
    den = r[0] * s[1] - r[1] * s[0]
    if abs(den) < 1e-12:
        return None
    t = ((b0[0] - a0[0]) * s[1] - (b0[1] - a0[1]) * s[0]) / den
    u = ((b0[0] - a0[0]) * r[1] - (b0[1] - a0[1]) * r[0]) / den
    if not (0.0 < t < 1.0 and 0.0 < u < 1.0):
        return None
    Lr, Ls = np.hypot(*r), np.hypot(*s)
    sin_th = abs(den) / (Lr * Ls)
    return t * Lr, max(sin_th, 0.15)


# Sine of the smallest angle at which two strokes count as crossing.  A
# grazing, nearly-parallel pass produces a long overlap and so a long
# break, which reads as the bond being split for no visible reason -
# there is no line crossing it at that point, only one alongside it.
MIN_CROSS_SIN = 0.30


def crosses_transversely(a0, a1, b0, b1):
    """True if these two strokes meet at enough of an angle for a break
    between them to read as one passing behind the other."""
    u = np.asarray(a1, float) - np.asarray(a0, float)
    v = np.asarray(b1, float) - np.asarray(b0, float)
    nu, nv = float(np.hypot(*u)), float(np.hypot(*v))
    if nu < 1e-9 or nv < 1e-9:
        return False
    sin = abs(float(u[0] * v[1] - u[1] * v[0])) / (nu * nv)
    return sin >= MIN_CROSS_SIN


def _overlap_span(a0, a1, b0, b1, thresh):
    """Arc-length interval of segment a that lies within `thresh` of segment
    b, i.e. the stretch of a that b's stroke-plus-margin actually covers.
    Exact for crossings and for near-misses alike.  None if never covered."""
    d = a1 - a0
    L = float(np.hypot(*d))
    e = b1 - b0
    L2 = float(e @ e)
    if L < 1e-9 or L2 < 1e-12:
        return None
    # cheap bounding-box reject
    if (min(a0[0], a1[0]) - thresh > max(b0[0], b1[0]) or
            max(a0[0], a1[0]) + thresh < min(b0[0], b1[0]) or
            min(a0[1], a1[1]) - thresh > max(b0[1], b1[1]) or
            max(a0[1], a1[1]) + thresh < min(b0[1], b1[1])):
        return None
    n = max(24, int(L / 0.1))
    s = np.linspace(0.0, L, n)
    P = a0 + np.outer(s / L, d)
    u = np.clip((P - b0) @ e / L2, 0.0, 1.0)
    dist = np.hypot(*(P - (b0 + u[:, None] * e)).T)
    idx = np.flatnonzero(dist <= thresh)
    if idx.size == 0:
        return None
    return float(s[idx[0]]), float(s[idx[-1]])


def inner_span(q0, q1, apex0, nbrs0, apex1, nbrs1, clear,
               default=INNER_DEFAULT_INSET):
    """Start and end fractions along the offset line of a double bond.

    ChemDraw stops the inner line short of the bonds leaving each end
    rather than running it the full length.  A fixed inset is angle-blind:
    where a neighbour leaves at a shallow angle the inner line still
    reaches it and the two strokes touch.  This finds where the inner line
    would meet each neighbour and backs off by `clear` (a full stroke width
    plus the document margin, so a visible gap is left, not a butt joint),
    measured
    perpendicular so shallow angles get the longer inset they need.
    """
    q0 = np.asarray(q0, float); q1 = np.asarray(q1, float)
    d = q1 - q0
    L = float(np.hypot(*d))
    if L < 1e-9:
        return 0.0, 1.0

    def inset(apex, nbrs, from_start):
        apex = np.asarray(apex, float)
        best = default
        for m in nbrs:
            e = np.asarray(m, float) - apex
            den = d[0] * e[1] - d[1] * e[0]
            ne = float(np.hypot(*e))
            if abs(den) < 1e-9 or ne < 1e-9:
                continue
            w = apex - q0
            t = (w[0] * e[1] - w[1] * e[0]) / den      # along the inner line
            u = (w[0] * d[1] - w[1] * d[0]) / den      # along the neighbour
            if u <= 0.0:                 # neighbour points the other way
                continue
            sin_th = abs(den) / (L * ne)
            back = (clear / max(sin_th, INNER_SIN_FLOOR)) / L
            frac = (t + back) if from_start else (1.0 - t + back)
            best = max(best, min(frac, INNER_MAX_INSET))
        return best

    return inset(apex0, nbrs0, True), 1.0 - inset(apex1, nbrs1, False)


def keep_segments(p0, p1, segs, w, labelled):
    """Discard fragments too short to read as a bond - EXCEPT one that still
    touches a labelled atom.  That fragment may be a stub, but dropping it
    cuts the label loose from the drawing, which reads as an error; a stub
    reads as a bond disappearing behind whatever crosses it.

    labelled : (bool, bool) - whether the p0 and p1 ends carry a label."""
    L = float(np.hypot(*(p1 - p0)))
    out = []
    for s0, s1 in segs:
        if float(np.hypot(*(s1 - s0))) > MIN_FRAGMENT * w:
            out.append((s0, s1))
        elif ((labelled[0] and float(np.hypot(*(s0 - p0))) < 1e-6) or
              (labelled[1] and abs(float(np.hypot(*(s1 - p0))) - L) < 1e-6)):
            out.append((s0, s1))
    return out


def _punch(p0, p1, cuts):
    """Remove arc-length intervals (lo, hi); return the surviving pieces."""
    d = p1 - p0
    L = np.hypot(*d)
    if L < 1e-9:
        return []
    keep = [(0.0, L)]
    for lo, hi in cuts:
        nxt = []
        for a, b in keep:
            if lo <= a and hi >= b:
                continue
            if hi <= a or lo >= b:
                nxt.append((a, b)); continue
            if lo > a:
                nxt.append((a, lo))
            if hi < b:
                nxt.append((hi, b))
        keep = nxt
    u = d / L
    return [(p0 + a * u, p0 + b * u) for a, b in keep if b - a > 1e-6]


# --------------------------------------------------------------- strokes

# A token is one chemical unit.  A lowercase locant prefix binds to the
# group it names ("i-Pr", "t-Bu") and must not be split off or dropped;
# a bare lowercase run is a token in its own right so nothing vanishes.
# A bracketed unit is ONE token, brackets and all: a metal written [Rh]
# must not be taken apart, or reversing a right-aligned label turns it
# into ]Rh[.
_TOKEN = re.compile(r"\[[^\]]*\]|(?:[a-z]+-)?[A-Z][a-z]*\d*|[a-z]+\d*|\d+"
                    r"|[^A-Za-z0-9]+")


WEDGE_DISPLAYS = {"WedgeBegin", "WedgeEnd", "WedgedHashBegin",
                  "WedgedHashEnd", "Hash", "Bold", "Dash"}


# Least fraction of a bond that must survive its crossing gaps.  Below
# this the bond reads as a stub rather than a line passing behind, so the
# widest gap is given up instead.
MIN_SURVIVING = 0.20

# Shortest piece a crossing gap may leave behind.  Below this the remnant
# reads as a stray mark rather than part of a bond, so the gap that would
# create it is given up instead.
MIN_PIECE = 2.5

# How much of the document's MarginWidth a crossing gap actually uses.
# ChemDraw's full margin leaves a white band wide enough to swallow a
# narrow angle where two bonds meet just past a crossing, so the gap is
# drawn at three quarters of it by default.  1.0 restores ChemDraw's.
GAP_SCALE = 0.75

# Spacing between the rungs of a hashed wedge, in ChemDraw points.  This
# overrides the document's own HashSpacing, which at its default of 2.1
# puts seven rungs on an ordinary bond - denser than most figures want.
# Set it to None to use whatever the document specifies.
HASH_SPACING = 3.0

# Most parts a single bond may be broken into and still read as one bond.
MAX_PIECES = 2

# Longest a crossing break may be, as a multiple of the nominal break
# (line width plus twice the margin).
GAP_MAX = 1.5


def punch_surviving(p0, p1, cuts, w, labelled, max_gap=None):
    """Punch crossing gaps, backing off only where the bond stops reading.

    Every crossing gets its break -- losing one costs the reader the depth
    cue the break exists to give.  Only where the result stops reading as
    a single bond is a break given up: when the cuts erase the bond
    outright, leave too little of it, or dice it into more parts than a
    reader accepts as one bond.  Then the NARROWEST break is dropped
    first, since the widest crossing is the one most worth showing.  A
    piece too short to read is discarded rather than drawn -- what
    ChemDraw shows when a bond is crossed near its end -- unless it is
    the last thing joining a labelled atom to the drawing.
    """
    P0, P1 = np.asarray(p0, float), np.asarray(p1, float)
    full = float(np.hypot(*(P1 - P0)))
    solid = lambda segs: [(a, b, 1.0) for a, b in segs]
    if not cuts or full < 1e-9:
        return solid(keep_segments(p0, p1, [(p0, p1)], w, labelled))
    if max_gap:
        # Two bonds sweeping past each other are nearly parallel at first
        # contact, so the overlap - and the gap - is briefly enormous and
        # arrives in one frame.  A break only has to read as a break.
        cuts = [(0.5 * (a + b) - 0.5 * min(b - a, max_gap),
                 0.5 * (a + b) + 0.5 * min(b - a, max_gap))
                for a, b in cuts]

    def pieces(cs_):
        """Surviving pieces, each with an opacity weight.

        Keeping or discarding a piece at a hard threshold makes it blink
        on and off as the drawing moves and its length drifts across that
        threshold.  A piece near the limit fades instead, so the decision
        is continuous in the geometry.
        """
        kept = []
        thr = max(MIN_PIECE, MIN_FRAGMENT * w)
        for s0, s1 in _punch(p0, p1, cs_):
            A, B = np.asarray(s0, float), np.asarray(s1, float)
            L = float(np.hypot(*(B - A)))
            at_label = (
                (labelled[0] and float(np.hypot(*(A - P0))) < 1e-6)
                or (labelled[1] and abs(float(np.hypot(*(B - P0))) - full) < 1e-6))
            if at_label or L >= thr:
                kept.append((s0, s1, 1.0))
            elif L > 0.1 * thr:
                kept.append((s0, s1, L / thr))
        return kept

    # widest break last to be dropped: it is the crossing most worth showing
    cs = sorted(cuts, key=lambda c: c[0] - c[1])
    while cs:
        sg = pieces(cs)
        tot = sum(float(np.hypot(*(np.asarray(b, float) - np.asarray(a, float)))) * wt
                  for a, b, wt in sg)
        if sg and len(sg) <= MAX_PIECES and tot >= MIN_SURVIVING * full:
            return sg
        cs = cs[:-1]                      # give up the narrowest break
    return solid(keep_segments(p0, p1, [(p0, p1)], w, labelled))


def hash_count(sc, bid):
    """Number of rungs on a hashed bond, from the structure as DRAWN.

    Recomputing this from the current frame's length makes a rung appear
    or vanish mid-animation as the bond stretches, which reads as a jump.
    """
    step = hash_step(sc.doc)
    memo = getattr(sc, "_hash_n", None)
    # keyed by the spacing too, so changing the setting is not masked by
    # a count cached under the previous one
    if memo is None or memo.get("_step") != step:
        memo = sc._hash_n = {"_step": step}
    if bid not in memo:
        bd = sc.bonds[bid]
        p0 = np.asarray(sc.nodes[bd["b"]]["p"], float)
        p1 = np.asarray(sc.nodes[bd["e"]]["p"], float)
        memo[bid] = max(int(float(np.hypot(*(p1 - p0))) / step), 1)
    return memo[bid]


def hash_step(doc):
    """Rung spacing to draw with: the setting, or the document's own."""
    return max(doc.get("HashSpacing", 2.1) if HASH_SPACING is None
               else HASH_SPACING, 0.6)


def stereo_shape(display, p0, p1, doc, lw, rungs=None):
    """Geometry for a stereo bond drawn from `p0` (begin) to `p1` (end).

    Returns (kind, payload):
      ("poly",  [corner, ...])          a filled wedge
      ("rungs", [(a, b), ...])          a hashed wedge, one segment per rung
      ("line",  [(p0, p1)], width)      bold or plain
    ChemDraw narrows a wedge at the stereocentre: "Begin" means the point
    is at the bond's begin atom, "End" that it is at the other end.
    """
    p0 = np.asarray(p0, float); p1 = np.asarray(p1, float)
    d = p1 - p0
    L = float(np.hypot(*d))
    if L < 1e-9:
        return None
    u = d / L
    n = np.array([-u[1], u[0]])
    wide = max(2.0 * doc.get("BoldWidth", 1.45), 2.4 * lw)
    if display in ("WedgeEnd", "WedgedHashEnd"):     # point at the far end
        p0, p1, u = p1, p0, -u
        n = -n
    if display in ("WedgeBegin", "WedgeEnd"):
        half = 0.5 * wide
        return ("poly", [tuple(p0 + 0.5 * lw * n), tuple(p1 + half * n),
                         tuple(p1 - half * n), tuple(p0 - 0.5 * lw * n)])
    if display in ("WedgedHashBegin", "WedgedHashEnd", "Hash"):
        k = rungs or max(int(L / hash_step(doc)), 1)
        rungs = []
        for i in range(k + 1):
            f = i / k
            half = 0.5 * (lw + f * (wide - lw))
            c = p0 + f * L * u
            rungs.append((tuple(c + half * n), tuple(c - half * n)))
        return ("rungs", rungs)
    if display == "Bold":
        return ("line", [(tuple(p0), tuple(p1))], max(wide * 0.6, 2 * lw))
    return None


def apply_stereo(sc, out, P, key="id"):
    """Replace plain strokes with wedge or hash artwork, in place.

    Shared by the still renderer and the animator: the two have disagreed
    about drawing rules three times already, so there is one copy.
    """
    for i, d in enumerate(out):
        if d["kind"] != "line":
            continue
        bid = d.get(key)
        if key != "id" and bid:
            bid = bid[1:]
        bd = sc.bonds.get(bid)
        if not bd or bd.get("display", "Solid") not in WEDGE_DISPLAYS:
            continue
        if bd["order"] != 1 or bd["b"] not in P or bd["e"] not in P:
            continue
        pts = [q for seg in d["pts"] for q in seg]
        if not pts:
            continue
        pts = np.asarray(pts, float)
        begin = np.asarray(P[bd["b"]], float)
        # keep the drawn span (already trimmed at labels), oriented begin->end
        j0 = int(np.argmin(np.hypot(*(pts - begin).T)))
        j1 = int(np.argmax(np.hypot(*(pts - pts[j0]).T)))
        shape = stereo_shape(bd["display"], pts[j0], pts[j1], sc.doc,
                             d["width"], rungs=hash_count(sc, bid))
        if shape is None:
            continue
        if shape[0] == "poly":
            out[i] = dict(d, kind="poly", pts=shape[1])
        elif shape[0] == "rungs":
            out[i] = dict(d, pts=shape[1])
        else:
            out[i] = dict(d, pts=shape[1], width=shape[2])


def ring_through(sc, bid, nbr):
    """Smallest ring containing this bond, as node keys, or None.

    Memoised on the scene: topology does not change between frames, and
    this is consulted for every double bond of every frame.
    """
    memo = getattr(sc, "_ring_memo", None)
    if memo is None:
        memo = sc._ring_memo = {}
    if bid in memo:
        return memo[bid]
    b = sc.bonds[bid]
    u, v = b["b"], b["e"]
    prev, queue, found = {u: None}, deque([u]), None
    while queue and found is None:
        x = queue.popleft()
        for y in nbr.get(x, ()):
            if x == u and y == v:          # may not use the bond itself
                continue
            if y in prev:
                continue
            prev[y] = x
            if y == v:
                path, cur = [], v
                while cur is not None:
                    path.append(cur)
                    cur = prev[cur]
                found = path
                break
            queue.append(y)
    memo[bid] = found
    return found


def double_side(sc, bid, P, nbr):
    """Which side of a double bond carries the inner line: +1, -1, or 0.

    A ring double bond's second line goes INSIDE the ring - that is what
    ChemDraw draws, and it does not depend on what else is attached.  Only
    for an acyclic bond does the old heuristic apply: offset toward
    whichever side carries more substituents.

    Counting substituents alone gets a ring wrong whenever the ring bond
    has one exocyclic neighbour at each end, because then the ring
    neighbours and the substituents cancel and the tie-break decides - so
    the line lands outside the ring.  Pyridine drawn with a substituent
    either side of a ring double bond does exactly this.
    """
    b = sc.bonds[bid]
    p0, p1 = P[b["b"]], P[b["e"]]
    d = p1 - p0
    L = float(np.hypot(*d))
    if L < 1e-9:
        return 0.0
    n = np.array([-d[1], d[0]]) / L

    ring = ring_through(sc, bid, nbr)
    if ring:
        pts = [P[k] for k in ring if k in P]
        if len(pts) >= 3:
            s = float(np.dot(np.mean(pts, axis=0) - p0, n))
            if abs(s) > 1e-9:
                return 1.0 if s > 0 else -1.0

    if len(nbr.get(b["b"], ())) < 2 or len(nbr.get(b["e"], ())) < 2:
        return 0.0
    s = 0.0
    for nid, other in ((b["b"], b["e"]), (b["e"], b["b"])):
        for m in nbr[nid]:
            if m != other:
                s += np.sign(np.dot(P[m] - P[nid], n))
    return 1.0 if s >= 0 else -1.0


def _ink_centre(txt, size):
    """Where the drawn ink of a sign sits relative to its text origin.

    A "+" floats on the maths axis, well above the baseline, and its ink
    is not centred on the advance width either.  Centring the SIGN in its
    ring means centring its ink, so both offsets are measured.
    """
    key = ("centre", txt, round(float(size), 3))
    if key not in _METRICS:
        from matplotlib.textpath import TextPath
        from matplotlib.font_manager import FontProperties
        e = TextPath((0, 0), txt, size=size,
                     prop=FontProperties(family=TEXT_FAMILY)).get_extents()
        _METRICS[key] = (0.5 * float(e.x0 + e.x1), 0.5 * float(e.y0 + e.y1))
    return _METRICS[key]


def charge_radius(nd, doc):
    """Radius of the circle around a charge sign, in points."""
    lab = nd.get("label")
    base = float(lab["size"] if lab else doc.get("LabelSize", 8) or 8)
    return 0.30 * base


def _bond_segments(sc):
    """Every bond as a drawn segment, with its half width."""
    memo = getattr(sc, "_bond_segs", None)
    if memo is not None:
        return memo
    segs = []
    for bd in sc.bonds.values():
        if bd["b"] not in sc.nodes or bd["e"] not in sc.nodes:
            continue
        p0 = np.asarray(sc.nodes[bd["b"]]["p"], float)
        p1 = np.asarray(sc.nodes[bd["e"]]["p"], float)
        w = bd.get("width") or sc.doc["LineWidth"]
        # a double bond's second line sits BondSpacing away, so allow for it
        if bd.get("order", 1) >= 2:
            w += 2.0 * sc.doc.get("BondSpacing", 0.0) * 0.01 \
                 * sc.doc.get("BondLength", 30.0)
        segs.append((p0, p1, 0.5 * float(w)))
    memo = sc._bond_segs = segs
    return segs


def _clear_of_bonds(sc, c, r):
    """Gap between a circle of radius `r` at `c` and the nearest bond."""
    best = 1e18
    for p0, p1, hw in _bond_segments(sc):
        v = p1 - p0
        L2 = float(v @ v)
        u = 0.0 if L2 < 1e-12 else float(np.clip(((c - p0) @ v) / L2, 0.0, 1.0))
        d = float(np.hypot(*(c - (p0 + u * v)))) - hw - r
        best = min(best, d)
    return best


def charge_box(lab):
    """The box a charge is placed against.

    For a STACKED label that is the glyph the bonds attach to, not the
    whole label: a sulfonium's plus belongs next to the S, not out beyond
    the Ar sitting above it.
    """
    if stacked_lines(lab["text"], lab["bbox"], lab["size"], lab["bold"],
                     lab["align"]):
        return attachment_box(lab)
    return lab["bbox"]


def charge_candidates(sc, nid):
    """The places a charge may sit, as absolute points.

    Around the label box if the atom has one, else around the atom: the
    four corners and the four sides.
    """
    nd = sc.nodes[nid]
    r = charge_radius(nd, sc.doc)
    lab = nd.get("label")
    if lab:
        bx = charge_box(lab)
        ox, oy = 0.5 * (bx[0] + bx[2]), 0.5 * (bx[1] + bx[3])
        hw, hh = 0.5 * (bx[2] - bx[0]) + r, 0.5 * (bx[3] - bx[1]) + r
    else:
        ox, oy = nd["p"]
        hw = hh = 1.2 * r
    return [(ox + hw, oy - hh), (ox - hw, oy - hh),
            (ox + hw, oy + hh), (ox - hw, oy + hh),
            (ox + hw + r, oy), (ox - hw - r, oy),
            (ox, oy - hh - r), (ox, oy + hh + r)]


def charge_offset(sc, nid):
    """Where this atom's charge sits, as a fixed offset from the atom.

    Decided ONCE per structure from its own drawn geometry and memoised.
    Choosing per frame makes the sign hop between directions as the atoms
    move; a fixed offset simply rides along with its atom.

    A circled charge must not touch the drawing: the candidate sites are
    scored on their clearance from every BOND as well as from
    neighbouring glyphs, and the winner is pushed further out along its
    own direction if even it would graze something.
    """
    memo = getattr(sc, "_charge_off", None)
    if memo is None:
        memo = sc._charge_off = {}
    if nid in memo:
        return memo[nid]
    nd = sc.nodes[nid]
    r = charge_radius(nd, sc.doc)
    lab = nd.get("label")
    px, py = nd["p"]
    if lab:
        bx = charge_box(lab)
        ox, oy = 0.5 * (bx[0] + bx[2]), 0.5 * (bx[1] + bx[3])
        hw, hh = 0.5 * (bx[2] - bx[0]) + r, 0.5 * (bx[3] - bx[1]) + r
    else:
        ox, oy = px, py
        hw = hh = 1.2 * r
    cands = charge_candidates(sc, nid)
    sites = [p for k, p in _glyph_sites(sc).items() if k != nid]
    flat = [q for ps in sites for q in ps]
    # a stacked label's OTHER lines are obstacles for its own charge: the
    # plus is placed against the S, so the Ar above it must be avoided
    # exactly like a neighbouring atom's glyphs
    if lab:
        lines = stacked_lines(lab["text"], lab["bbox"], lab["size"],
                              lab["bold"], lab["align"])
        keep = charge_box(lab)
        for line, lx, ly in (lines or []):
            w, rise, drop = _ink_box(line, lab["size"], lab["bold"])
            b = (lx, ly - rise, lx + w, ly + drop)
            if abs(0.5 * (b[1] + b[3]) - 0.5 * (keep[1] + keep[3])) < 0.5:
                continue                      # this is the attachment line
            for cx_ in (b[0], 0.5 * (b[0] + b[2]), b[2]):
                for cy_ in (b[1], 0.5 * (b[1] + b[3]), b[3]):
                    flat.append((cx_, cy_))
    pts = np.asarray(flat, float) if flat else None
    want = CHARGE_CLEARANCE + r

    def score(x, y):
        c = np.array([x, y], float)
        d_glyph = (float(np.min(np.hypot(pts[:, 0] - x, pts[:, 1] - y)))
                   if pts is not None else 1e18)
        return min(d_glyph - r, _clear_of_bonds(sc, c, r))

    best = max(cands, key=lambda c: score(*c))
    if score(*best) < CHARGE_CLEARANCE:
        # slide it outwards along its own direction until it is clear
        dirv = np.array([best[0] - ox, best[1] - oy], float)
        n = float(np.hypot(*dirv))
        if n > 1e-9:
            dirv /= n
            step, moved = 0.25, 0.0
            while moved < 4.0 * r and score(best[0], best[1]) < CHARGE_CLEARANCE:
                best = (best[0] + dirv[0] * step, best[1] + dirv[1] * step)
                moved += step
    memo[nid] = (best[0] - px, best[1] - py)
    return memo[nid]


def _glyph_sites(sc):
    """Per atom, the points a neighbouring charge should keep away from."""
    memo = getattr(sc, "_glyph_sites", None)
    if memo is not None:
        return memo
    memo = sc._glyph_sites = {}
    for nid, n in sc.nodes.items():
        pts = [tuple(n["p"])]
        lab = n.get("label")
        if lab:
            bx = lab["bbox"]
            for cx_ in (bx[0], 0.5 * (bx[0] + bx[2]), bx[2]):
                for cy_ in (bx[1], 0.5 * (bx[1] + bx[3]), bx[3]):
                    pts.append((cx_, cy_))
        memo[nid] = pts
    return memo


def charge_text(charge):
    """What ChemDraw writes for a formal charge: +, -, 2+, 2- ..."""
    c = int(charge or 0)
    if c == 0:
        return ""
    sign = "+" if c > 0 else "\u2212"          # a real minus, not a hyphen
    return sign if abs(c) == 1 else f"{abs(c)}{sign}"


def charge_glyph(sc, nid, dx=0.0, dy=0.0, rgb=None, z=None, alpha=1.0):
    """Text drawable for an atom's formal charge, or None.

    Drawn in ChemDraw's circled style: the sign centred in a thin ring.
    The position is a fixed offset from the atom (see `charge_offset`), so
    it rides along instead of hopping about between frames.  Bonds are not
    trimmed at a charge, so this is never registered as a trimming box.
    y grows downward here (`draw` flips it), so "up" is -y.
    """
    nd = sc.nodes[nid]
    txt = charge_text(nd.get("charge", 0))
    if not txt:
        return None
    r = charge_radius(nd, sc.doc)
    ox, oy = charge_offset(sc, nid)
    cx = nd["p"][0] + ox + dx
    cy = nd["p"][1] + oy + dy
    lab = nd.get("label")
    col = lab["color"] if lab else nd["color"]
    # The sign is centred in the ring both ways, on its INK - drawing it
    # from the text origin would hang it above and right of centre.  y
    # grows downward here, so the baseline goes below the middle.
    size = CHARGE_GLYPH * r
    mx, my = _ink_centre(txt, size)
    return dict(kind="text", text=txt, anchor=(cx - mx, cy + my),
                atom=(nd["p"][0] + dx, nd["p"][1] + dy),
                bbox=[cx - r, cy - r, cx + r, cy + r],
                just="Left", size=size, font="Arial", bold=False,
                color=rgb if rgb is not None else col,
                margin=0.0, z=z, alpha=alpha, charge=True,
                circle=(cx, cy, r))


_METRICS = {}


def _ascent_descent(size, bold):
    """How far a line of text reaches above and below its baseline."""
    key = (round(float(size), 3), bool(bold))
    if key not in _METRICS:
        from matplotlib.textpath import TextPath
        from matplotlib.font_manager import FontProperties
        fp = FontProperties(family=TEXT_FAMILY,
                            weight="bold" if bold else "normal")
        ext = TextPath((0, 0), "Ag", size=size, prop=fp).get_extents()
        _METRICS[key] = (float(ext.y1), float(-ext.y0))
    return _METRICS[key]


def _ink_box(t, size, bold):
    """(width, rise above baseline, drop below) of drawn text, in points."""
    key = ("ink", t, round(float(size), 3), bool(bold))
    if key not in _METRICS:
        from matplotlib.textpath import TextPath
        from matplotlib.font_manager import FontProperties
        fp = FontProperties(family=TEXT_FAMILY,
                            weight="bold" if bold else "normal")
        e = TextPath((0, 0), t, size=size, prop=fp).get_extents()
        _METRICS[key] = (float(e.x1 - e.x0), float(e.y1), float(-e.y0))
    return _METRICS[key]


def layout_left(anchor_x, just, text, size, bold):
    """Left edge of the box the canvas aligns text in.

    ChemDraw gives a label a justification and an anchor at one edge of
    its layout; the canvas honours both.  Expressing that as a single
    left edge makes the placement a POSITION rather than a position plus
    a discrete flag, so two drawings that justify the same label
    differently can be interpolated without the glyph jumping - and both
    ends still land exactly where the drawing puts them.
    """
    adv = layout_width(text, size, bold)
    if just == "Center":
        return anchor_x - 0.5 * adv
    if just == "Right":
        return anchor_x - adv
    return anchor_x


def layout_width(text, size, bold):
    """Advance width of a string, as the canvas lays it out."""
    key = ("adv", text, round(float(size), 3), bool(bold))
    if key not in _METRICS:
        from matplotlib.textpath import TextToPath
        from matplotlib.font_manager import FontProperties
        fp = FontProperties(family=TEXT_FAMILY,
                            weight="bold" if bold else "normal")
        w, _, _ = TextToPath().get_text_width_height_descent(text, fp, False)
        _METRICS[key] = float(w)
    return _METRICS[key]


def _text_width(t, size, bold):
    """How wide a piece of text is drawn, in points."""
    key = (t, round(float(size), 3), bool(bold))
    if key not in _METRICS:
        from matplotlib.textpath import TextPath
        from matplotlib.font_manager import FontProperties
        fp = FontProperties(family=TEXT_FAMILY,
                            weight="bold" if bold else "normal")
        ext = TextPath((0, 0), t, size=size, prop=fp).get_extents()
        _METRICS[key] = float(ext.x1 - ext.x0)
    return _METRICS[key]



def glyph_centres(lab, p):
    """Where each glyph of a label is drawn, as offsets from its atom.

    A flippable label is drawn as two glyphs while it turns and as one
    string at rest, so the two renderings must agree exactly or the H
    steps sideways the instant the slide begins.  Half the label's width
    is close but not equal to where the H actually sits: the glyphs are
    laid out along the string, so measure them.
    """
    text = lab["text"]
    if lab.get("align") == "Right":
        text = reverse_label(text)
    toks = _TOKEN.findall(text)
    total = _ink_box(text, lab["size"], lab["bold"])[0]
    centre = 0.5 * (lab["bbox"][0] + lab["bbox"][2]) - p[0]
    left = centre - 0.5 * total
    # Prefix widths do not add up to the whole: each glyph carries side
    # bearings the string absorbs.  The two glyphs of a flippable label
    # sit against the string's edges, so measure from those.
    out = {}
    w_first = _ink_box(toks[0], lab["size"], lab["bold"])[0]
    w_last = _ink_box(toks[-1], lab["size"], lab["bold"])[0]
    out[toks[0]] = left + 0.5 * w_first
    out[toks[-1]] = left + total - 0.5 * w_last
    return out



def label_parts(lab, p):
    """Split a label into the glyph its bonds meet and the rest.

    ChemDraw centres a label on that glyph, so it is simply the one drawn
    nearest the atom - a rule that held for all 59 multi-glyph labels in
    the files this was built against, including "MeO", where the stored
    text puts it last.

    Returns (attachment, its centre offset, remainder, its centre
    offset), the offsets measured from the atom.  A label of one glyph
    has an empty remainder.
    """
    text = lab["text"]
    if lab.get("align") == "Right":
        text = reverse_label(text)
    toks = _TOKEN.findall(text)
    g = glyph_centres(lab, p)
    if not toks or not g:
        return text, 0.0, "", 0.0
    att = min(g.items(), key=lambda kv: abs(kv[1]))[0]
    total = _ink_box(text, lab["size"], lab["bold"])[0]
    left = 0.5 * (lab["bbox"][0] + lab["bbox"][2]) - p[0] - 0.5 * total
    w_att = _ink_box(att, lab["size"], lab["bold"])[0]
    # Measure the remainder from the string's FAR edge, never by adding up
    # glyph widths: each glyph carries side bearings the string absorbs,
    # and half of one is enough to make the H twitch as the split takes
    # over from the one-string rendering.
    if toks[0] == att:
        rest = "".join(toks[1:])
        w_rest = _ink_box(rest, lab["size"], lab["bold"])[0] if rest else 0.0
        rest_c = left + total - 0.5 * w_rest
    else:
        rest = "".join(toks[:-1])
        w_rest = _ink_box(rest, lab["size"], lab["bold"])[0] if rest else 0.0
        rest_c = left + 0.5 * w_rest
    return att, g[att], rest, rest_c


def stacked_lines(text, bbox, size, bold, align, px=None):
    """Where each line of a vertically stacked label goes, or None.

    ChemDraw's LabelAlignment "Above" and "Below" put the attachment atom
    on its own line and the rest of the group on another, so "SAr" reads
    as Ar over S.  The stored box gives it away: it is as wide as the
    WIDER LINE rather than the whole string, and two lines tall - and
    drawing the string horizontally instead spills the glyphs outside
    that box, which is where the bonds are trimmed and the charge is
    placed.  Lines sit flush with the box's left edge, which reproduces
    the box exactly; the upper baseline one ascent below its top, the
    lower one a descent above its bottom.  Returns [(text, x, baseline)].
    """
    if align not in ("Above", "Below"):
        return None
    toks = _TOKEN.findall(text)
    if len(toks) < 2:
        return None
    head, rest = toks[0], "".join(toks[1:])
    asc, desc = _ascent_descent(size, bold)
    # The alignment flag alone does not settle it: ChemDraw writes "OH"
    # above its carbon on ONE line too.  The stored box does settle it -
    # a stacked label's box is only as wide as its wider line and is two
    # lines tall - so measure before splitting the text.
    whole = _ink_box(text, size, bold)[0]
    if (whole <= (bbox[2] - bbox[0]) * 1.05
            and (bbox[3] - bbox[1]) < 1.5 * (asc + desc)):
        return None
    top, bottom = bbox[1] + asc, bbox[3] - desc
    # Both lines share a left edge - ChemDraw's own, which is why the
    # stored box is exactly as wide as the wider line.
    x = bbox[0]
    if align == "Above":                  # the attachment atom underneath
        return [(rest, x, top), (head, x, bottom)]
    return [(head, x, top), (rest, x, bottom)]


def attachment_box(lab, px=None):
    """The box a bond should be cut at where it meets this label.

    A bond meets the ATTACHMENT atom, which for a stacked label is one
    line of it.  Cutting at the whole label's box stops the two bonds at
    different distances from the atom, because that box is wide enough
    for whatever is stacked above.  Cutting at the attachment glyph
    alone, centred on the atom, leaves the ends symmetric about it.
    """
    lines = stacked_lines(lab["text"], lab["bbox"], lab["size"], lab["bold"],
                          lab["align"], px)
    if not lines:
        return lab["bbox"]
    txt, lx, base = lines[1] if lab["align"] == "Above" else lines[0]
    # the glyph's OWN ink where it is actually drawn, not the font's
    # generic ascent and descent: an "S" has no descender, and a box that
    # allowed for one would cut a bond arriving from below further back
    # than one arriving from the side
    w, above, below = _ink_box(txt, lab["size"], lab["bold"])
    return [lx, base - above, lx + w, base + below]


def reverse_label(txt):
    """A right-aligned atom label as ChemDraw draws it.

    The group is reordered so the atom bonded to the chain sits next to
    the bond, but the reordering is by TOKEN, not by letter: "OMe" becomes
    "MeO", not "eMO", and a single-token label like "Me" is unchanged.
    Reversing characters happens to give the right answer for "OH" -> "HO",
    which is why getting this wrong can go unnoticed.
    """
    toks = _TOKEN.findall(txt)
    return "".join(reversed(toks)) if len(toks) > 1 else txt


def build_strokes(sc, positions=None, node_over=None):
    """Turn the scene into an ordered list of drawables.

    positions : optional {node_id: (x, y)} override (used by the animator)
    Returns list of dicts sorted by z:
      {kind:'line', pts:[(p0,p1),...], color, width, z}
      {kind:'text', ...}
    """
    P = {k: np.asarray(positions[k] if positions and k in positions
                       else v["p"], float) for k, v in sc.nodes.items()}
    lw = sc.doc["LineWidth"]
    margin = sc.doc["MarginWidth"]
    sep = sc.doc["BondSpacing"] / 100.0 * sc.doc["BondLength"]

    # adjacency for the double-bond side heuristic
    nbr = {k: set() for k in sc.nodes}
    for bd in sc.bonds.values():
        if bd["b"] in nbr and bd["e"] in nbr:
            nbr[bd["b"]].add(bd["e"]); nbr[bd["e"]].add(bd["b"])

    raw = []          # (bond_id, p0, p1, width, color, z, node_pair)
    for bid, bd in sc.bonds.items():
        if bd["b"] not in P or bd["e"] not in P:
            continue
        if bd.get("alpha", 1.0) <= 0.01:
            continue                       # fully faded out
        p0, p1 = P[bd["b"]].copy(), P[bd["e"]].copy()
        for end, nid in ((0, bd["b"]), (1, bd["e"])):
            lab = sc.nodes[nid]["label"]
            if lab:
                box = attachment_box(lab)
                if positions and nid in positions:      # translate the box
                    dx = P[nid][0] - sc.nodes[nid]["p"][0]
                    dy = P[nid][1] - sc.nodes[nid]["p"][1]
                    box = [box[0] + dx, box[1] + dy, box[2] + dx, box[3] + dy]
                r = _clip_to_box(p0, p1, box, margin)
                if r is None:
                    p0 = p1 = None
                    break
                p0, p1 = r
        if p0 is None or np.hypot(*(p1 - p0)) < 1e-6:
            continue

        col = sc.rgb(bd["color"])
        pair = (bd["b"], bd["e"])
        if bd["order"] == 2:
            d = p1 - p0
            n = np.array([-d[1], d[0]]) / np.hypot(*d)
            o1 = len(nbr[bd["b"]]) > 1
            o2 = len(nbr[bd["e"]]) > 1
            if o1 and o2:
                # inside the ring for a ring bond, otherwise toward the
                # side carrying more substituents (shared with the animator)
                sgn = double_side(sc, bid, P, nbr) or 1.0
                q0, q1 = p0 + sgn * sep * n, p1 + sgn * sep * n
                a, b = inner_span(
                    q0, q1,
                    p0, [P[m] for m in nbr[bd["b"]] if m != bd["e"]],
                    p1, [P[m] for m in nbr[bd["e"]] if m != bd["b"]],
                    lw + margin)
                raw.append((bid, p0, p1, lw, col, bd["z"], pair))
                raw.append((bid, q0 + a * (q1 - q0), q0 + b * (q1 - q0),
                            lw, col, bd["z"], pair))
            else:
                # Symmetric pair, used where one end is terminal (C=O).
                # Both lines run the FULL length: trimming them back at the
                # substituted end leaves the double bond not reaching its
                # own carbon, which reads as a broken bond.  The inset in
                # the offset branch above exists to keep an inner line off
                # a NEIGHBOURING bond; here the line meets its own atom,
                # which is simply how bonds join.
                for sgn in (+1, -1):
                    raw.append((bid, p0 + sgn * sep / 2 * n,
                                p1 + sgn * sep / 2 * n, lw, col, bd["z"],
                                pair))
        elif bd["order"] >= 3:
            # A triple bond is the centre line plus one either side, at the
            # same spacing a double bond uses between its two.  All three
            # run the full length: a triple bond is linear and reaches its
            # own atoms.  Without this an alkyne, a nitrile - or an
            # equivalency sign drawn as one - renders as a single line.
            d = p1 - p0
            n = np.array([-d[1], d[0]]) / np.hypot(*d)
            for sgn in (0, +1, -1):
                raw.append((bid, p0 + sgn * sep * n, p1 + sgn * sep * n,
                            lw, col, bd["z"], pair))
        else:
            raw.append((bid, p0, p1, lw, col, bd["z"], pair))

    # crossings: the stroke with the LOWER z gets a gap
    cuts = {i: [] for i in range(len(raw))}
    for i in range(len(raw)):
        for j in range(i + 1, len(raw)):
            bi, p0, p1, wi, _, zi, pri = raw[i]
            bj, q0, q1, wj, _, zj, prj = raw[j]
            if bi == bj or set(pri) & set(prj):
                continue
            # The front stroke is painted with a white band of half-width
            # (w_front/2 + margin).  The back stroke disappears where its
            # CENTRELINE falls inside that band - its own width does not
            # lengthen the gap.  Round caps then regrow w_back/2 at each new
            # end, so widen the cut by that much to leave the intended gap.
            back, front = (i, j) if zi < zj else (j, i)
            bp0, bp1, bw = raw[back][1], raw[back][2], raw[back][3]
            fp0, fp1, fw = raw[front][1], raw[front][2], raw[front][3]
            if not crosses_transversely(bp0, bp1, fp0, fp1):
                continue
            # Only an opaque stroke occludes.  A bond part-way through a
            # cross-dissolve would otherwise punch a gap in whatever it
            # happens to overlap while itself being barely visible.
            if sc.bonds[raw[front][0]].get("alpha", 1.0) <= 0.5:
                continue
            sp = _overlap_span(bp0, bp1, fp0, fp1,
                               fw / 2 + margin * GAP_SCALE)
            if sp is not None:
                cuts[back].append((sp[0] - bw / 2, sp[1] + bw / 2))

    out = []
    for i, (bid, p0, p1, w, col, z, pair) in enumerate(raw):
        segs = punch_surviving(p0, p1, cuts[i], w,
                               (bool(sc.nodes[pair[0]]["label"]),
                                bool(sc.nodes[pair[1]]["label"])),
                               max_gap=GAP_MAX * (lw + 2 * margin))
        if segs:
            a0 = sc.bonds[bid].get("alpha", 1.0)
            stereo = sc.bonds[bid].get("display", "Solid") != "Solid"
            firm = [(a, b) for a, b, wt in segs if wt >= 0.999 or stereo]
            if firm:
                out.append(dict(kind="line", id=bid, pts=firm, color=col,
                                width=w, z=z, alpha=a0))
            if not stereo:
                for a, b, wt in segs:
                    if wt < 0.999:
                        out.append(dict(kind="line", id=bid, pts=[(a, b)],
                                        color=col, width=w, z=z,
                                        alpha=a0 * wt))
    apply_stereo(sc, out, P)

    for nid, nd in sc.nodes.items():
        lab = nd["label"]
        if not lab:
            continue
        dx = dy = 0.0
        if positions and nid in positions:
            dx = P[nid][0] - nd["p"][0]; dy = P[nid][1] - nd["p"][1]
        z = node_over.get(nid, nd["z"]) if node_over else nd["z"]
        b = lab["bbox"]
        if lab.get("parts"):
            # The label is drawn as separate glyphs, each with its own
            # position and depth: that is what lets one glyph stay put
            # while another travels past behind it.  The label's own box
            # is still what bonds are trimmed against.
            for pt in lab["parts"]:
                out.append(dict(
                    kind="text", id=nid, text=pt["text"],
                    anchor=(pt["anchor"][0] + dx, pt["anchor"][1] + dy),
                    bbox=[b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy],
                    just=pt.get("just", "Center"), size=lab["size"],
                    font=lab["font"], bold=lab["bold"],
                    color=sc.rgb(lab["color"]), margin=margin,
                    alpha=pt.get("alpha", 1.0),
                    clearance=pt.get("clearance", LABEL_CLEARANCE),
                    z=z + pt.get("dz", 0.0)))
            continue
        if lab.get("alpha", 1.0) <= 0.01:
            continue
        lines = stacked_lines(lab["text"], b, lab["size"], lab["bold"],
                              lab["align"])
        if lines:
            for txt, lx, ly in lines:
                out.append(dict(
                    kind="text", id=nid, text=txt,
                    anchor=(lx + dx, ly + dy),
                    bbox=[b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy],
                    just="Left", size=lab["size"], font=lab["font"],
                    bold=lab["bold"], color=sc.rgb(lab["color"]),
                    margin=margin, z=z, alpha=lab.get("alpha", 1.0)))
            continue
        txt = lab["text"]
        if lab["align"] == "Right":
            txt = reverse_label(txt)
        extra = {"blend": lab["blend"]} if lab.get("blend") else {}
        out.append(dict(kind="text", id=nid, text=txt, **extra,
                        anchor=(lab["anchor"][0] + dx, lab["anchor"][1] + dy),
                        bbox=[b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy],
                        just=lab["just"], size=lab["size"], font=lab["font"],
                        bold=lab["bold"], color=sc.rgb(lab["color"]),
                        margin=margin, z=z,
                        alpha=lab.get("alpha", 1.0)))

    for nid, nd in sc.nodes.items():
        dx = dy = 0.0
        if positions and nid in positions:
            dx = P[nid][0] - nd["p"][0]; dy = P[nid][1] - nd["p"][1]
        z = node_over.get(nid, nd["z"]) if node_over else nd["z"]
        g = charge_glyph(sc, nid, dx, dy,
                         rgb=sc.rgb(nd["label"]["color"] if nd["label"]
                                    else nd["color"]),
                         z=z + CHARGE_Z)
        if g is not None:
            g["id"] = nid
            out.append(g)

    out.sort(key=lambda d: d["z"])
    return out


# -------------------------------------------------------------- rendering

def draw(ax, drawables, scale=1.0):
    """Paint drawables (already z-sorted) into `ax`.
    Data units are ChemDraw points * scale, y flipped."""
    for d in drawables:
        if d["kind"] == "poly":                 # a solid stereo wedge
            ax.add_patch(matplotlib.patches.Polygon(
                [(q[0] * scale, -q[1] * scale) for q in d["pts"]],
                closed=True, facecolor=d["color"], edgecolor=d["color"],
                linewidth=0.0, zorder=d["z"], alpha=d.get("alpha", 1.0)))
        elif d["kind"] == "line":
            for p0, p1 in d["pts"]:
                ax.plot([p0[0] * scale, p1[0] * scale],
                        [-p0[1] * scale, -p1[1] * scale],
                        color=d["color"], lw=d["width"] * scale,
                        solid_capstyle="round", zorder=d["z"],
                        alpha=d.get("alpha", 1.0))
        else:
            # Bonds ATTACHED to a label are already trimmed at bbox+margin,
            # so the drawn halo does no work for them.  Its only job is to
            # keep unrelated bonds and neighbouring labels off the
            # letterforms, which needs a thin clearance -- using the full
            # MarginWidth here carves visible bites out of both.
            a = d.get("alpha", 1.0)
            ha = {"Left": "left", "Right": "right",
                  "Center": "center"}.get(d["just"], "left")
            circ = d.get("circle")
            if circ is not None:
                ccx, ccy, cr = circ
                # White fill first so the ring is legible over a bond, and a
                # white MARGIN outside it so a bond sweeping past is held off
                # the ring rather than abutting it.  The sign never moves to
                # make room: the drawing's placement is what a reader expects.
                ax.add_patch(matplotlib.patches.Circle(
                    (ccx * scale, -ccy * scale), cr * scale,
                    facecolor="white", edgecolor=d["color"],
                    linewidth=0.5 * scale, zorder=d["z"], alpha=a,
                    path_effects=[pe.withStroke(
                        linewidth=(0.5 + 2 * CHARGE_CLEARANCE) * scale,
                        foreground="white", alpha=a)]))
            ax.text(d["anchor"][0] * scale, -d["anchor"][1] * scale, d["text"],
                    ha=ha, va="center" if circ is not None else "baseline",
                    color=d["color"],
                    fontsize=d["size"] * scale, fontfamily="Arial",
                    fontweight="bold" if d["bold"] else "normal",
                    zorder=d["z"], alpha=a,
                    path_effects=[pe.withStroke(
                        linewidth=2 * d.get("clearance", LABEL_CLEARANCE) * scale,
                        foreground="white", alpha=a)])


def audit_crossings(sc):
    """Compare the crossings this renderer punches against the CrossingBonds
    lists ChemDraw stored.  Returns (found, declared) as sets of frozensets
    of bond ids."""
    lw, margin = sc.doc["LineWidth"], sc.doc["MarginWidth"]
    segs = []
    for bid, bd in sc.bonds.items():
        if bd["b"] not in sc.nodes or bd["e"] not in sc.nodes:
            continue
        p0 = np.asarray(sc.nodes[bd["b"]]["p"], float)
        p1 = np.asarray(sc.nodes[bd["e"]]["p"], float)
        for nid in (bd["b"], bd["e"]):
            lab = sc.nodes[nid]["label"]
            if lab:
                r = _clip_to_box(p0, p1, lab["bbox"], margin)
                if r is None:
                    p0 = None
                    break
                p0, p1 = r
        if p0 is not None:
            segs.append((bid, p0, p1, (bd["b"], bd["e"])))

    found = set()
    for i in range(len(segs)):
        for j in range(i + 1, len(segs)):
            bi, p0, p1, pri = segs[i]
            bj, q0, q1, prj = segs[j]
            if set(pri) & set(prj):
                continue
            if _seg_cross(p0, p1, q0, q1) is not None:
                found.add(frozenset((bi, bj)))

    declared = set()
    for bid, bd in sc.bonds.items():
        for other in bd["crossing"]:
            if other in sc.bonds:
                declared.add(frozenset((bid, other)))
    return found, declared


def _hex(c):
    return "#%02x%02x%02x" % tuple(int(round(255 * v)) for v in c[:3])


def to_svg(drawables):
    """Serialise z-sorted drawables as SVG elements.  SVG's y axis already
    points down, so ChemDraw coordinates are used unchanged."""
    out = []
    for d in drawables:
        a = d.get("alpha", 1.0)
        op = "" if a >= 0.999 else f' opacity="{a:.3f}"'
        if d["kind"] == "poly":
            tag = f' data-b="{d["id"]}"' if d.get("id") else ""
            pts = " ".join(f"{q[0]:.2f},{q[1]:.2f}" for q in d["pts"])
            out.append(f'<polygon{tag} points="{pts}"'
                       f' fill="{_hex(d["color"])}" stroke="none"{op}/>')
        elif d["kind"] == "line":
            tag = f' data-b="{d["id"]}"' if d.get("id") else ""
            for p0, p1 in d["pts"]:
                out.append(
                    f'<path{tag} d="M{p0[0]:.2f},{p0[1]:.2f} L{p1[0]:.2f},{p1[1]:.2f}"'
                    f' stroke="{_hex(d["color"])}" stroke-width="{d["width"]:.2f}"'
                    f' stroke-linecap="round" fill="none"{op}/>')
        else:
            x0, y0, x1, y1 = d["bbox"]
            m = d["margin"]
            anc = {"Left": "start", "Right": "end",
                   "Center": "middle"}.get(d["just"], "start")
            esc = (d["text"].replace("&", "&amp;")
                   .replace("<", "&lt;").replace(">", "&gt;"))
            out.append(
                f'<text x="{d["anchor"][0]:.2f}" y="{d["anchor"][1]:.2f}"'
                f' font-family="Arial, Helvetica, sans-serif"'
                f' font-size="{d["size"]:.2f}"'
                f' font-weight="{"bold" if d["bold"] else "normal"}"'
                f' text-anchor="{anc}" fill="{_hex(d["color"])}"'
                f' stroke="#ffffff" stroke-width="{2*LABEL_CLEARANCE:.2f}"'
                f' stroke-linejoin="round" paint-order="stroke fill"{op}'
                f'>{esc}</text>')
    return "\n".join(out)


def figure_for(sc, scale=6.0, pad=6.0, dpi=200):
    import matplotlib.pyplot as plt
    x0, y0, x1, y1 = sc.extent()
    w = (x1 - x0 + 2 * pad) * scale
    h = (y1 - y0 + 2 * pad) * scale
    fig = plt.figure(figsize=(w / 72, h / 72), dpi=dpi)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim((x0 - pad) * scale, (x1 + pad) * scale)
    ax.set_ylim(-(y1 + pad) * scale, -(y0 - pad) * scale)
    ax.set_aspect("equal")
    ax.axis("off")
    fig.patch.set_facecolor("white")
    return fig, ax
