@echo off
REM Double-click this file to start cdxmorph.
REM The first run sets things up and needs internet; later runs start at once.
cd /d "%~dp0"

set PY=
for %%C in (py python) do (
  if not defined PY (
    %%C -c "import sys; raise SystemExit(0 if sys.version_info[:2]>=(3,9) else 1)" >nul 2>&1
    if not errorlevel 1 set PY=%%C
  )
)

if not defined PY (
  echo.
  echo -------------------------------------------------------------
  echo  cdxmorph needs Python ^(version 3.9 or newer^), which this PC
  echo  does not have yet.
  echo.
  echo  I am opening the download page in your browser. Install
  echo  Python, TICK THE BOX that says "Add Python to PATH", then
  echo  double-click this file again.
  echo -------------------------------------------------------------
  echo.
  start "" "https://www.python.org/downloads/windows/"
  pause
  exit /b 1
)

set WHEEL=
for %%W in (cdxmorph-*.whl) do set "WHEEL=%%~fW"

if not defined WHEEL (
  echo.
  echo  The program file is missing from this folder. Unzip the whole
  echo  folder again, keeping all the files together.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\cdxmorph.exe" (
  echo Setting up cdxmorph. This happens once and takes a few minutes.
  echo You need to be online for this step.
  echo.
  %PY% -m venv .venv
  if errorlevel 1 (
    echo.
    echo Could not create the private folder that cdxmorph installs into.
    echo If this PC is managed by your institution, its security settings
    echo may be blocking it; ask your IT contact.
    pause
    exit /b 1
  )
  .venv\Scripts\python.exe -m pip install --upgrade pip >nul 2>&1
  .venv\Scripts\python.exe -m pip install "%WHEEL%[web,mp4]"
  if errorlevel 1 (
    rmdir /s /q .venv
    echo.
    echo The setup step could not download what it needs. Check that you
    echo are online and try again. An institutional firewall may be
    echo blocking the download.
    pause
    exit /b 1
  )
  echo.
  echo Setup finished.
)

echo.
echo Starting cdxmorph. Your browser will open in a moment.
echo Leave THIS window open while you use it; close it to stop.
echo.
.venv\Scripts\cdxmorph.exe serve --open --port 0
pause
