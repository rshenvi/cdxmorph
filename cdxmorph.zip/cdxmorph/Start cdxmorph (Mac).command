#!/bin/bash
# Double-click this file to start cdxmorph.
# The first run sets things up and needs internet; later runs start at once.
cd "$(dirname "$0")" || exit 1

say_and_stop () {            # show the message, keep the window readable
  echo ""
  echo "-------------------------------------------------------------"
  echo "$1"
  echo "-------------------------------------------------------------"
  echo ""
  read -r -p "Press Return to close this window. " _
  exit 1
}

# --- find a usable Python -----------------------------------------------
PY=""
for cand in python3 python3.13 python3.12 python3.11 python3.10 python3.9; do
  if command -v "$cand" >/dev/null 2>&1 &&
     "$cand" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] >= (3, 9) else 1)' 2>/dev/null
  then PY="$cand"; break; fi
done
if [ -z "$PY" ]; then
  open "https://www.python.org/downloads/macos/" 2>/dev/null
  say_and_stop "cdxmorph needs Python (version 3.9 or newer), which this Mac
does not have yet.

I have opened the download page in your browser. Install Python,
then double-click this file again. Nothing else is needed."
fi

# --- first run: build a private copy of everything it needs -------------
if [ ! -x ".venv/bin/cdxmorph" ]; then
  echo "Setting up cdxmorph. This happens once and takes a few minutes."
  echo "You need to be online for this step."
  echo ""
  "$PY" -m venv .venv || say_and_stop "Could not create the private folder
that cdxmorph installs into. If this Mac is managed by your institution,
its security settings may be blocking it; ask your IT contact about
running Python programs from your home folder."
  ./.venv/bin/python -m pip install --upgrade pip >/dev/null 2>&1
  # resolve the wheel first: [web,mp4] in a glob is a character class to the
  # shell, so the pattern would match nothing and pip would see a literal *
  WHEEL=$(ls ./cdxmorph-*.whl 2>/dev/null | head -1)
  if [ -z "$WHEEL" ]; then
    rm -rf .venv
    say_and_stop "The program file is missing from this folder.
Unzip the whole folder again, keeping all the files together."
  fi
  if ! ./.venv/bin/python -m pip install "${WHEEL}[web,mp4]"; then
    rm -rf .venv
    say_and_stop "The setup step could not download what it needs.
Check that you are online and try again. If you are behind an
institutional firewall, it may be blocking the download."
  fi
  echo ""
  echo "Setup finished."
fi

# --- run -----------------------------------------------------------------
echo ""
echo "Starting cdxmorph. Your browser will open in a moment."
echo "Leave THIS window open while you use it; close it to stop."
echo ""
./.venv/bin/cdxmorph serve --open --port 0
