"""The interface the in-browser build calls: bytes in, bytes out.

A browser tab has no command line and no server, so this module is the
whole boundary between JavaScript and the program.  Everything here
drives the SAME entry point the desktop build uses, so an animation made
in a browser is the one `cdxmorph render` would make: the frame
scheduling, the pairing rules and the occlusion rules are not
reimplemented, and cannot drift from the desktop version.

Two desktop features are unavailable in a browser and are refused rather
than faked: MP4 output, whose encoder is not compiled for WebAssembly,
and rendering across processes, which a tab cannot do.
"""

import contextlib
import io
import json
import os
import sys

from . import cli

WORK = "/tmp/cdxmorph"


def _put(name, data):
    """Write uploaded bytes into the virtual filesystem, return the path."""
    os.makedirs(WORK, exist_ok=True)
    safe = os.path.basename(str(name)) or "input.cdxml"
    path = os.path.join(WORK, safe)
    with open(path, "wb") as fh:
        fh.write(bytes(data))
    return path


def _clean(*paths):
    for p in paths:
        try:
            os.remove(p)
        except OSError:
            pass


def _run(argv):
    """Run one command and return its JSON report.

    The commands print a report to stdout; a browser has no stdout worth
    reading, so it is captured and parsed here.  A failure raises with
    whatever the command said, which the page shows verbatim.
    """
    out, err = io.StringIO(), io.StringIO()
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = cli.main([str(a) for a in argv])
    except SystemExit as exc:                      # argparse or a refusal
        raise RuntimeError(err.getvalue().strip()
                           or f"command failed ({exc.code})") from None
    except Exception as exc:
        raise RuntimeError(f"{type(exc).__name__}: {exc}") from None
    if code:
        raise RuntimeError(err.getvalue().strip() or f"command failed ({code})")
    text = out.getvalue().strip()
    if not text:
        return {}
    starts = [i for i in (text.find("{"), text.find("[")) if i >= 0]
    try:
        return json.loads(text[min(starts):]) if starts else {"output": text}
    except ValueError:
        return {"output": text}


def _config(cfg):
    """A config dict written where the commands can read it, or None."""
    if not cfg:
        return None
    path = os.path.join(WORK, "config.json")
    os.makedirs(WORK, exist_ok=True)
    with open(path, "w") as fh:
        json.dump(cfg, fh)
    return path


def version():
    from . import __version__
    return __version__


def describe(name, data, config=None):
    """What this file holds: its stages, and whether it can be turned."""
    path = _put(name, data)
    rep = _run(["check", path] + (["-c", _config(config)] if config else []))
    from . import rotate as rot, scene as cs
    try:
        turns = len(rot.guide_stages(cs.parse_sequence(path)))
    except Exception:
        turns = 0
    rep["turns"] = turns
    rep["file"] = os.path.basename(path)
    return rep


def animate(name, data, opts=None):
    """Render an animation; returns the report plus the file's bytes.

    `opts` keys: mode ("morph" or "turn"), seconds, fps, width, pause,
    bounce, fmt ("gif" or "png"), config (a mapping/style dict).
    """
    opts = dict(opts or {})
    fmt = str(opts.get("fmt", "gif")).lower()
    if fmt in ("mp4", "m4v"):
        raise RuntimeError(
            "MP4 needs an encoder that is not available in a browser; "
            "render a GIF here, or use the download for MP4")
    if fmt not in ("gif", "png"):
        raise RuntimeError(f"unknown format {fmt!r}; use gif or png")
    path = _put(name, data)
    out = os.path.join(WORK, "out." + ("gif" if fmt == "gif" else "png"))
    _clean(out)
    cfg = _config(opts.get("config"))
    seconds = float(opts.get("seconds", 6.0))
    argv = ([("rotate" if opts.get("mode") == "turn" else "render"), path,
             "-o", out, "--width", int(opts.get("width", 900)),
             "--pause", float(opts.get("pause", 0.3))]
            + (["-c", cfg] if cfg else []))
    if opts.get("mode") == "turn":
        argv += ["--oneway", seconds]
        if not opts.get("bounce", True):
            argv += ["--once"]
    else:
        argv += ["--duration", seconds, "--fps", float(opts.get("fps", 20))]
        if opts.get("bounce"):
            argv += ["--bounce"]
    rep = _run(argv)
    if fmt == "png":
        # a numbered sequence: hand back a zip of the frames
        import glob
        import zipfile
        frames = sorted(glob.glob(os.path.splitext(out)[0] + "_*.png"))
        zpath = os.path.join(WORK, "frames.zip")
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in frames:
                zf.write(f, os.path.basename(f))
        _clean(*frames)
        rep["data"] = open(zpath, "rb").read()
        rep["name"] = "frames.zip"
    else:
        rep["data"] = open(out, "rb").read()
        rep["name"] = "animation.gif"
    return rep


def still(name, data, config=None, dpi=200):
    """Every structure as drawn, as PNG bytes."""
    path = _put(name, data)
    out = os.path.join(WORK, "still.png")
    _clean(out)
    cfg = _config(config)
    _run(["still", path, "-o", out, "--dpi", int(dpi)]
         + (["-c", cfg] if cfg else []))
    return {"data": open(out, "rb").read(), "name": "structures.png"}


def editors(name, data, config=None):
    """The click-to-pair page for every transition, as standalone HTML."""
    path = _put(name, data)
    base = os.path.join(WORK, "editor.html")
    cfg = _config(config)
    rep = _run(["editor", path, "-o", base] + (["-c", cfg] if cfg else []))
    pages = []
    # the command reports one object for a single editor and a list for
    # several, so accept either shape rather than assuming one
    rows = rep if isinstance(rep, list) else [rep]
    outs = [r.get("out") for r in rows if isinstance(r, dict) and r.get("out")]
    if not outs and os.path.exists(base):
        outs = [base]
    for p in outs:
        if p and os.path.exists(p):
            with open(p) as fh:
                pages.append({"name": os.path.basename(p), "html": fh.read()})
    return pages
